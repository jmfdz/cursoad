---
name: ua-accesibilidad
description: Crear, revisar y corregir la accesibilidad y usabilidad de interfaces y páginas web en HTML, Vue, Razor, PHP o Markdown publicado como web, y validar URLs o proyectos con CADUA o AXE. Usar al crear o modificar componentes, vistas o páginas de un proyecto web, aunque no se mencione la accesibilidad; no para notas Markdown del segundo cerebro ni para documentos PDF, DOCX o PPTX.
---

# UA Accesibilidad

Skill autónoma para aplicar criterios de accesibilidad al crear, revisar o corregir
interfaces web: de forma preventiva al generar contenido y correctiva al revisar
ficheros, URLs o proyectos completos. No depende de ningún repositorio, librería,
validador externo ni otra skill.

## Tres formas de comprobar, con fronteras distintas

| Forma | Quién la hace | Qué alcanza |
| --- | --- | --- |
| Revisión de código | Un agente leyendo ficheros, sin navegador | Problemas visibles en el código fuente: marcado, plantillas, estructura, textos |
| Validación automática | CADUA, AXE o motor avanzado de teclado sobre páginas renderizadas | Las pruebas de cada motor sobre el DOM final, incluido el contraste real; en teclado, solo el recorrido documentado en `references/cadua.md` |
| Comprobación manual | Una persona | Teclado, lector de pantalla y todo lo que exige criterio |

Son complementarias y no se sustituyen entre sí. La revisión de código no confirma
nada que dependa del DOM final, del CSS aplicado ni del comportamiento en
ejecución; la validación automática no entiende el propósito de un texto ni la
estructura de un componente parcial.

Nunca presentes una como si fuera otra. Si has leído ficheros, el informe dice
revisión de código; si has ejecutado un motor, indica cuál. La revisión de
código no es una herramienta: **no existe ni debe construirse un validador estático
propio**. Las reglas viven en las referencias y las aplica quien revisa; las
herramientas de `tools/` ejecutan CADUA, AXE y los motores avanzados de teclado y
recogida de evidencias. Este último recoge material, no valida por sí solo.

## Flujo de trabajo

1. Úsala siempre que vayas a crear o modificar HTML, Vue, Razor, PHP, Markdown
   renderizado o componentes de interfaz.
2. Identifica el modo y carga su referencia (tabla siguiente).
3. Carga `references/checklist.md` para barrer una revisión, y solo las referencias
   completas de los elementos que necesites explicar o corregir.
4. Aplica los criterios antes de escribir código: la accesibilidad forma parte del
   diseño, no es solo una validación posterior.
5. Distingue siempre entre errores automáticos, avisos y comprobaciones manuales.
   La ausencia de errores detectables no equivale por sí sola a conformidad.
6. Si recibes documentación pública o código de validación ajeno como contexto,
   extrae los criterios aplicables sin copiar nombres internos ni estructuras
   privadas del proyecto de origen.
7. Ejecuta las herramientas automatizadas desde la raíz del proyecto revisado. No
   cambies al directorio de la skill salvo para instalar dependencias.
8. **No corrijas nada salvo que el usuario lo pida explícitamente.** Si solo pide
   revisar, informa, explica cómo se solucionaría y cierra el informe como indica
   `references/informes.md`.

## Modos de uso

| Modo | Qué hacer | Referencia |
| --- | --- | --- |
| Creación accesible | Diseña la estructura antes de escribir código, con HTML semántico y controles nativos. Aplica las referencias de los elementos presentes y, al crear interfaz, `usabilidad.md` y `diseno-estilos.md`. Registra de forma explícita cualquier limitación del diseño que impida cumplir un criterio. En un proyecto local, propone o ejecuta una revisión de código o una validación automática. | Las de cada elemento |
| Revisión de código | Lees ficheros sin navegador ni herramientas: inventario y cobertura declarada, clasificación de cada fichero, checklist, confirmación en padre o router, hallazgos con ruta, línea, `HTML incorrecto` y `HTML corregido` y código CADUA equivalente. Cierra proponiendo validar con CADUA. | `references/revision-codigo.md` |
| URLs | `run-cadua.mjs` con una o varias URLs, o `--file` para una lista. | `references/cadua.md` |
| Proyecto completo | `run-cadua-auto.mjs`, que reutiliza `results-accesibilidad/rutas.json` o lo crea desde el router la primera vez. Para .NET de la UA, también `references/proyectos-dotnet-ua.md`. | `references/cadua.md` |
| Teclado y componentes (avanzado) | `--engine teclado` y `--componentes`. | `references/cadua.md` |
| Evidencias de imágenes (avanzado) | `--engine evidencias`; después revisas los recortes y resuelves `imgManual`. | `references/cadua.md` |

Reglas fijas de todos los modos:

- En una revisión, lo que no puedas confirmar leyendo es `Comprobación manual
  pendiente`, nunca `Error`. Usa `Error` solo para un incumplimiento de
  accesibilidad, un componente que no funciona o un problema objetivo que impida
  completar la tarea; las pautas de usabilidad y diseño son `Aviso`.
- CADUA es el motor por defecto. AXE y los motores avanzados (teclado, componentes
  y evidencias) se ejecutan **solo si el usuario los pide expresamente**.
- El motor de teclado solo pulsa el tabulador y no activa controles. No exige que
  cada opción interna reciba Tab: radios y pestañas se recorren con flechas, y eso
  queda pendiente de comprobar; no añadas `tabindex="0"` para silenciar un
  hallazgo. `--componentes` sí abre los disparadores `data-bs-toggle`, nunca los
  controles de su interior.
- En evidencias, marca como error únicamente el texto alternativo que no se
  corresponda con la imagen: no persigas el alternativo perfecto. Las decorativas
  grandes con `alt=""` se revisan en una lista aparte.

## Referencias

Dos grupos que no deben mezclarse. Las **reglas** recogen criterios WCAG y pruebas
del catálogo, organizadas por familia, y sus hallazgos son `Error`. Las
**recomendaciones** recogen buenas prácticas que deben seguirse pero no son
exigibles, y sus hallazgos son `Aviso`. Una regla vive en una sola familia y no se
repite en las recomendaciones.

| Referencia | Grupo | Cuándo cargarla |
| --- | --- | --- |
| `references/checklist.md` | Regla | Barrido de una revisión y equivalencia entre reglas y códigos CADUA. |
| `references/revision-codigo.md` | Procedimiento | Recorrido, cobertura y formato de hallazgos de la revisión de código. |
| `references/imagenes.md` | Regla | Imágenes, iconos, SVG y textos alternativos. |
| `references/enlaces.md` | Regla | Enlaces, textos de enlace, enlaces con imagen o icono. |
| `references/encabezados.md` | Regla | Jerarquía de encabezados, orden y uso semántico. |
| `references/estructura.md` | Regla | Estructura HTML5, idioma, título, landmarks y maquetación semántica. |
| `references/componentes.md` | Regla | Modales, pestañas, desplegables, acordeones, regiones vivas y navegación en SPA. |
| `references/bootstrap-vue.md` | Regla | Componentes de Bootstrap dentro de Vue: qué gestiona el plugin y qué no duplicar. |
| `references/spa-vue.md` | Regla | Aplicaciones Vue de una sola página: `App.vue`, router, título, foco y regiones vivas. |
| `references/plantillas-vue.md` | Regla | Reglas comprobables en un `.vue` y cómo no convertirlas en falsos positivos. |
| `references/listas.md` | Regla | Listas reales, listas simuladas y tablas usadas como lista. |
| `references/tablas.md` | Regla | Tablas de datos, títulos, encabezados y tablas complejas. |
| `references/formularios.md` | Regla | Campos, etiquetas, grupos, obligatoriedad, selects y botones. |
| `references/colores.md` | Regla | Contraste y uso del color como portador de significado. |
| `references/cadua.md` | Herramienta | Motores CADUA, AXE, teclado y evidencias; comandos, manifiesto, resultados y credenciales. |
| `references/informes.md` | Procedimiento | Estructura y cierre de cualquier informe de resultados. |
| `references/proyectos-dotnet-ua.md` | Herramienta | Aplicaciones .NET de la UA con cliente Vue y login CAS. |
| `references/tipografia.md` | Recomendación | Familia tipográfica, tamaño base, espaciado, longitud de línea y mayúsculas. |
| `references/usabilidad.md` | Recomendación | Microcopy, estados, mensajes, prevención de errores, carga cognitiva y navegación. |
| `references/diseno-estilos.md` | Recomendación | Composición, clases CSS y uso prudente de utilidades Bootstrap. |

## Principios al crear contenido

- Usa HTML semántico antes que ARIA. Añade ARIA solo cuando el elemento nativo no
  cubra el patrón, y mantén sus estados sincronizados con el comportamiento visible.
- Todo control interactivo debe tener nombre accesible perceptible o equivalente.
- Todo contenido no textual debe tener alternativa textual o estar marcado como
  decorativo de forma intencionada.
- Prefiere texto visible descriptivo. Usa texto oculto visualmente o `aria-label`
  solo cuando el diseño lo haga necesario.
- No uses textos genéricos como "haz clic aquí", "imagen" o "foto", ni nombres de
  fichero, como sustituto de una descripción real.
- Mantén las soluciones legibles en el código y comprobables en navegador: que se
  entiendan leyendo el fichero y no dependan de efectos visuales que no existen en
  el DOM accesible.

## Alcance

Esta skill cubre contenido web. Generar documentos PDF, Word o PowerPoint, o
comprobar su accesibilidad, queda fuera de su alcance: si existe la skill
`ua-documentos-accesibles`, úsala; si no, entrega el resultado en Markdown o HTML e
indica que la versión en documento queda pendiente. Si un resultado de CADUA trae
pruebas de PDF, DOCX o PPTX, recógelas en el informe tal cual y márcalas como
comprobación manual pendiente.
