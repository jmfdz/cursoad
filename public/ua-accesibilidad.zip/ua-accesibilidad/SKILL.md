---
name: ua-accesibilidad
description: Crear, revisar y corregir contenido e interfaces accesibles y usables en HTML, Vue, Razor, PHP, Markdown renderizado o páginas web. Usar siempre que se vaya a generar o modificar ese tipo de contenido o componentes de interfaz, aunque el usuario no mencione accesibilidad. Usar también para aplicar microcopy y criterios de diseño, revisar ficheros de código sin ejecutar navegador, validar páginas con CADUA o AXE, preparar informes y aplicar correcciones cuando el usuario lo pida.
---

# UA Accesibilidad

Skill genérica para aplicar criterios de accesibilidad al crear, revisar o corregir
interfaces web. Se usa de forma preventiva al generar contenido y de forma
correctiva al revisar ficheros, URLs o proyectos completos. No depende de ningún
repositorio, librería ni validador concreto.

## Tres formas de comprobar, con fronteras distintas

| Forma | Quién la hace | Qué alcanza |
| --- | --- | --- |
| Revisión de código | Un agente leyendo ficheros, sin navegador | Problemas visibles en el código fuente: marcado, plantillas, estructura, textos |
| Validación automática | CADUA, AXE o motor avanzado de teclado sobre páginas renderizadas | Las pruebas de cada motor sobre el DOM final, incluido el contraste real; en teclado, solo el recorrido que se documenta abajo |
| Comprobación manual | Una persona | Teclado, lector de pantalla y todo lo que exige criterio |

Son complementarias y no se sustituyen entre sí. La revisión de código no confirma
nada que dependa del DOM final, del CSS aplicado ni del comportamiento en
ejecución; la validación automática no entiende el propósito de un texto ni la
estructura de un componente parcial.

Nunca presentes una como si fuera otra. Si has leído ficheros, el informe dice
revisión de código; si has ejecutado un motor, indica cuál. La revisión de
código no es una herramienta: **no existe ni debe construirse un validador estático
propio**. Las reglas viven en las referencias y las aplica quien revisa; las
herramientas de `tools/` ejecutan CADUA, AXE y los motores avanzados de teclado y
recogida de evidencias. Este último recoge material, no valida por sí solo.

## Flujo de trabajo

1. Úsala siempre que vayas a crear o modificar HTML, Vue, Razor, PHP, Markdown
   renderizado o componentes de interfaz.
2. Identifica el modo: creación accesible, revisión de código, validación de URLs
   o validación de proyecto completo.
3. Carga `references/checklist.md` para barrer una revisión, y solo las referencias
   completas de los elementos que necesites explicar o corregir.
4. Aplica los criterios antes de escribir código: la accesibilidad forma parte del
   diseño, no es solo una validación posterior.
5. Distingue siempre entre errores automáticos, avisos y comprobaciones manuales.
   La ausencia de errores detectables no equivale por sí sola a conformidad.
6. Si recibes documentación pública o código de validación ajeno como contexto,
   extrae los criterios aplicables sin copiar nombres internos ni estructuras
   privadas del proyecto de origen.
7. Ejecuta las herramientas automatizadas desde la raíz del proyecto revisado. No
   cambies al directorio de la skill salvo para instalar dependencias.
8. **No corrijas nada salvo que el usuario lo pida explícitamente.** Si solo pide
   revisar, informa, explica cómo se solucionaría y cierra el informe como indica
   `references/informes.md`.

## Modos de uso

### Creación accesible

Diseña la estructura accesible antes de escribir código y usa HTML semántico y
controles nativos siempre que puedas. Aplica las referencias de los elementos que
aparezcan y, al crear interfaz, también `usabilidad.md` y `diseno-estilos.md`. Si
una limitación del diseño impide cumplir un criterio, regístrala de forma
explícita en vez de dejarla implícita. Si el contenido pertenece a un proyecto
local, propone o ejecuta una revisión de código o una validación automática.

### Revisión de código

La haces tú leyendo ficheros: HTML, Vue, Razor, PHP, Markdown renderizado,
componentes, layouts, formularios y estilos relacionados. Sin navegador y sin
herramientas de la skill.

Sigue este recorrido:

1. **Inventaria y cuenta.** Enumera los ficheros candidatos con `find` o `grep` y
   apunta cuántos hay. Ese número es el denominador de la cobertura que declararás
   en el informe.
2. **Delimita.** Si son demasiados para revisarlos todos, elige un subconjunto con
   un criterio explicable: layouts y vistas antes que componentes hoja, lo que toca
   la tarea en curso, lo que más se reutiliza. Anota el criterio; no muestrees en
   silencio.
3. **Clasifica cada fichero** antes de juzgarlo: página completa, layout o
   componente parcial. Muchas reglas solo se pueden exigir a la página final.
4. **Recorre el checklist** fichero a fichero. En proyectos Vue,
   `references/plantillas-vue.md` separa lo que se puede afirmar leyendo la
   plantilla de lo que hay que confirmar en el componente padre o en el router.
   Si hay componentes Bootstrap, carga `references/bootstrap-vue.md` y comprueba
   la versión y el plugin utilizado antes de proponer cambios de ARIA o teclado.
5. **Confirma lo dudoso** en el padre, en el layout o en el router. Lo que no puedas
   confirmar leyendo es `Comprobación manual pendiente`, nunca `Error`.
6. **Declara la cobertura** en el informe: ficheros existentes, revisados, criterio
   de selección y qué queda pendiente de validar en navegador.

Para cada hallazgo:

- Localízalo con ruta y línea siempre que sea posible.
- Clasifícalo como `Error`, `Aviso` o `Comprobación manual pendiente`.
- Usa `Error` solo para un incumplimiento de accesibilidad, un componente que no
  funciona o un problema objetivo que impida completar la tarea. Las pautas de
  usabilidad y diseño son recomendaciones o `Aviso`.
- Explica por qué es un problema, qué criterio afecta y cómo se corrige, con
  `HTML incorrecto` y `HTML corregido`.
- Cita el código CADUA equivalente cuando exista, según `references/checklist.md`,
  para que este informe se pueda cruzar con el de la validación automática.

Cierra proponiendo la validación con CADUA para lo que no se puede resolver leyendo:
contraste real, comportamiento en ejecución y estructura de la página renderizada.

### Validación automática de URLs

Para una URL, varias o un fichero de URLs, usa `run-cadua.mjs` (con `--file` para
listas). Consulta `references/cadua.md` para motores, comandos y resultados.

### Comprobación de teclado (modo avanzado)

Solo cuando el usuario la pida expresamente. `--engine teclado` recorre las rutas
con el tabulador y comprueba lo que el catálogo no alcanza: controles inalcanzables,
trampas de teclado, foco no visible y `tabindex` positivos. Usa códigos propios de
un catálogo aparte y produce un informe separado del de CADUA. No activa ningún
control: solo pulsa el tabulador.

No exige que cada opción interna reciba Tab: radios y pestañas pueden recorrerse
con flechas. Ese comportamiento queda pendiente de comprobar; no añadas
`tabindex="0"` a todas las opciones para silenciar un hallazgo.

Con `--componentes` abre además los modales, desplegables y paneles declarados con
`data-bs-toggle` y comprueba foco, Escape, retorno del foco y `aria-expanded`. Esa
opción sí activa esos disparadores, nunca los controles de su interior.

### Revisión asistida de imágenes (modo avanzado)

También solo a petición. `--engine evidencias` recoge un recorte y una ficha de cada
imagen con texto alternativo, sin emitir veredicto; después las revisas tú y
resuelves `imgManual` con evidencia. Marca como error únicamente el texto que no se
corresponda con la imagen: no persigas el alternativo perfecto.

Recoge además, en una lista aparte, las imágenes grandes marcadas como decorativas
con `alt=""`, que son las candidatas a ser informativas mal marcadas. El resto de
decorativas quedan fuera.

El detalle de los tres motores avanzados está en `references/cadua.md`.

### Validación automática de proyecto completo

Usa `run-cadua-auto.mjs`, que reutiliza `results-accesibilidad/rutas.json` si ya
existe y lo crea desde el router la primera vez. Los detalles de manifiesto,
credenciales, regeneración y salida están en `references/cadua.md`. Para una
aplicación .NET de la UA, sigue además `references/proyectos-dotnet-ua.md`.

## Referencias

Dos grupos que no deben mezclarse. Las **referencias de reglas** recogen criterios WCAG
y pruebas del catálogo, organizadas por familia, y sus hallazgos son `Error`. Las
**referencias de recomendaciones** recogen buenas prácticas que deben seguirse pero que
no son exigibles, y sus hallazgos son `Aviso`. Una regla vive en una sola familia y no
se repite en las recomendaciones.

### Reglas

| Referencia | Cuándo cargarla |
| --- | --- |
| `references/checklist.md` | Barrido de una revisión y equivalencia entre reglas y códigos CADUA. |
| `references/imagenes.md` | Imágenes, iconos, SVG y textos alternativos. |
| `references/enlaces.md` | Enlaces, textos de enlace, enlaces con imagen o icono. |
| `references/encabezados.md` | Jerarquía de encabezados, orden y uso semántico. |
| `references/estructura.md` | Estructura HTML5, idioma, título, landmarks y maquetación semántica. |
| `references/componentes.md` | Modales, pestañas, desplegables, acordeones, regiones vivas y navegación en SPA. |
| `references/bootstrap-vue.md` | Componentes de Bootstrap dentro de Vue: qué gestiona el plugin y qué no duplicar. |
| `references/spa-vue.md` | Aplicaciones Vue de una sola página: `App.vue`, router, título, foco y regiones vivas. |
| `references/plantillas-vue.md` | Reglas comprobables en un `.vue` y cómo no convertirlas en falsos positivos. |
| `references/listas.md` | Listas reales, listas simuladas y tablas usadas como lista. |
| `references/tablas.md` | Tablas de datos, títulos, encabezados y tablas complejas. |
| `references/formularios.md` | Campos, etiquetas, grupos, obligatoriedad, selects y botones. |
| `references/colores.md` | Contraste y uso del color como portador de significado. |
| `references/cadua.md` | Ejecutar CADUA o AXE, manifiesto de rutas y ubicación de resultados. |
| `references/informes.md` | Estructura y cierre de cualquier informe de resultados. |
| `references/proyectos-dotnet-ua.md` | Aplicaciones .NET de la UA con cliente Vue y login CAS. |

### Recomendaciones

| Referencia | Cuándo cargarla |
| --- | --- |
| `references/tipografia.md` | Familia tipográfica, tamaño base, espaciado, longitud de línea y mayúsculas. |
| `references/usabilidad.md` | Microcopy, estados, mensajes, prevención de errores, carga cognitiva y navegación. |
| `references/diseno-estilos.md` | Composición, clases CSS y uso prudente de utilidades Bootstrap. |

## Principios al crear contenido

- Usa HTML semántico antes que ARIA. Añade ARIA solo cuando el elemento nativo no
  cubra el patrón, y mantén sus estados sincronizados con el comportamiento visible.
- Todo control interactivo debe tener nombre accesible perceptible o equivalente.
- Todo contenido no textual debe tener alternativa textual o estar marcado como
  decorativo de forma intencionada.
- Prefiere texto visible descriptivo. Usa texto oculto visualmente o `aria-label`
  solo cuando el diseño lo haga necesario.
- No uses textos genéricos como "haz clic aquí", "imagen" o "foto", ni nombres de
  fichero, como sustituto de una descripción real.
- Mantén las soluciones legibles en el código y comprobables en navegador: que se
  entiendan leyendo el fichero y no dependan de efectos visuales que no existen en
  el DOM accesible.

## Alcance

Esta skill cubre contenido web. Generar documentos accesibles, incluido un informe en
PDF, Word o PowerPoint, y comprobar la accesibilidad de un PDF, DOCX o PPTX corresponde a la skill
`ua-documentos-accesibles`. Si un resultado de CADUA trae pruebas de PDF, DOCX o PPTX,
recógelas en el informe tal cual y márcalas como comprobación manual pendiente.
