#!/usr/bin/env node
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { copiarScriptCaduaDesdeProyecto } from './lib/cadua-runner.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const destino = path.resolve(__dirname, 'vendor/cadua.core.global.js');

const origenIndicado = process.argv[2] ?? process.env.CADUA_SOURCE;

if (!origenIndicado) {
  process.stderr.write(
    [
      'Falta la ruta del script CADUA original.',
      '',
      'Uso:',
      '  node sync-cadua.mjs <ruta/a/cadua.core.global.js>',
      '  CADUA_SOURCE=<ruta> node sync-cadua.mjs',
      '',
      'En el proyecto de origen suele estar en wwwroot/lib/cadua.core.global.js.',
      ''
    ].join('\n')
  );
  process.exitCode = 1;
} else {
  const origen = path.resolve(process.cwd(), origenIndicado);
  try {
    const ruta = await copiarScriptCaduaDesdeProyecto(origen, destino);
    process.stdout.write(`Script CADUA sincronizado en: ${ruta}\n`);
  } catch (error) {
    process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
    process.exitCode = 1;
  }
}
