# CADUA/AXE Playwright

Herramienta CLI para ejecutar comprobaciones automaticas de accesibilidad sobre una o varias URLs con Chromium headless. Usa CADUA por defecto y puede usar AXE si se solicita explicitamente.

## Instalacion

```bash
cd skills/ua-accesibilidad/tools/cadua-playwright
npm install
npx playwright install chromium
```

## Uso

Ejecuta la herramienta desde la raiz del proyecto que quieres revisar. Las rutas relativas de salida se resuelven contra ese directorio, no contra la carpeta de la skill.

### Una URL o varias URLs

```bash
node /ruta/a/segundo-cerebro/skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs https://www.ua.es/
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs --file urls.txt --out resultados/cadua
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs https://www.ua.es/ https://web.ua.es/es/accesibilidad/ --stdout
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs https://www.ua.es/ --engine axe
```

### Lista de URLs

```bash
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs --file urls.txt
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs --file urls.txt --axe
```

### Generar URLs desde router

```bash
node skills/ua-accesibilidad/tools/cadua-playwright/generate-cadua-routes.mjs --router ClientApp/src/router/index.ts --base-url http://localhost:5173
node skills/ua-accesibilidad/tools/cadua-playwright/generate-cadua-routes.mjs --urls-out results-accesibilidad/urls.txt
node skills/ua-accesibilidad/tools/cadua-playwright/generate-cadua-routes.mjs --router ClientApp/src/router/index.ts --regenerate-routes
node skills/ua-accesibilidad/tools/cadua-playwright/generate-cadua-routes.mjs --router ClientApp/src/router/index.ts --base-url http://localhost:5173 --stdout
```

La primera ejecución crea `results-accesibilidad/rutas.json`. Las siguientes reutilizan ese fichero aunque se vuelva a indicar `--router`. Solo `--regenerate-routes` vuelve a leer el router y reemplaza las rutas de todas las pruebas, conservando sus usuarios y contraseñas.

### Proyecto completo

```bash
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua-auto.mjs --router ClientApp/src/router/index.ts --base-url http://localhost:5173
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua-auto.mjs
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua-auto.mjs --router ClientApp/src/router/index.ts --regenerate-routes
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua-auto.mjs --prueba prueba1
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua-auto.mjs --router ClientApp/src/router/index.ts --base-url http://localhost:5173 --axe
```

Para usar otra ubicación, indica `--manifest <ruta>`. Consulta `rutas.example.json` para definir varias pruebas, cada una con su autenticación y sus rutas.

### Pruebas y autenticación

El manifiesto es un único objeto. Cada propiedad principal representa una prueba con un usuario, una contraseña y su propia lista de rutas:

```json
{
  "prueba1": {
    "usuario": "nombre usuario",
    "contrasena": "contrasena",
    "rutas": [
      {
        "url": "http://localhost:5173/"
      },
      {
        "url": "http://localhost:5173/administracion"
      }
    ]
  }
}
```

Si `usuario` y `contrasena` están vacíos, la prueba se ejecuta sin autenticación. Si contienen valores, se utilizan directamente para iniciar sesión en CAS. Cada prueba se ejecuta en un contexto de navegador independiente y, cuando hay varias, sus resultados se guardan en subcarpetas separadas.

`results-accesibilidad/rutas.json` debe permanecer ignorado por Git porque puede contener credenciales locales. El fichero versionado `rutas.example.json` utiliza únicamente valores ficticios.

En el futuro se puede ampliar cada prueba con una lista de acciones previas, como pulsaciones o esperas. Esas acciones todavía no se ejecutan y no deben añadirse al JSON hasta que el ejecutor las implemente.

Ejecuta los comandos desde el directorio del proyecto o pasa `--out` con una ruta de salida dentro de ese directorio. La herramienta rechaza por defecto escribir resultados dentro de `skills/ua-accesibilidad/`; `--allow-skill-output` existe solo para pruebas internas y no debe usarse en revisiones de proyectos.

## Salida

- Por defecto, guarda `informe-accesibilidad.json` e `informe-accesibilidad.md` en `./results-accesibilidad/`.
- Cuando hay varias pruebas, crea una subcarpeta por prueba con esos dos ficheros.
- El JSON usa campos en español, agrupa los errores por criterio y no contiene credenciales.
- No genera ficheros JSON adicionales por URL.
- Por defecto, ejecuta el motor `cadua`.
- Con `--engine axe` o `--axe`, ejecuta axe-core desde `lib/axe.es.min.js` y normaliza sus violaciones al mismo formato de lote.
- Con `--stdout`, imprime el lote JSON en pantalla sin guardar resultados JSON.
- Con `--out`, guarda ambos informes en la carpeta indicada. Esa carpeta debe estar en el directorio de trabajo del usuario, no dentro de la skill.
- Con `--screenshot-errors`, guarda capturas en `./results-accesibilidad/screenshots/` o en la carpeta de salida.
- `run-cadua.mjs` tambien acepta `--router` y `--routes` para construir la lista de URLs a partir del router o de un manifiesto.
- `run-cadua-auto.mjs` hace el recorrido completo: router o manifiesto -> URLs -> motor seleccionado.
- `run-cadua-auto.mjs` crea y reutiliza por defecto `./results-accesibilidad/rutas.json`.
- Cada error se enriquece con `codigoPrueba` y `catalogoPrueba` a partir de `lib/catalogo-de-pruebas.json`.
- `catalogoPrueba` incluye id, codigo, familia, nombre, descripcion y auditoria (`referencia`, `criterio`, `nivel` y `wcag` cuando aplica).
- El informe textual empieza por `# Resultados de la comprobación de accesibilidad`, resume por tipo de prueba y muestra `HTML incorrecto` y `HTML corregido`.

## Motores

- `cadua`: motor por defecto. Usa `vendor/cadua.core.global.js` y enriquece resultados con `lib/catalogo-de-pruebas.json`.
- `axe`: motor opcional. Usa `lib/axe.es.min.js`, axe-core con el idioma espanol ya configurado. Se regenera con `npm run sync-axe`. Solo debe ejecutarse cuando el usuario lo pida expresamente.
- `evidencias`: motor opcional. Recoge capturas y fichas de las imagenes con texto alternativo para poder resolver `imgManual`. No emite veredicto. Solo debe ejecutarse cuando el usuario lo pida expresamente.
- `teclado`: motor opcional. Recorre la pagina con el tabulador y usa los codigos de `lib/catalogo-de-pruebas-avanzadas.json`. Solo debe ejecutarse cuando el usuario lo pida expresamente.

### Motor de teclado

```bash
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs https://www.ua.es/ --teclado
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua-auto.mjs --engine teclado
```

Comprueba lo que no cubre el catalogo oficial: controles que no se alcanzan con el
tabulador, trampas de teclado, elementos ocultos que reciben el foco, falta de
indicador de foco, `tabindex` positivos y el contraste 3:1 del indicador de foco.

El contraste evalúa los indicadores visibles y descarta colores transparentes.
En sombras analiza todas las capas de anillos concéntricos opacos, sin desenfoque,
y excluye las tapadas. Las geometrías o fondos que no puede resolver quedan como
comprobación pendiente; no equivalen a un resultado conforme.

Solo pulsa el tabulador. No pulsa Intro ni Espacio, de modo que no activa botones ni
envia formularios: puede ejecutarse sobre una aplicacion con datos reales. Si en el
futuro se anaden acciones que activen controles, deben declararse ruta por ruta.

Con `--componentes` abre ademas los componentes declarados con `data-bs-toggle`
(modal, dropdown, collapse) y comprueba que el foco entra en el dialogo, que no se
escapa al contenido de detras, que Escape lo cierra, que el foco vuelve al control
que lo abrio y que `aria-expanded` cambia al abrir:

```bash
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs https://ejemplo/ --teclado --componentes
```

Esa opcion activa los disparadores con `data-bs-toggle`, que por definicion solo
abren o cierran interfaz, y nunca pulsa un control del interior del componente.

En modales espera los eventos `shown.bs.modal` y `hidden.bs.modal` del destino
concreto del disparador, con un plazo máximo de 2,5 segundos. Registra el diálogo,
el elemento activo y el tiempo esperado en `rutas[].teclado.componentes`.
Las aperturas no confirmadas quedan pendientes. Prueba Tab y Mayús+Tab por separado
y recarga la ruta entre disparadores para aislar el estado de los componentes.
No activa pestañas. El paso del foco por la interfaz del navegador no se considera
una fuga hacia contenido de la página.

`--teclado --forced-colors` ejecuta un recorrido independiente en colores forzados.
La CLI escribe sus resultados en la subcarpeta `forced-colors` del directorio de
salida. El JSON identifica el modo en `rutas[].teclado.modo`. La emulación no
sustituye una revisión con las configuraciones de alto contraste del usuario.

El comportamiento tras operaciones CRUD y las regiones vivas siguen siendo
comprobacion manual.

Sus codigos van en un catalogo aparte del oficial, con la misma nomenclatura y los
mismos campos, para poder fusionarlos si algun dia se incorporan a CADUA.

### Motor de evidencias

```bash
node skills/ua-accesibilidad/tools/cadua-playwright/run-cadua.mjs https://ejemplo/ --evidencias
```

Guarda en `results-accesibilidad/evidencias/` un recorte por imagen y un
`imagenes.json` con el texto alternativo, su longitud, el `src`, las dimensiones, si
esta dentro de un enlace o boton y el texto de alrededor.

Los recortes se guardan en `evidencias/ruta-NNNN/`; `imagenes.json` reúne todas las
rutas al terminar el lote, también con concurrencia. Cada ficha incluye su URL.
Antes de medir se inicia la carga diferida; antes de capturar se desplaza la imagen,
se espera su decodificación con plazo máximo y se actualizan las dimensiones.
Si falla, la ficha contiene `captura: null` y `motivoCapturaNoDisponible`.

Recoge las imagenes con `alt` no vacio y, en una lista aparte, las decorativas
grandes: imagenes sueltas, visibles, de al menos 150x150 px y con `alt=""`, que son
las candidatas a ser informativas mal marcadas. El resto de decorativas quedan fuera,
igual que las que estan dentro de un enlace o boton. Las que no tienen `alt` las
comprueba CADUA con `imgWithoutAlt`.

No emite ningun veredicto: el informe dice cuantas imagenes quedan pendientes de
revisar. Quien revisa abre los recortes y resuelve `imgManual`.

## Uso dentro de la skill

- Para revisar una URL o varias URLs, usa `run-cadua.mjs`.
- Para revisar un proyecto completo con rutas generadas desde router o manifiesto, usa `run-cadua-auto.mjs`.
- Para crear o revisar un manifiesto sin ejecutar navegador, usa `generate-cadua-routes.mjs`.
- No guardes resultados dentro de `skills/ua-accesibilidad/`.
- Si el usuario no ha pedido corregir errores, informa de los errores y termina preguntando si quiere que los soluciones con la skill.

## Sincronización del script

El script CADUA vive en `vendor/cadua.core.global.js`. Para actualizarlo, indica la
ruta del fichero original del proyecto que lo distribuye:

```bash
node sync-cadua.mjs ../../../../otro-proyecto/wwwroot/lib/cadua.core.global.js
CADUA_SOURCE=/ruta/al/cadua.core.global.js npm run sync-cadua
```

Consulta `vendor/README.md` para la procedencia, las sumas de comprobación y las
dudas de licencia pendientes de aclarar.

### Regresión de los motores avanzados

`npm test` incluye Bootstrap 5.3.8 como dependencia exclusiva de pruebas y valida
anillos de foco, modales correctos y defectuosos, expresiones de rutas, evidencias
concurrentes, carga diferida y el recorrido en colores forzados.

El generador excluye las rutas que contienen `${...}` e informa del número de
expresiones sin resolver. Hay que completar sus URLs concretas en `rutas.json`.
