#!/usr/bin/env node
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  crearManifiestoCaduaDesdeRouterSource,
  crearManifiestoPruebasDesdeUrls,
  ejecutarLoteCadua,
  inferirBaseUrlPruebas,
  leerRutasManifiestoCadua,
  leerUrlsDesdeArchivo,
  normalizarUrlEntrada,
  urlsDesdeManifiesto
} from './lib/cadua-runner.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const skillDir = path.resolve(__dirname, '..', '..');
const defaultOutputDir = path.resolve(process.cwd(), 'results-accesibilidad');
const defaultManifestPath = path.join(defaultOutputDir, 'rutas.json');
const defaultCaduaScript = path.join(__dirname, 'vendor', 'cadua.core.global.js');

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.forcedColors) {
    if (args.engine !== 'teclado') throw new Error('--forced-colors requiere el motor teclado.');
    if (args.outputDir) args.outputDir = path.join(args.outputDir, 'forced-colors');
  }

  if (args.help) {
    mostrarAyuda();
    process.exit(0);
  }

  const contexto = await prepararContextoEjecucion(args);

  if (!contexto.pruebas.length) {
    throw new Error('No se han generado URLs para comprobar.');
  }

  if (args.urlsOutPath) {
    const urls = [...new Set(contexto.pruebas.flatMap((prueba) => prueba.urls))];
    await asegurarDirectorioPadre(args.urlsOutPath);
    await writeFile(args.urlsOutPath, `${urls.join('\n')}\n`, 'utf8');
  }

  const ejecuciones = [];
  for (const prueba of contexto.pruebas) {
    const outputDir = args.outputDir && contexto.pruebas.length > 1
      ? path.join(args.outputDir, sanitizarNombre(prueba.nombre))
      : args.outputDir;
    const lote = await ejecutarLoteCadua(prueba.urls, {
      engine: args.engine,
      componentes: args.componentes,
      forcedColors: args.forcedColors,
      caduaScriptPath: defaultCaduaScript,
      outputDir,
      concurrency: args.concurrency,
      timeout: args.timeout,
      settleDelayMs: args.settleDelayMs,
      querySuffix: args.querySuffix,
      waitUntil: args.waitUntil,
      headful: args.headful,
      screenshotErrors: args.screenshotErrors,
      agregarErrores: args.agregarErrores,
      casLogin: prueba.auth.casLogin,
      casLoginUrl: prueba.auth.casLoginUrl,
      casUsername: prueba.auth.casUsername,
      casPassword: prueba.auth.casPassword,
      storageStatePath: args.storageStatePath,
      raw: args.raw,
      nombrePrueba: prueba.nombre
    });
    ejecuciones.push({ prueba: prueba.nombre, lote });
  }

  if (args.stdout || !args.outputDir) {
    const salida = ejecuciones.length === 1 ? ejecuciones[0].lote : { ejecuciones };
    process.stdout.write(`${JSON.stringify(salida, null, args.pretty ? 2 : 0)}\n`);
  } else {
    for (const ejecucion of ejecuciones) {
      process.stderr.write(`CADUA [${ejecucion.prueba}]: ${ejecucion.lote.resumen.rutasCorrectas}/${ejecucion.lote.resumen.totalRutas} rutas correctas.\n`);
      if (ejecucion.lote.informe) {
        process.stderr.write(`${ejecucion.lote.informe}\n`);
      }
    }
    process.stderr.write(`Resultados guardados en: ${path.resolve(args.outputDir)}\n`);
  }

  process.stderr.write(`Rutas ${contexto.manifestAction} desde: ${path.resolve(contexto.manifestPath)}\n`);
  if (args.urlsOutPath) {
    process.stderr.write(`URLs CADUA escritas en: ${path.resolve(args.urlsOutPath)}\n`);
  }
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}

async function prepararContextoEjecucion(args) {
  const manifestPath = args.manifestPath ?? args.seedManifestPath ?? defaultManifestPath;
  const existeManifiesto = existsSync(manifestPath);
  let manifiesto;
  let manifestAction = 'reutilizadas';

  if (existeManifiesto && !args.regenerateRoutes) {
    manifiesto = await leerRutasManifiestoCadua(manifestPath);
  } else {
    if (!args.routerPath) {
      throw new Error(`No existe ${manifestPath}. Indica --router para generar las rutas por primera vez.`);
    }
    const anterior = existeManifiesto ? await leerRutasManifiestoCadua(manifestPath) : null;
    const routerSource = await readFile(args.routerPath, 'utf8');
    const baseUrl = args.baseUrl ?? inferirBaseUrlPruebas(anterior?.pruebas);
    const generado = crearManifiestoCaduaDesdeRouterSource(routerSource, baseUrl);
    const urlsGeneradas = urlsDesdeManifiesto(generado.routes, generado.baseUrl);
    const manifiestoPruebas = crearManifiestoPruebasDesdeUrls(urlsGeneradas, anterior?.raw);
    await asegurarDirectorioPadre(manifestPath);
    await writeFile(manifestPath, `${JSON.stringify(manifiestoPruebas, null, 2)}\n`, 'utf8');
    manifiesto = await leerRutasManifiestoCadua(manifestPath);
    manifestAction = existeManifiesto ? 'regeneradas' : 'generadas';
  }

  const pruebas = [];
  for (const prueba of manifiesto.pruebas) {
    if (args.testNames.length && !args.testNames.includes(prueba.nombre)) continue;
    const urls = prueba.rutas.map((ruta) => normalizarUrlEntrada(ruta.url)).filter(Boolean);
    if (!urls.length) {
      throw new Error(`La prueba "${prueba.nombre}" no contiene ninguna ruta valida.`);
    }
    pruebas.push({ nombre: prueba.nombre, urls, auth: resolverAuthPrueba(prueba, args) });
  }

  if (args.testNames.length) {
    const encontrados = new Set(pruebas.map((prueba) => prueba.nombre));
    const ausentes = args.testNames.filter((nombre) => !encontrados.has(nombre));
    if (ausentes.length) {
      throw new Error(`Pruebas no encontradas: ${ausentes.join(', ')}.`);
    }
  }

  if (args.storageStatePath && pruebas.length > 1) {
    throw new Error('No se puede compartir --storage-state entre varias pruebas. Ejecuta una cada vez con --prueba.');
  }

  if (args.filePaths.length) {
    const urlsExtra = [];
    for (const ruta of args.filePaths) {
      urlsExtra.push(...await leerUrlsDesdeArchivo(ruta));
    }
    for (const prueba of pruebas) prueba.urls.push(...urlsExtra);
  }

  if (args.positionalUrls.length) {
    const urlsExtra = args.positionalUrls.map(normalizarUrlEntrada).filter(Boolean);
    for (const prueba of pruebas) prueba.urls.push(...urlsExtra);
  }

  for (const prueba of pruebas) prueba.urls = [...new Set(prueba.urls)];
  return { manifiesto, pruebas, manifestPath, manifestAction };
}

function resolverAuthPrueba(prueba, args) {
  const usuario = prueba.usuario.trim();
  const contrasena = prueba.contrasena;
  if (!usuario && !contrasena && !args.casLogin) {
    return { casLogin: false, casLoginUrl: args.casLoginUrl, casUsername: null, casPassword: null };
  }
  const casUsername = usuario || process.env.CAS_USERNAME;
  const casPassword = contrasena || process.env.CAS_PASSWORD;
  if (!casUsername || !casPassword) {
    throw new Error(`La prueba "${prueba.nombre}" debe indicar usuario y contrasena, o dejar ambos vacios.`);
  }
  return {
    casLogin: true,
    casLoginUrl: prueba.urlLogin ?? args.casLoginUrl,
    casUsername,
    casPassword
  };
}

async function asegurarDirectorioPadre(rutaArchivo) {
  await mkdir(path.dirname(path.resolve(rutaArchivo)), { recursive: true });
}

function sanitizarNombre(valor) {
  return String(valor).toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'prueba';
}

function parseArgs(argv) {
  const args = {
    routerPath: null,
    manifestPath: null,
    seedManifestPath: null,
    regenerateRoutes: false,
    testNames: [],
    urlsOutPath: null,
    filePaths: [],
    positionalUrls: [],
    baseUrl: null,
    engine: 'cadua',
    componentes: false,
    outputDir: null,
    concurrency: 2,
    timeout: 30000,
    settleDelayMs: 750,
    querySuffix: 'body',
    waitUntil: 'domcontentloaded',
    headful: false,
    screenshotErrors: false,
    agregarErrores: false,
    casLogin: false,
    casLoginUrl: 'https://casdesa.cpd.ua.es/cas/login',
    storageStatePath: null,
    raw: false,
    stdout: false,
    allowSkillOutput: false,
    pretty: true,
    help: false
  };

  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];

    switch (token) {
      case '--router':
        args.routerPath = requerirValor(argv, ++i, token);
        break;
      case '--manifest':
        args.manifestPath = requerirValor(argv, ++i, token);
        break;
      case '--seed-manifest':
        args.seedManifestPath = requerirValor(argv, ++i, token);
        break;
      case '--regenerate-routes':
        args.regenerateRoutes = true;
        break;
      case '--prueba':
        args.testNames.push(requerirValor(argv, ++i, token));
        break;
      case '--urls-out':
        args.urlsOutPath = requerirValor(argv, ++i, token);
        break;
      case '--base-url':
        args.baseUrl = requerirValor(argv, ++i, token);
        break;
      case '--file':
      case '-f':
        args.filePaths.push(requerirValor(argv, ++i, token));
        break;
      case '--out':
      case '-o':
        args.outputDir = requerirValor(argv, ++i, token);
        break;
      case '--engine':
        args.engine = validarEngine(requerirValor(argv, ++i, token));
        break;
      case '--axe':
        args.engine = 'axe';
        break;
      case '--teclado':
        args.engine = 'teclado';
        break;
      case '--forced-colors':
        args.forcedColors = true;
        break;
      case '--componentes':
        args.componentes = true;
        break;
      case '--evidencias':
        args.engine = 'evidencias';
        break;
      case '--allow-skill-output':
        args.allowSkillOutput = true;
        break;
      case '--concurrency':
      case '-c':
        args.concurrency = Number(requerirValor(argv, ++i, token));
        break;
      case '--timeout':
        args.timeout = Number(requerirValor(argv, ++i, token));
        break;
      case '--settle-delay':
        args.settleDelayMs = Number(requerirValor(argv, ++i, token));
        break;
      case '--query':
        args.querySuffix = requerirValor(argv, ++i, token);
        break;
      case '--wait':
        args.waitUntil = validarWaitUntil(requerirValor(argv, ++i, token));
        break;
      case '--headful':
        args.headful = true;
        break;
      case '--screenshot-errors':
        args.screenshotErrors = true;
        break;
      case '--cas-login':
        args.casLogin = true;
        break;
      case '--cas-login-url':
        args.casLoginUrl = requerirValor(argv, ++i, token);
        break;
      case '--storage-state':
        args.storageStatePath = requerirValor(argv, ++i, token);
        break;
      case '--agregar-errores':
        args.agregarErrores = true;
        break;
      case '--raw':
        args.raw = true;
        break;
      case '--stdout':
        args.stdout = true;
        break;
      case '--pretty':
        args.pretty = true;
        break;
      case '--no-pretty':
        args.pretty = false;
        break;
      case '--help':
      case '-h':
        args.help = true;
        break;
      default:
        if (token.startsWith('-')) {
          throw new Error(`Opcion desconocida: ${token}`);
        }

        args.positionalUrls.push(token);
        break;
    }
  }

  if (args.help) {
    return args;
  }

  if (!Number.isInteger(args.concurrency) || args.concurrency < 1) {
    throw new Error('`--concurrency` debe ser un numero entero mayor o igual que 1.');
  }

  if (!Number.isInteger(args.timeout) || args.timeout < 1) {
    throw new Error('`--timeout` debe ser un numero entero mayor o igual que 1.');
  }

  if (!Number.isInteger(args.settleDelayMs) || args.settleDelayMs < 0) {
    throw new Error('`--settle-delay` debe ser un numero entero mayor o igual que 0.');
  }

  if (args.manifestPath && args.seedManifestPath) {
    throw new Error('Usa --manifest o --seed-manifest, no ambos a la vez.');
  }

  if (!args.stdout && !args.outputDir) {
    args.outputDir = defaultOutputDir;
  }

  validarRutaSalida(args.outputDir, '--out', args.allowSkillOutput);
  validarRutaSalida(args.seedManifestPath, '--seed-manifest', args.allowSkillOutput);
  if (args.regenerateRoutes) {
    validarRutaSalida(args.manifestPath, '--manifest', args.allowSkillOutput);
  }
  validarRutaSalida(args.urlsOutPath, '--urls-out', args.allowSkillOutput);
  validarRutaSalida(args.storageStatePath, '--storage-state', args.allowSkillOutput);

  if (args.stdout && args.screenshotErrors && !args.outputDir) {
    args.outputDir = defaultOutputDir;
    validarRutaSalida(args.outputDir, '--out', args.allowSkillOutput);
  }

  return args;
}

function validarEngine(valor) {
  const engine = String(valor ?? '').trim().toLowerCase();
  if (engine === 'cadua' || engine === 'axe' || engine === 'teclado' || engine === 'evidencias') {
    return engine;
  }

  throw new Error('`--engine` debe ser `cadua`, `axe`, `teclado` o `evidencias`.');
}

function validarRutaSalida(ruta, opcion, allowSkillOutput) {
  if (!ruta || allowSkillOutput) {
    return;
  }

  const rutaResuelta = path.resolve(ruta);
  const relativa = path.relative(skillDir, rutaResuelta);
  const estaDentroDeSkill = relativa === '' || (!relativa.startsWith('..') && !path.isAbsolute(relativa));

  if (estaDentroDeSkill) {
    throw new Error(`${opcion} no puede apuntar dentro de la skill: ${rutaResuelta}. Ejecuta el comando desde el proyecto o usa una ruta como ./results-accesibilidad.`);
  }
}

function requerirValor(argv, index, opcion) {
  const valor = argv[index];
  if (valor == null || valor.startsWith('-')) {
    throw new Error(`Falta el valor para ${opcion}.`);
  }

  return valor;
}

function validarWaitUntil(valor) {
  const permitidos = new Set(['domcontentloaded', 'load', 'networkidle']);
  if (!permitidos.has(valor)) {
    throw new Error('`--wait` debe ser `domcontentloaded`, `load` o `networkidle`.');
  }

  return valor;
}

function mostrarAyuda() {
  process.stdout.write(`Uso:
  node run-cadua-auto.mjs --router <router.ts> --base-url <url> [opciones]
  node run-cadua-auto.mjs [--manifest <rutas.json>] [opciones]

Opciones de generacion:
  --router <ruta>          Lee un router Vue al crear o regenerar las rutas
  --manifest <ruta>        Usa otro manifiesto (por defecto results-accesibilidad/rutas.json)
  --base-url <url>         Base para resolver rutas relativas
  --seed-manifest <ruta>   Alias compatible para indicar el manifiesto que se va a crear
  --regenerate-routes      Regenera desde el router las rutas de todas las pruebas
  --prueba <nombre>        Ejecuta solo esta prueba; se puede repetir
  --urls-out <ruta>        Escribe una lista de URLs en un fichero
  --file, -f <ruta>        Anade URLs desde un fichero

Opciones de ejecucion:
  --out, -o <carpeta>      Guarda los resultados JSON en una carpeta
                            Por defecto: ./results-accesibilidad si no usas --stdout
  --engine <motor>         Motor de comprobacion: cadua | axe | teclado | evidencias
                           (por defecto cadua)
  --axe                    Alias de --engine axe
  --teclado                Alias de --engine teclado. Recorre la pagina con el
                           tabulador; no pulsa Intro ni Espacio, asi que no
                           activa ningun control
  --forced-colors          Recorrido de teclado separado con colores forzados
  --componentes            Solo con --teclado. Abre ademas los componentes
                           declarados con data-bs-toggle (modal, dropdown,
                           collapse) para comprobar foco, Escape y retorno.
                           Activa esos disparadores, nunca los controles de
                           su interior
  --evidencias             Alias de --engine evidencias. Recoge capturas y fichas
                           de las imagenes con texto alternativo para resolver
                           imgManual. No emite veredicto ni activa nada
  --stdout                 Imprime el JSON por pantalla
  --allow-skill-output     Permite escribir dentro de la skill solo para pruebas internas
  --concurrency, -c <n>    Numero de paginas simultaneas (por defecto 2)
  --timeout <ms>           Timeout de navegacion y evaluacion (por defecto 30000)
  --settle-delay <ms>      Espera extra tras cargar la pagina (por defecto 750)
  --query <selector>       Selector CADUA (por defecto body)
  --wait <estado>          domcontentloaded | load | networkidle
  --headful                Ejecuta Chromium visible
  --screenshot-errors      Guarda capturas cuando haya errores o fallos
  --cas-login              Inicia sesion en CAS con CAS_USERNAME y CAS_PASSWORD
  --cas-login-url <url>    URL de login CAS (por defecto casdesa)
  --storage-state <ruta>   Lee o guarda estado de sesion de Playwright
  --agregar-errores        Pinta errores sobre la pagina
  --raw                    Devuelve el JSON original de CADUA
  --pretty                 Formatea el JSON con indentacion
  --no-pretty              Minimiza el JSON impreso por pantalla
  -h, --help               Muestra esta ayuda

Ejemplos:
  node run-cadua-auto.mjs --router ClientApp/src/router/index.ts --base-url http://localhost:5173
  node run-cadua-auto.mjs
  node run-cadua-auto.mjs --router ClientApp/src/router/index.ts --regenerate-routes
  node run-cadua-auto.mjs --prueba prueba1
`);
}
