#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  ejecutarLoteCadua,
  extraerRutasDesdeRouter,
  leerRutasManifiestoCadua,
  leerUrlsDesdeArchivo,
  normalizarUrlEntrada,
  urlsDesdeManifiesto
} from './lib/cadua-runner.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const skillDir = path.resolve(__dirname, '..', '..');
const defaultOutputDir = path.resolve(process.cwd(), 'results-accesibilidad');
const defaultCaduaScript = path.join(__dirname, 'vendor', 'cadua.core.global.js');

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.forcedColors) {
    if (args.engine !== 'teclado') throw new Error('--forced-colors requiere el motor teclado.');
    if (args.outputDir) args.outputDir = path.join(args.outputDir, 'forced-colors');
  }

  if (args.help) {
    mostrarAyuda();
    process.exit(0);
  }

  const urls = await obtenerUrls(args);
  if (!urls.length) {
    throw new Error('No se han proporcionado URLs.');
  }

  const lote = await ejecutarLoteCadua(urls, {
    engine: args.engine,
    componentes: args.componentes,
    forcedColors: args.forcedColors,
    caduaScriptPath: defaultCaduaScript,
    outputDir: args.outputDir,
    concurrency: args.concurrency,
    timeout: args.timeout,
    settleDelayMs: args.settleDelayMs,
    querySuffix: args.querySuffix,
    waitUntil: args.waitUntil,
    headful: args.headful,
    screenshotErrors: args.screenshotErrors,
    agregarErrores: args.agregarErrores,
    casLogin: args.casLogin,
    casLoginUrl: args.casLoginUrl,
    casUsername: process.env.CAS_USERNAME,
    casPassword: process.env.CAS_PASSWORD,
    storageStatePath: args.storageStatePath,
    raw: args.raw
  });

  if (args.stdout || !args.outputDir) {
    process.stdout.write(`${JSON.stringify(lote, null, args.pretty ? 2 : 0)}\n`);
  } else {
    process.stderr.write(`CADUA completado: ${lote.resumen.rutasCorrectas}/${lote.resumen.totalRutas} rutas correctas.\n`);
    if (lote.informe) {
      process.stderr.write(`${lote.informe}\n`);
    }
    if (args.outputDir) {
      process.stderr.write(`Resultados guardados en: ${path.resolve(args.outputDir)}\n`);
    }
  }
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}

async function obtenerUrls(args) {
  const urls = [];

  if (args.routesManifestPath) {
    const manifiesto = await leerRutasManifiestoCadua(args.routesManifestPath);
    urls.push(...urlsDesdeManifiesto(manifiesto.routes, args.baseUrl ?? manifiesto.baseUrl));
  }

  if (args.routerPath) {
    const rutas = await extraerRutasDesdeRouter(args.routerPath);
    const rutasManifiesto = rutas.map((ruta) => ({
      path: ruta,
      enabled: !/[:*]/.test(ruta),
      source: 'router',
      kind: /[:*]/.test(ruta) ? 'dynamic' : 'static',
      examples: []
    }));
    urls.push(...urlsDesdeManifiesto(rutasManifiesto, args.baseUrl));
  }

  if (args.filePaths.length) {
    for (const ruta of args.filePaths) {
      urls.push(...await leerUrlsDesdeArchivo(ruta));
    }
  }

  if (args.positionalUrls.length) {
    urls.push(...args.positionalUrls.map(normalizarUrlEntrada).filter(Boolean));
  }

  if (!urls.length && !process.stdin.isTTY) {
    const stdin = await readFile(0, 'utf8');
    urls.push(
      ...stdin
        .replace(/^\uFEFF/, '')
        .split(/\r?\n/)
        .map((linea) => linea.trim())
        .filter((linea) => linea && !linea.startsWith('#'))
        .map((linea) => normalizarUrlEntrada(linea))
        .filter(Boolean)
    );
  }

  return [...new Set(urls)];
}

function parseArgs(argv) {
  const args = {
    filePaths: [],
    positionalUrls: [],
    engine: 'cadua',
    componentes: false,
    outputDir: null,
    concurrency: 2,
    timeout: 30000,
    settleDelayMs: 750,
    querySuffix: 'body',
    waitUntil: 'domcontentloaded',
    headful: false,
    screenshotErrors: false,
    agregarErrores: false,
    casLogin: false,
    casLoginUrl: 'https://casdesa.cpd.ua.es/cas/login',
    storageStatePath: null,
    raw: false,
    stdout: false,
    allowSkillOutput: false,
    pretty: true,
    routerPath: null,
    routesManifestPath: null,
    baseUrl: null,
    help: false
  };

  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];

    switch (token) {
      case '--file':
      case '-f':
        args.filePaths.push(requerirValor(argv, ++i, token));
        break;
      case '--out':
      case '-o':
        args.outputDir = requerirValor(argv, ++i, token);
        break;
      case '--engine':
        args.engine = validarEngine(requerirValor(argv, ++i, token));
        break;
      case '--axe':
        args.engine = 'axe';
        break;
      case '--teclado':
        args.engine = 'teclado';
        break;
      case '--forced-colors':
        args.forcedColors = true;
        break;
      case '--componentes':
        args.componentes = true;
        break;
      case '--evidencias':
        args.engine = 'evidencias';
        break;
      case '--allow-skill-output':
        args.allowSkillOutput = true;
        break;
      case '--concurrency':
      case '-c':
        args.concurrency = Number(requerirValor(argv, ++i, token));
        break;
      case '--timeout':
        args.timeout = Number(requerirValor(argv, ++i, token));
        break;
      case '--settle-delay':
        args.settleDelayMs = Number(requerirValor(argv, ++i, token));
        break;
      case '--query':
        args.querySuffix = requerirValor(argv, ++i, token);
        break;
      case '--router':
        args.routerPath = requerirValor(argv, ++i, token);
        break;
      case '--routes':
      case '--manifest':
        args.routesManifestPath = requerirValor(argv, ++i, token);
        break;
      case '--base-url':
        args.baseUrl = requerirValor(argv, ++i, token);
        break;
      case '--wait':
        args.waitUntil = validarWaitUntil(requerirValor(argv, ++i, token));
        break;
      case '--headful':
        args.headful = true;
        break;
      case '--screenshot-errors':
        args.screenshotErrors = true;
        break;
      case '--cas-login':
        args.casLogin = true;
        break;
      case '--cas-login-url':
        args.casLoginUrl = requerirValor(argv, ++i, token);
        break;
      case '--storage-state':
        args.storageStatePath = requerirValor(argv, ++i, token);
        break;
      case '--raw':
        args.raw = true;
        break;
      case '--stdout':
        args.stdout = true;
        break;
      case '--pretty':
        args.pretty = true;
        break;
      case '--no-pretty':
        args.pretty = false;
        break;
      case '--help':
      case '-h':
        args.help = true;
        break;
      default:
        if (token.startsWith('-')) {
          throw new Error(`Opcion desconocida: ${token}`);
        }

        args.positionalUrls.push(token);
        break;
    }
  }

  if (args.help) {
    return args;
  }

  if (!Number.isInteger(args.concurrency) || args.concurrency < 1) {
    throw new Error('`--concurrency` debe ser un numero entero mayor o igual que 1.');
  }

  if (!Number.isInteger(args.timeout) || args.timeout < 1) {
    throw new Error('`--timeout` debe ser un numero entero mayor o igual que 1.');
  }

  if (!Number.isInteger(args.settleDelayMs) || args.settleDelayMs < 0) {
    throw new Error('`--settle-delay` debe ser un numero entero mayor o igual que 0.');
  }

  if (!args.stdout && !args.outputDir) {
    args.outputDir = defaultOutputDir;
  }

  validarRutaSalida(args.outputDir, '--out', args.allowSkillOutput);
  validarRutaSalida(args.storageStatePath, '--storage-state', args.allowSkillOutput);

  if (args.stdout && args.screenshotErrors && !args.outputDir) {
    args.outputDir = defaultOutputDir;
    validarRutaSalida(args.outputDir, '--out', args.allowSkillOutput);
  }

  return args;
}

function validarEngine(valor) {
  const engine = String(valor ?? '').trim().toLowerCase();
  if (engine === 'cadua' || engine === 'axe' || engine === 'teclado' || engine === 'evidencias') {
    return engine;
  }

  throw new Error('`--engine` debe ser `cadua`, `axe`, `teclado` o `evidencias`.');
}

function validarRutaSalida(ruta, opcion, allowSkillOutput) {
  if (!ruta || allowSkillOutput) {
    return;
  }

  const rutaResuelta = path.resolve(ruta);
  const relativa = path.relative(skillDir, rutaResuelta);
  const estaDentroDeSkill = relativa === '' || (!relativa.startsWith('..') && !path.isAbsolute(relativa));

  if (estaDentroDeSkill) {
    throw new Error(`${opcion} no puede apuntar dentro de la skill: ${rutaResuelta}. Ejecuta el comando desde el proyecto o usa una ruta como ./results-accesibilidad.`);
  }
}

function requerirValor(argv, index, opcion) {
  const valor = argv[index];
  if (valor == null || valor.startsWith('-')) {
    throw new Error(`Falta el valor para ${opcion}.`);
  }

  return valor;
}

function validarWaitUntil(valor) {
  const permitidos = new Set(['domcontentloaded', 'load', 'networkidle']);
  if (!permitidos.has(valor)) {
    throw new Error('`--wait` debe ser `domcontentloaded`, `load` o `networkidle`.');
  }

  return valor;
}

function mostrarAyuda() {
  process.stdout.write(`Uso:
  node run-cadua.mjs [url ...]
  node run-cadua.mjs --file urls.txt

Opciones:
  --file, -f <ruta>        Lee URLs desde un fichero, una por linea
  --out, -o <carpeta>      Guarda los resultados JSON en una carpeta
                            Por defecto: ./results-accesibilidad si no usas --stdout
  --engine <motor>         Motor de comprobacion: cadua | axe | teclado | evidencias
                           (por defecto cadua)
  --axe                    Alias de --engine axe
  --teclado                Alias de --engine teclado. Recorre la pagina con el
                           tabulador; no pulsa Intro ni Espacio, asi que no
                           activa ningun control
  --forced-colors          Recorrido de teclado separado con colores forzados
  --componentes            Solo con --teclado. Abre ademas los componentes
                           declarados con data-bs-toggle (modal, dropdown,
                           collapse) para comprobar foco, Escape y retorno.
                           Activa esos disparadores, nunca los controles de
                           su interior
  --evidencias             Alias de --engine evidencias. Recoge capturas y fichas
                           de las imagenes con texto alternativo para resolver
                           imgManual. No emite veredicto ni activa nada
  --stdout                 Imprime el JSON por pantalla
  --allow-skill-output     Permite escribir dentro de la skill solo para pruebas internas
  --concurrency, -c <n>    Numero de paginas simultaneas (por defecto 2)
  --timeout <ms>           Timeout de navegacion y evaluacion (por defecto 30000)
  --settle-delay <ms>      Espera extra tras cargar la pagina (por defecto 750)
  --query <selector>       Selector CADUA (por defecto body)
  --router <ruta>          Lee rutas desde un router Vue y las convierte en URLs
  --routes <ruta>          Lee un manifiesto de rutas CADUA
  --base-url <url>         Base para resolver rutas relativas del router o manifiesto
  --wait <estado>          domcontentloaded | load | networkidle
  --headful                Ejecuta Chromium visible
  --screenshot-errors      Guarda capturas cuando haya errores o fallos
  --cas-login              Inicia sesion en CAS con CAS_USERNAME y CAS_PASSWORD
  --cas-login-url <url>    URL de login CAS (por defecto casdesa)
  --storage-state <ruta>   Lee o guarda estado de sesion de Playwright
  --raw                    Devuelve el JSON original de CADUA
  --pretty                 Formatea el JSON con indentacion
  --no-pretty              Minimiza el JSON impreso por pantalla
  -h, --help               Muestra esta ayuda

Ejemplos:
  node run-cadua.mjs https://www.ua.es/
  node run-cadua.mjs --file urls.txt --out results-accesibilidad
  node run-cadua.mjs https://www.ua.es/ https://web.ua.es/es/accesibilidad/ --stdout
`);
}
