#!/usr/bin/env node
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  crearManifiestoCaduaDesdeRouterSource,
  crearManifiestoPruebasDesdeUrls,
  inferirBaseUrlPruebas,
  leerRutasManifiestoCadua,
  urlsDesdeManifiesto
} from './lib/cadua-runner.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const skillDir = path.resolve(__dirname, '..', '..');
const defaultManifestPath = path.resolve(process.cwd(), 'results-accesibilidad', 'rutas.json');

try {
  const args = parseArgs(process.argv.slice(2));

  if (args.help) {
    mostrarAyuda();
    process.exit(0);
  }

  let manifiesto = null;
  const manifestPath = args.manifestPath ?? args.seedManifestPath ?? defaultManifestPath;
  const existeManifiesto = existsSync(manifestPath);

  if (existeManifiesto && !args.regenerateRoutes) {
    manifiesto = await leerRutasManifiestoCadua(manifestPath);
  } else if (args.routerPath) {
    const anterior = existeManifiesto ? await leerRutasManifiestoCadua(manifestPath) : null;
    const routerSource = await readFile(args.routerPath, 'utf8');
    const baseUrl = args.baseUrl ?? inferirBaseUrlPruebas(anterior?.pruebas);
    const generado = crearManifiestoCaduaDesdeRouterSource(routerSource, baseUrl);
    const urlsGeneradas = urlsDesdeManifiesto(generado.routes, generado.baseUrl);
    const manifiestoPruebas = crearManifiestoPruebasDesdeUrls(urlsGeneradas, anterior?.raw);
    await mkdir(path.dirname(path.resolve(manifestPath)), { recursive: true });
    await writeFile(manifestPath, `${JSON.stringify(manifiestoPruebas, null, 2)}\n`, 'utf8');
    manifiesto = await leerRutasManifiestoCadua(manifestPath);
  }

  if (!manifiesto) {
    throw new Error(`No existe ${manifestPath}. Indica --router para generar las rutas por primera vez.`);
  }

  const urls = urlsDesdeManifiesto(
    manifiesto.routes,
    args.baseUrl ?? manifiesto.baseUrl
  );

  if (args.urlsOutPath) {
    await writeFile(args.urlsOutPath, `${urls.join('\n')}\n`, 'utf8');
  }

  if (args.stdout || !args.urlsOutPath) {
    process.stdout.write(`${urls.join('\n')}\n`);
  }

  process.stderr.write(`Manifiesto CADUA: ${path.resolve(manifestPath)}\n`);
  if (args.urlsOutPath) {
    process.stderr.write(`URLs CADUA escritas en: ${path.resolve(args.urlsOutPath)}\n`);
  }
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}

function parseArgs(argv) {
  const args = {
    routerPath: null,
    manifestPath: null,
    seedManifestPath: null,
    regenerateRoutes: false,
    urlsOutPath: null,
    baseUrl: null,
    stdout: false,
    allowSkillOutput: false,
    help: false
  };

  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];

    switch (token) {
      case '--router':
        args.routerPath = requerirValor(argv, ++i, token);
        break;
      case '--manifest':
        args.manifestPath = requerirValor(argv, ++i, token);
        break;
      case '--base-url':
        args.baseUrl = requerirValor(argv, ++i, token);
        break;
      case '--seed-manifest':
        args.seedManifestPath = requerirValor(argv, ++i, token);
        break;
      case '--regenerate-routes':
        args.regenerateRoutes = true;
        break;
      case '--urls-out':
        args.urlsOutPath = requerirValor(argv, ++i, token);
        break;
      case '--allow-skill-output':
        args.allowSkillOutput = true;
        break;
      case '--stdout':
        args.stdout = true;
        break;
      case '--help':
      case '-h':
        args.help = true;
        break;
      default:
        throw new Error(`Opcion desconocida: ${token}`);
    }
  }

  validarRutaSalida(args.seedManifestPath, '--seed-manifest', args.allowSkillOutput);
  if (args.regenerateRoutes) {
    validarRutaSalida(args.manifestPath, '--manifest', args.allowSkillOutput);
  }
  if (args.manifestPath && args.seedManifestPath) {
    throw new Error('Usa --manifest o --seed-manifest, no ambos a la vez.');
  }
  validarRutaSalida(args.urlsOutPath, '--urls-out', args.allowSkillOutput);

  return args;
}

function validarRutaSalida(ruta, opcion, allowSkillOutput) {
  if (!ruta || allowSkillOutput) {
    return;
  }

  const rutaResuelta = path.resolve(ruta);
  const relativa = path.relative(skillDir, rutaResuelta);
  const estaDentroDeSkill = relativa === '' || (!relativa.startsWith('..') && !path.isAbsolute(relativa));

  if (estaDentroDeSkill) {
    throw new Error(`${opcion} no puede apuntar dentro de la skill: ${rutaResuelta}. Ejecuta el comando desde el proyecto o usa una ruta como ./results-accesibilidad.`);
  }
}

function requerirValor(argv, index, opcion) {
  const valor = argv[index];
  if (valor == null || valor.startsWith('-')) {
    throw new Error(`Falta el valor para ${opcion}.`);
  }

  return valor;
}

function mostrarAyuda() {
  process.stdout.write(`Uso:
  node generate-cadua-routes.mjs --router <router.ts> [--base-url <url>] [--urls-out <urls.txt>]
  node generate-cadua-routes.mjs [--manifest <rutas.json>] [--urls-out <urls.txt>]

Opciones:
  --router <ruta>         Lee el router al crear o regenerar las rutas
  --manifest <ruta>       Usa otro manifiesto (por defecto results-accesibilidad/rutas.json)
  --base-url <url>        Base para resolver rutas relativas
  --seed-manifest <ruta>  Escribe un manifiesto inicial desde el router
  --regenerate-routes     Regenera desde el router las rutas de todas las pruebas
  --urls-out <ruta>       Escribe una lista de URLs en un fichero
  --stdout                Imprime la lista de URLs por pantalla
  --allow-skill-output    Permite escribir dentro de la skill solo para pruebas internas
  -h, --help              Muestra esta ayuda
`);
}
