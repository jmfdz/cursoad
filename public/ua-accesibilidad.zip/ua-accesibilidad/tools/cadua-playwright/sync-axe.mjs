#!/usr/bin/env node
// Genera lib/axe.es.min.js a partir del paquete axe-core instalado, dejando el
// idioma espanol configurado dentro del propio fichero para que los mensajes
// salgan siempre en espanol sin tener que configurarlo en cada ejecucion.
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const paqueteAxe = path.join(__dirname, 'node_modules', 'axe-core');
const destino = path.join(__dirname, 'lib', 'axe.es.min.js');

try {
  const { version } = JSON.parse(await readFile(path.join(paqueteAxe, 'package.json'), 'utf8'));
  const bundle = await readFile(path.join(paqueteAxe, 'axe.min.js'), 'utf8');
  const locale = JSON.parse(await readFile(path.join(paqueteAxe, 'locales', 'es.json'), 'utf8'));

  const contenido = [
    `/* axe-core ${version} con el idioma espanol configurado.`,
    ' * Generado con `npm run sync-axe`; no editar a mano.',
    ' * El aviso de copyright y la licencia MPL-2.0 de Deque Systems van dentro',
    ' * del propio bundle y deben conservarse.',
    ' */',
    bundle.trim(),
    `axe.configure({ locale: ${JSON.stringify(locale)} });`,
    ''
  ].join('\n');

  await writeFile(destino, contenido, 'utf8');

  const sha = createHash('sha256').update(contenido).digest('hex');
  process.stdout.write(`axe-core ${version} en espanol escrito en ${destino}\n`);
  process.stdout.write(`SHA-256: ${sha}\n`);
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}
