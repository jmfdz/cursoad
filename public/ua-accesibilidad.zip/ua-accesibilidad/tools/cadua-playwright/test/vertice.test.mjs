import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { chromium } from 'playwright';
import { inspeccionarVerticeParaCadua } from '../lib/cadua-runner.mjs';

const core = await readFile(new URL('../vendor/cadua.core.global.js', import.meta.url), 'utf8');

for (const caso of ['con-subtitulos', 'subtitulos-tardios', 'sin-subtitulos', 'desconocido']) {
  test(`Vértice de otro origen: ${caso}`, async () => {
    const browser = await chromium.launch();
    try {
      const page = await browser.newPage();
      const frameUrl = `https://vertice.cpd.ua.es/player?id=${caso}`;
      const subtitulos = caso === 'con-subtitulos';
      const tardios = caso === 'subtitulos-tardios' ? 'setTimeout(() => subtitulos = true, 150);' : '';
      const shaka = caso === 'desconocido' ? '' : `<script>
        let subtitulos = ${subtitulos}; ${tardios}
        document.querySelector('video').ui = { getControls: () => ({ getPlayer: () => ({
          getVariantTracks: () => [{ audioId: null, videoId: 1, codecs: 'avc1.64001f,mp4a.40.2', mimeType: 'video/mp2t' }],
          getTextTracks: () => subtitulos ? [{ kind: 'subtitle', language: 'es', active: false }] : []
        }) }) };
      </script>`;
      await page.route('**/*', route => route.fulfill({ contentType: 'text/html', body: route.request().url() === frameUrl
        ? `<video controls></video>${shaka}`
        : `<!doctype html><html lang="es"><title>Multimedia</title><body><main><h1>Multimedia</h1><iframe title="Vídeo" src="${frameUrl}"></iframe></main></body></html>` }));
      await page.goto('https://pagina.example/');
      assert.equal(await page.evaluate(() => document.querySelector('iframe').contentDocument), null);
      const inspecciones = await inspeccionarVerticeParaCadua(page, core, { timeout: 500 });
      assert.equal(inspecciones.length, 1);
      assert.equal(inspecciones[0].url, frameUrl);
      assert.equal(inspecciones[0].subtitulos, caso === 'desconocido' ? null : caso !== 'sin-subtitulos');
      await page.addScriptTag({ content: core });
      const resultados = await page.evaluate(async inspeccionesVertice => {
        const r = await window.cadua.runAsync({ agregarErrores: false, inspeccionesVertice });
        return r.errores.filter(e => e.idTipoPrueba >= 109 && e.idTipoPrueba <= 112).map(e => ({ id: e.idTipoPrueba, contenido: e.contenido }));
      }, inspecciones);
      if (caso === 'con-subtitulos' || caso === 'subtitulos-tardios') assert.deepEqual(resultados, []);
      else {
        assert.equal(resultados.length, 1);
        assert.equal(resultados[0].id, 112);
        assert.match(resultados[0].contenido, caso === 'desconocido' ? /no se puede afirmar/ : /sin pistas/);
      }
      assert.equal(await page.frames().find(f => f.url() === frameUrl).evaluate(() => document.querySelector('video').paused), true);
    } finally { await browser.close(); }
  });
}

test('sin frames Vértice no carga ni ejecuta el inspector', async () => {
  const main = { url: () => 'https://pagina.example/' };
  const otro = { url: () => 'https://vertice.cpd.ua.es.example/player', evaluate: () => { throw new Error('No ejecutar'); } };
  assert.deepEqual(await inspeccionarVerticeParaCadua({ frames: () => [main, otro], mainFrame: () => main }, 'JavaScript deliberadamente inválido'), []);
});
