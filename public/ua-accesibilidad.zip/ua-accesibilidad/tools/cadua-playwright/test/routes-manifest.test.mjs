import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtemp, readFile, readdir, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import { crearInformeLote, escribirResultados, leerRutasManifiestoCadua } from '../lib/cadua-runner.mjs';

const execFileAsync = promisify(execFile);
const testDir = path.dirname(fileURLToPath(import.meta.url));
const generatorPath = path.resolve(testDir, '..', 'generate-cadua-routes.mjs');

test('crea, reutiliza y regenera un manifiesto sencillo', async () => {
  const cwd = await mkdtemp(path.join(os.tmpdir(), 'cadua-rutas-'));
  const routerPath = path.join(cwd, 'router.ts');
  const manifestPath = path.join(cwd, 'results-accesibilidad', 'rutas.json');

  await writeFile(routerPath, 'const routes = [{ path: "/" }, { path: "/inicial" }];\n', 'utf8');
  await execFileAsync(process.execPath, [generatorPath, '--router', routerPath, '--base-url', 'http://localhost:5173'], { cwd });

  const inicial = JSON.parse(await readFile(manifestPath, 'utf8'));
  assert.deepEqual(inicial.prueba1.rutas.map((ruta) => ruta.url), ['http://localhost:5173/', 'http://localhost:5173/inicial']);
  inicial.prueba1.usuario = 'usuario local';
  inicial.prueba1.contrasena = 'contrasena local';
  inicial.prueba1.rutas.push({ url: 'http://localhost:5173/manual' });
  inicial.prueba2 = { usuario: 'otro usuario', contrasena: 'otra contrasena', rutas: inicial.prueba1.rutas };
  await writeFile(manifestPath, `${JSON.stringify(inicial, null, 2)}\n`, 'utf8');

  await writeFile(routerPath, 'const routes = [{ path: "/" }, { path: "/nueva" }];\n', 'utf8');
  await execFileAsync(process.execPath, [generatorPath, '--router', routerPath], { cwd });
  const reutilizado = JSON.parse(await readFile(manifestPath, 'utf8'));
  assert.deepEqual(reutilizado.prueba1.rutas.map((ruta) => ruta.url), ['http://localhost:5173/', 'http://localhost:5173/inicial', 'http://localhost:5173/manual']);

  await execFileAsync(process.execPath, [generatorPath, '--router', routerPath, '--regenerate-routes'], { cwd });
  const regenerado = JSON.parse(await readFile(manifestPath, 'utf8'));
  assert.deepEqual(regenerado.prueba1.rutas.map((ruta) => ruta.url), ['http://localhost:5173/', 'http://localhost:5173/nueva']);
  assert.deepEqual(regenerado.prueba2.rutas, regenerado.prueba1.rutas);
  assert.equal(regenerado.prueba1.usuario, 'usuario local');
  assert.equal(regenerado.prueba1.contrasena, 'contrasena local');
});

test('lee varias pruebas con autenticacion y rutas propias', async () => {
  const cwd = await mkdtemp(path.join(os.tmpdir(), 'cadua-pruebas-'));
  const manifestPath = path.join(cwd, 'rutas.json');
  await writeFile(manifestPath, JSON.stringify({
    prueba1: {
      usuario: 'usuario',
      contrasena: 'secreto',
      rutas: [{ url: 'http://localhost:5173/' }]
    },
    prueba2: {
      usuario: 'otro',
      contrasena: 'otro secreto',
      rutas: [{ url: 'http://localhost:5173/admin' }]
    }
  }), 'utf8');

  const manifiesto = await leerRutasManifiestoCadua(manifestPath);
  assert.equal(manifiesto.pruebas.length, 2);
  assert.equal(manifiesto.pruebas[0].usuario, 'usuario');
  assert.equal(manifiesto.pruebas[0].contrasena, 'secreto');
  assert.equal(manifiesto.pruebas[1].rutas[0].url, 'http://localhost:5173/admin');
});

test('genera dos informes sencillos con campos publicos en espanol', async () => {
  const informe = crearInformeLote({
    herramienta: 'cadua-playwright',
    motor: 'cadua',
    prueba: 'prueba1',
    fechaGeneracion: '2026-07-17T10:00:00.000Z',
    resultados: [{
      urlOriginal: 'http://localhost:5173/formulario',
      urlFinal: 'http://localhost:5173/formulario',
      statusHttp: 200,
      validacion: { correcta: true, incidencias: [] },
      resultado: {
        errores: [{
          idTipoPrueba: 1,
          checkTypeInfo: { type: 'formElementWithoutLabel', text: 'Campo sin etiqueta', description: 'El campo necesita una etiqueta.' },
          html: '<input id="nombre">'
        }]
      }
    }]
  });

  assert.deepEqual(Object.keys(informe), [
    'herramienta', 'motor', 'prueba', 'fechaGeneracion', 'resumen', 'rutas',
    'urlsInvalidas', 'comprobacionesManualesPendientes', 'informe'
  ]);
  assert.equal(informe.resumen.totalRutas, 1);
  assert.equal(informe.resumen.rutasCorrectas, 0);
  assert.equal(informe.resumen.rutasConIncidencias, 1);
  assert.equal(informe.rutas[0].estadoHttp, 200);
  assert.equal(informe.rutas[0].errores[0].totalCasos, 1);
  assert.match(informe.informe, /## Resumen/);
  assert.match(informe.informe, /HTML incorrecto/);

  const outputDir = await mkdtemp(path.join(os.tmpdir(), 'cadua-informe-'));
  await escribirResultados(outputDir, informe);
  assert.deepEqual((await readdir(outputDir)).sort(), ['informe-accesibilidad.json', 'informe-accesibilidad.md']);
  const datosGuardados = JSON.parse(await readFile(path.join(outputDir, 'informe-accesibilidad.json'), 'utf8'));
  assert.equal(datosGuardados.informe, undefined);
  assert.equal(datosGuardados.rutas[0].errores[0].casos[0].htmlIncorrecto, '<input id="nombre">');
});


test('el generador avisa de expresiones sin resolver y no las escribe como URLs', async () => {
  const cwd = await mkdtemp(path.join(os.tmpdir(), 'cadua-expresiones-'));
  const routerPath = path.join(cwd, 'router.ts');
  await writeFile(routerPath, 'const routes = [{path: "/"}, {path: `/${bloque.slug}`}, {path: `/${bloque.slug}/${apartado.id}`}];');
  const { stderr } = await execFileAsync(process.execPath, [generatorPath, '--router', routerPath, '--base-url', 'http://localhost:5173'], { cwd });
  assert.match(stderr, /2 expresiones sin resolver/);
  assert.match(stderr, /Completa rutas.json manualmente/);
  const contenido = JSON.parse(await readFile(path.join(cwd, 'results-accesibilidad/rutas.json'), 'utf8'));
  assert.deepEqual(contenido.prueba1.rutas, [{ url: 'http://localhost:5173/' }]);
});
