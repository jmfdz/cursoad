import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile, mkdtemp, stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { chromium } from 'playwright';
import { ejecutarLoteCadua, comprobarComponentesConTeclado, evaluarContrasteFoco,
  crearManifiestoCaduaDesdeRouterSource, urlsDesdeManifiesto } from '../lib/cadua-runner.mjs';

const base = { outlineStyle: 'none', outlineWidth: '0px', outlineColor: 'rgb(0,0,0)',
  boxShadow: 'none', borderStyle: 'solid', borderWidth: '1px', borderColor: 'rgb(200,200,200)', backgroundColor: 'rgb(255,255,255)' };
const blanco = 'rgb(255,255,255)';
test('anillos visibles, ocultos, transparentes y geometria incierta', () => {
  const medir = (boxShadow, extra = {}) => evaluarContrasteFoco(base, { ...base, boxShadow, ...extra }, blanco);
  assert.equal(medir('rgb(255,255,255) 0px 0px 0px 2px, rgb(221,110,0) 0px 0px 0px 6px').suficiente, true);
  assert.equal(medir('rgb(255,255,255) 0px 0px 0px 2px, rgb(230,230,230) 0px 0px 0px 6px').suficiente, false);
  assert.equal(medir('rgb(255,255,255) 0px 0px 0px 6px, rgb(0,0,0) 0px 0px 0px 2px').suficiente, false);
  assert.equal(medir('rgb(255,255,255) 0px 0px 0px 4px', { borderStyle: 'none', backgroundColor: 'rgb(0,0,0)' }).suficiente, true);
  assert.equal(medir('none', { outlineStyle: 'solid', outlineWidth: '3px', outlineColor: 'rgba(0,0,0,0)' }), null);
  assert.equal(medir('rgba(0,0,0,0) 0px 0px 0px 6px'), null);
  assert.equal(medir('rgb(0,0,0) 1px 0px 4px 6px').pendiente, true);
  assert.equal(medir('rgb(230,230,230) 0px 0px 0px 6px', { outlineStyle: 'solid', outlineWidth: '3px', outlineColor: 'rgb(0,0,0)' }).suficiente, true);
});

test('no convierte expresiones del router en URLs', () => {
  const m = crearManifiestoCaduaDesdeRouterSource('const rutas = [{path: "/"}, {path: `/${bloque.slug}`}, {path: `/${bloque.slug}/${apartado.id}`}];', 'https://example.org');
  assert.deepEqual(urlsDesdeManifiesto(m.routes, m.baseUrl), ['https://example.org/']);
});

const css = await readFile(new URL('../node_modules/bootstrap/dist/css/bootstrap.css', import.meta.url), 'utf8');
const bootstrap = await readFile(new URL('../node_modules/bootstrap/dist/js/bootstrap.bundle.js', import.meta.url), 'utf8');
const modal = `<button data-bs-toggle="modal" data-bs-target="#modal">Abrir</button>
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="titulo"><div class="modal-dialog"><div class="modal-content">
<h2 id="titulo">Dialogo</h2><button data-bs-dismiss="modal">Cerrar</button><button>Cancelar</button></div></div></div>`;
async function servir(paginas, fn) {
  const server = createServer((req, res) => {
    if (req.url === '/imagen.svg') {
      res.setHeader('Content-Type', 'image/svg+xml');
      setTimeout(() => res.end('<svg xmlns="http://www.w3.org/2000/svg" width="868" height="200"><rect width="868" height="200" fill="red"/></svg>'), 150);
    } else if (paginas[req.url]) {
      res.setHeader('Content-Type', 'text/html');
      res.end(`<!doctype html><html lang="es"><title>Prueba</title><body>${paginas[req.url]}</body></html>`);
    } else { res.statusCode = 404; res.end(); }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  try { await fn(`http://127.0.0.1:${server.address().port}`); }
  finally { server.closeAllConnections(); await new Promise((resolve) => server.close(resolve)); }
}

test('Bootstrap real: transicion, foco en contenedor y componentes aislados', async () => {
  await servir({ '/modal': `<style>${css}.modal.fade .modal-dialog { transition-duration: .6s; }</style>
<button data-bs-toggle="collapse" data-bs-target="#panel" aria-expanded="false">Panel</button><div class="collapse" id="panel">Contenido</div>
${modal}<script>${bootstrap}</script>` }, async (url) => {
    const lote = await ejecutarLoteCadua([url + '/modal'], { engine: 'teclado', componentes: true, settleDelayMs: 0 });
    assert.deepEqual(lote.urlsInvalidas, []);
    assert.deepEqual(lote.rutas[0].errores.filter((e) => /keyboardDialog|keyboardFocusNotRestored/.test(e.codigo)), []);
    assert.ok(lote.rutas[0].teclado.componentes.some((m) => m.fase === 'apertura' && m.focoDentro && m.activo.includes('id="modal"')));
    assert.ok(lote.rutas[0].teclado.componentes.some((m) => m.fase === 'cierre' && m.oculto));
    assert.equal(lote.rutas[0].teclado.pendientes.some((p) => /inconclusa/.test(p)), false);
  });
});

test('modal defectuoso conserva los tres fallos independientes; sin evento queda pendiente', async () => {
  const browser = await chromium.launch();
  try {
    const page = await browser.newPage();
    await page.setContent(`<button data-bs-toggle="modal" data-bs-target="#mal" onclick="mal.style.display='block';mal.dispatchEvent(new Event('shown.bs.modal'))">Abrir</button>
<div id="mal" tabindex="-1" style="display:none"><button>Interior</button></div><button>Fuera</button>`);
    const r = await comprobarComponentesConTeclado(page, 150);
    for (const codigo of ['keyboardDialogFocusNotMoved', 'keyboardDialogNotTrapped', 'keyboardDialogNoEscape']) assert.ok(r.errores.some((e) => e.codigoPrueba === codigo), codigo);
    await page.setContent('<button data-bs-toggle="modal" data-bs-target="#mal">Abrir</button><div id="mal" style="display:none"></div>');
    const inconcluso = await comprobarComponentesConTeclado(page, 150);
    assert.deepEqual(inconcluso.errores, []);
    assert.ok(inconcluso.pendientes.some((p) => p.includes('inconclusa')));
  } finally { await browser.close(); }
});

test('evidencias concurrentes, lazy y descarga fallida', async () => {
  const contenido = '<div style="height:2500px"></div><img loading="lazy" src="/imagen.svg" alt="Rectangulo rojo"><img loading="lazy" src="/imagen.svg" alt="Otro rectangulo"><img src="/fallida.png" alt="No disponible">';
  await servir({ '/a': contenido, '/b': contenido }, async (url) => {
    const outputDir = await mkdtemp(path.join(tmpdir(), 'ua-evidencias-'));
    const lote = await ejecutarLoteCadua([url + '/a', url + '/b'], { engine: 'evidencias', outputDir, settleDelayMs: 0, concurrency: 2 });
    assert.deepEqual(lote.urlsInvalidas, []);
    const indice = JSON.parse(await readFile(path.join(outputDir, 'evidencias/imagenes.json'), 'utf8'));
    assert.equal(indice.imagenesConAlt.length, 6);
    const capturas = indice.imagenesConAlt.filter((f) => f.captura);
    assert.equal(new Set(capturas.map((f) => f.captura)).size, 4);
    for (const ficha of capturas) {
      assert.equal(ficha.anchura, 868);
      assert.equal(ficha.anchuraNatural, 868);
      assert.ok((await stat(path.join(outputDir, ficha.captura))).size > 100);
      assert.ok(ficha.url === url + '/a' || ficha.url === url + '/b');
    }
    for (const ficha of indice.imagenesConAlt.filter((f) => !f.captura)) assert.ok(ficha.motivoCapturaNoDisponible);
  });
});

test('forced-colors produce un recorrido identificado y separado del normal', async () => {
  await servir({ '/foco': '<style>button:focus{outline:3px solid transparent;box-shadow:0 0 0 3px #000}@media(forced-colors:active){button:focus{outline-color:Highlight;box-shadow:none}}</style><button>Accion</button>' }, async (url) => {
    const normal = await ejecutarLoteCadua([url + '/foco'], { engine: 'teclado', settleDelayMs: 0 });
    const forzado = await ejecutarLoteCadua([url + '/foco'], { engine: 'teclado', forcedColors: true, settleDelayMs: 0 });
    assert.equal(normal.rutas[0].teclado.modo, 'normal');
    assert.equal(forzado.rutas[0].teclado.modo, 'forced-colors');
    assert.deepEqual(normal.urlsInvalidas, []);
    assert.deepEqual(forzado.urlsInvalidas, []);
  });
});
