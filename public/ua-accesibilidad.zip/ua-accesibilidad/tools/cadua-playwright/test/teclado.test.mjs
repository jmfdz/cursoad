import assert from 'node:assert/strict';
import test from 'node:test';

import { crearInformeLote } from '../lib/cadua-runner.mjs';

test('los codigos del catalogo avanzado se enriquecen como los del catalogo CADUA', () => {
  const lote = crearInformeLote({
    motor: 'teclado',
    prueba: 'prueba1',
    resultados: [
      {
        urlOriginal: 'http://localhost:5173/usuarios',
        urlFinal: 'http://localhost:5173/usuarios',
        statusHttp: 200,
        ok: true,
        resultado: {
          datos: { url: 'http://localhost:5173/usuarios', candidatos: 4, alcanzados: 3 },
          errores: [
            { codigoPrueba: 'keyboardNotReachable', html: '<div role="button">Editar</div>', contenido: 'No se alcanza con el tabulador.' },
            { codigoPrueba: 'keyboardFocusNotVisible', html: '<button class="sin-foco">Guardar</button>', contenido: 'No cambia ningun estilo.' }
          ]
        }
      }
    ]
  });

  assert.equal(lote.motor, 'teclado');
  assert.equal(lote.resumen.totalErrores, 2);

  const codigos = lote.rutas[0].errores.map((error) => error.codigo);
  assert.deepEqual(codigos.sort(), ['keyboardFocusNotVisible', 'keyboardNotReachable']);

  const noAlcanzable = lote.rutas[0].errores.find((error) => error.codigo === 'keyboardNotReachable');
  assert.equal(noAlcanzable.nombre, 'Elemento interactivo al que no se llega con el tabulador');
  assert.equal(noAlcanzable.criterio, 'WCAG 2 2.1.1 (A)');
  assert.match(noAlcanzable.solucion, /tabindex/);
  assert.equal(noAlcanzable.casos[0].htmlIncorrecto, '<div role="button">Editar</div>');
});

test('el informe de teclado no mezcla codigos del catalogo oficial', () => {
  const lote = crearInformeLote({
    motor: 'teclado',
    resultados: [
      {
        urlOriginal: 'http://localhost:5173/',
        urlFinal: 'http://localhost:5173/',
        statusHttp: 200,
        ok: true,
        resultado: { datos: {}, errores: [{ codigoPrueba: 'keyboardTrap', html: '<div tabindex="0"></div>' }] }
      }
    ]
  });

  const familias = lote.rutas[0].errores.map((error) => error.codigo);
  assert.ok(familias.every((codigo) => codigo.startsWith('keyboard')));
  assert.match(lote.informe, /# Resultados de la comprobación de accesibilidad/);
});

test('los codigos de componentes tambien salen del catalogo avanzado', () => {
  const lote = crearInformeLote({
    motor: 'teclado',
    resultados: [
      {
        urlOriginal: 'http://localhost:5173/usuarios',
        urlFinal: 'http://localhost:5173/usuarios',
        statusHttp: 200,
        ok: true,
        resultado: {
          datos: {},
          errores: [
            { codigoPrueba: 'keyboardDialogFocusNotMoved', html: '<button data-bs-toggle="modal">Eliminar</button>' },
            { codigoPrueba: 'keyboardDialogNoEscape', html: '<button data-bs-toggle="modal">Eliminar</button>' },
            { codigoPrueba: 'keyboardExpandedNotUpdated', html: '<button data-bs-toggle="collapse">Filtros</button>' }
          ]
        }
      }
    ]
  });

  const porCodigo = new Map(lote.rutas[0].errores.map((error) => [error.codigo, error]));
  assert.equal(porCodigo.get('keyboardDialogFocusNotMoved').criterio, 'WCAG 2 2.4.3 (A)');
  assert.equal(porCodigo.get('keyboardExpandedNotUpdated').criterio, 'WCAG 2 4.1.2 (A)');

  // Escape no es una exigencia WCAG: el catalogo lo declara como buena practica
  // y el informe debe reflejar esa clasificacion sin reinterpretarla.
  assert.equal(porCodigo.get('keyboardDialogNoEscape').criterio, 'CADUA BUENA_PRACTICA');
});

test('el motor de evidencias no emite veredicto y declara lo pendiente', () => {
  const lote = crearInformeLote({
    motor: 'evidencias',
    resultados: [
      {
        urlOriginal: 'http://localhost:5173/galeria',
        urlFinal: 'http://localhost:5173/galeria',
        statusHttp: 200,
        ok: true,
        resultado: {
          datos: {
            imagenesConAlt: 3,
            imagenesDecorativas: 5,
            imagenesSinAlt: 1,
            carpetaEvidencias: 'evidencias',
            imagenes: [{ id: '001', alt: 'Vista del campus', captura: 'evidencias/imagen-001.png' }]
          },
          errores: []
        }
      }
    ]
  });

  assert.equal(lote.resumen.totalErrores, 0);
  assert.equal(lote.rutas[0].evidencias.imagenesConAlt, 3);
  assert.equal(lote.rutas[0].evidencias.imagenesDecorativas, 5);

  // El informe no puede dar la ruta por correcta: no se ha comprobado nada.
  assert.doesNotMatch(lote.informe, /Resultado: Correcto/);
  assert.match(lote.informe, /Pendiente de revisión/);
  assert.match(lote.informe, /Imágenes recogidas pendientes de revisar: 3/);
  assert.match(lote.comprobacionesManualesPendientes.join(' '), /imgManual/);
  assert.match(lote.comprobacionesManualesPendientes.join(' '), /no se corresponda con la imagen/);
});

test('las decorativas grandes se cuentan aparte de las imagenes con alt', () => {
  const lote = crearInformeLote({
    motor: 'evidencias',
    resultados: [
      {
        urlOriginal: 'http://localhost:5173/galeria',
        urlFinal: 'http://localhost:5173/galeria',
        statusHttp: 200,
        ok: true,
        resultado: {
          datos: {
            imagenesConAlt: 2,
            imagenesDecorativasGrandes: 1,
            imagenesDecorativas: 9,
            imagenesSinAlt: 0,
            carpetaEvidencias: 'evidencias',
            imagenes: [],
            decorativasGrandes: [{ id: 'd001', anchura: 400, altura: 300 }]
          },
          errores: []
        }
      }
    ]
  });

  assert.equal(lote.rutas[0].evidencias.imagenesDecorativasGrandes, 1);
  assert.match(lote.informe, /decorativas, por confirmar: 1/);
  assert.match(lote.comprobacionesManualesPendientes.join(' '), /aportan informacion/);
});

test('el contraste del indicador de foco solo falla cuando no hay lectura que lo salve', async () => {
  const { evaluarContrasteFoco, relacionContraste, analizarColor, componerSobre } =
    await import('../lib/cadua-runner.mjs');

  // Blanco contra negro: el maximo posible, 21:1.
  assert.equal(
    Math.round(relacionContraste(analizarColor('rgb(255,255,255)'), analizarColor('rgb(0,0,0)'))),
    21
  );

  // Un color con alfa se compone sobre el fondo antes de medirlo.
  assert.deepEqual(
    componerSobre(analizarColor('rgba(0,0,0,0.5)'), analizarColor('rgb(255,255,255)')),
    { r: 127.5, g: 127.5, b: 127.5, a: 1 }
  );

  const base = {
    outlineStyle: 'none', outlineWidth: '0px', outlineColor: 'rgb(0,0,0)',
    boxShadow: 'none', borderStyle: 'solid', borderWidth: '1px',
    borderColor: 'rgb(206,212,218)', backgroundColor: 'rgb(255,255,255)'
  };

  const contornoFlojo = { ...base, outlineStyle: 'solid', outlineWidth: '2px', outlineColor: 'rgb(200,200,200)' };
  const contornoFuerte = { ...base, outlineStyle: 'solid', outlineWidth: '2px', outlineColor: 'rgb(11,94,215)' };

  assert.equal(evaluarContrasteFoco(base, contornoFlojo, 'rgb(255,255,255)').suficiente, false);
  assert.equal(evaluarContrasteFoco(base, contornoFuerte, 'rgb(255,255,255)').suficiente, true);

  // Sin cambios no hay indicador que medir: de eso ya informa keyboardFocusNotVisible.
  assert.equal(evaluarContrasteFoco(base, base, 'rgb(255,255,255)'), null);

  // Si el fondo no se puede resolver, no se informa nada.
  assert.equal(evaluarContrasteFoco(base, contornoFlojo, null), null);
  assert.equal(evaluarContrasteFoco(base, contornoFlojo, 'rgba(0,0,0,0)'), null);
});

test('el informe no repite mas de cinco casos del mismo tipo', () => {
  const casos = Array.from({ length: 12 }, (unused, indice) => ({
    codigoPrueba: 'colorContrastUI',
    html: `<button id="b${indice}">Boton ${indice}</button>`
  }));

  const lote = crearInformeLote({
    motor: 'teclado',
    resultados: [{
      urlOriginal: 'https://x/', urlFinal: 'https://x/', statusHttp: 200, ok: true,
      resultado: { datos: {}, errores: casos }
    }]
  });

  assert.equal(lote.rutas[0].errores[0].totalCasos, 12);
  assert.match(lote.informe, /Y 7 casos más del mismo tipo/);
});
