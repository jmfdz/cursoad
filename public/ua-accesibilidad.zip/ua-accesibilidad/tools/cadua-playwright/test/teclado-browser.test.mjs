import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import test from 'node:test';

import { ejecutarLoteCadua } from '../lib/cadua-runner.mjs';

// Estados inicializados de componentes Bootstrap: no se carga el plugin ni se
// prueban aquí sus flechas. El motor solo debe evaluar el recorrido de Tab.
const paginasTeclado = {
  '/radios': `<form><fieldset><legend>Tipo</legend>
    <label><input class="form-check-input" type="radio" name="tipo" value="a" checked> A</label>
    <label><input class="form-check-input" type="radio" name="tipo" value="b"> B</label>
    </fieldset><button type="submit">Enviar</button></form>`,
  '/radios-sin-seleccion': `<form><fieldset><legend>Tipo</legend>
    <label><input type="radio" name="tipo" value="a"> A</label>
    <label><input type="radio" name="tipo" value="b"> B</label>
    </fieldset></form>`,
  '/pestanas': `<div class="nav nav-tabs" role="tablist" aria-label="Ficha">
    <button class="nav-link active" data-bs-toggle="tab" role="tab" aria-selected="true" aria-controls="panel-a">Datos</button>
    <button class="nav-link" data-bs-toggle="tab" role="tab" aria-selected="false" tabindex="-1" aria-controls="panel-b">Permisos</button>
    </div><div id="panel-a" role="tabpanel" tabindex="0">Datos personales</div>
    <div id="panel-b" role="tabpanel" hidden>Permisos del usuario</div>
    <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Acciones</button>
    <div class="dropdown-menu" hidden><button>Editar</button></div>`,
  '/inalcanzables': `<button>Inicio</button><div role="button" id="sin-teclado">Editar</div>`,
  // Un grupo alcanzado no debe ocultar un fallo en otro formulario con el mismo
  // name ni en otro grupo del propio formulario. Tab salta esos controles.
  '/grupos-distintos': `<form>
    <label><input id="entrada" type="radio" name="tipo" checked> A</label>
    <label><input id="otro-grupo" type="radio" name="otro" checked> B</label>
    </form><form><label><input id="otro-formulario" type="radio" name="tipo" checked> C</label></form>
    <button id="fin">Fin</button>
    <script>document.getElementById('entrada').addEventListener('keydown', (event) => {
      if (event.key === 'Tab') { event.preventDefault(); document.getElementById('fin').focus(); }
    });</script>`
};

const campos = Array.from({ length: 6 }, (_, i) =>
  `<label for="campo-${i}">Dato ${i}</label><input type="text" id="campo-${i}" name="campo-${i}">`).join('');

// Sin required, la aceptación de la prueba no puede atribuirse a ese atributo:
// aísla la detección del texto. No se modifica el motor ni el catálogo CADUA.
const paginasFormulario = {
  '/opcional': `<form><p>Todos los campos son obligatorios salvo los marcados como (opcional).</p>
    ${campos}<label for="telefono">Teléfono (opcional)</label><input id="telefono" type="tel"></form>`,
  '/asteriscos': `<form><p>Los campos marcados con * son obligatorios.</p>
    ${campos.replaceAll('</label>', ' *</label>')}</form>`,
  '/sin-indicacion': `<form>${campos}</form>`
};

async function servir(paginas, prueba) {
  const server = createServer((request, response) => {
    const cuerpo = paginas[request.url];
    if (cuerpo === undefined) {
      response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end('No encontrado');
      return;
    }
    response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    response.end(`<!doctype html><html lang="es"><title>Prueba de accesibilidad</title>
      <style>:focus { outline: 3px solid black; }</style><body>${cuerpo}</body></html>`);
  });
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  try {
    await prueba(`http://127.0.0.1:${server.address().port}`);
  } finally {
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
}

test('el recorrido de Tab respeta los grupos de radios y los estados Bootstrap', async () => {
  await servir(paginasTeclado, async (base) => {
    const lote = await ejecutarLoteCadua(Object.keys(paginasTeclado).map((ruta) => base + ruta), {
      engine: 'teclado', settleDelayMs: 0
    });
    assert.deepEqual(lote.urlsInvalidas, []);
    const porRuta = new Map(lote.rutas.map((ruta) => [new URL(ruta.urlSolicitada).pathname, ruta]));
    const inalcanzables = (ruta) => porRuta.get(ruta).errores
      .filter((error) => error.codigo === 'keyboardNotReachable')
      .flatMap((error) => error.casos.map((caso) => caso.htmlIncorrecto));
    for (const ruta of ['/radios', '/radios-sin-seleccion', '/pestanas']) {
      assert.deepEqual(inalcanzables(ruta), [], ruta);
    }
    assert.equal(inalcanzables('/inalcanzables').length, 1);
    assert.match(inalcanzables('/inalcanzables')[0], /sin-teclado/);
    assert.equal(inalcanzables('/grupos-distintos').length, 2);
    assert.ok(inalcanzables('/grupos-distintos').some((html) => html.includes('otro-grupo')));
    assert.ok(inalcanzables('/grupos-distintos').some((html) => html.includes('otro-formulario')));
  });
});

test('CADUA admite la indicacion de obligatoriedad con (opcional) y con asteriscos', async () => {
  await servir(paginasFormulario, async (base) => {
    const lote = await ejecutarLoteCadua(Object.keys(paginasFormulario).map((ruta) => base + ruta), {
      engine: 'cadua', settleDelayMs: 0
    });
    assert.deepEqual(lote.urlsInvalidas, []);
    for (const ruta of lote.rutas) {
      const sinIndicacion = new URL(ruta.urlSolicitada).pathname === '/sin-indicacion';
      assert.equal(ruta.errores.some((error) => error.codigo === 'formFieldsObligatoryOptional'), sinIndicacion, ruta.urlSolicitada);
    }
  });
});
