import assert from 'node:assert/strict';
import test from 'node:test';
import { createServer } from 'node:http';
import { tiposPrueba, obtenerTipoPrueba, ResultadoPrueba } from '../lib/modelos-cadua.mjs';
import { crearResumenLimpio, crearInformeLote, ejecutarLoteCadua } from '../lib/cadua-runner.mjs';

const camposResultado = ['idTipoPrueba', 'contenido', 'texto', 'html', 'itemAnterior', 'itemSiguiente'];

test('un catálogo de ejecución: core, documentos, externos y las 74 altas, sin IDs locales', () => {
  assert.equal(tiposPrueba.length, 190);
  assert.equal(new Set(tiposPrueba.map(t => t.idTipoPrueba)).size, 190);
  assert.equal(new Set(tiposPrueba.map(t => t.codigo)).size, 190);
  assert.deepEqual(tiposPrueba.filter(t => t.idTipoPrueba >= 117).map(t => t.idTipoPrueba),
    Array.from({ length: 74 }, (_, i) => i + 117));
  assert.deepEqual(tiposPrueba.filter(t => t.idTipoPrueba >= 79 && t.idTipoPrueba <= 105).map(t => t.gravedad), ['CRITICA', 'CRITICA', 'ALTA', 'MEDIA', 'MEDIA', 'MEDIA', 'CRITICA', 'ALTA', 'MEDIA', 'ALTA', 'CRITICA', 'MEDIA', 'MEDIA', 'MEDIA', 'MEDIA', 'ALTA', 'MEDIA', 'ALTA', 'MEDIA', 'MEDIA', 'ALTA', 'ALTA', 'ALTA', 'MEDIA', 'MEDIA', 'BAJA', 'BAJA']);
  assert.equal(tiposPrueba.some(t => t.idTipoPrueba >= 1001), false);
  for (const [codigo, id] of Object.entries({ imgGraphicWithoutName: 32,
    structureAriaMissingRequired: 33, structureControlWithoutName: 57,
    structureInvalidLang: 77, structureRefreshAutomatic: 116,
    keyboardNotReachable: 117, keyboardPositiveTabindex: 122,
    keyboardDialogNoEscape: 125, colorContrastUI: 128, supportAccessibilityReview: 190 })) {
    assert.equal(obtenerTipoPrueba(codigo).idTipoPrueba, id);
  }
  assert.equal(obtenerTipoPrueba('keyboardPositiveTabindex').nivelAuditoria, 'BUENA_PRACTICA');
  assert.equal(obtenerTipoPrueba('keyboardDialogNoEscape').nivelAuditoria, 'BUENA_PRACTICA');
  assert.equal(obtenerTipoPrueba('keyboardNotReachable').modo, 'interaction');
  assert.equal(obtenerTipoPrueba('colorContrastUI').modo, 'color');
  assert.equal(obtenerTipoPrueba('mediaAlternativeReview').nivelAuditoria, 'REVISION_MANUAL');
  assert.throws(() => obtenerTipoPrueba('reglaInexistente'), /sin catálogo/);
});

test('ResultadoPrueba usa TipoPrueba y serializa exactamente el DTO del core', () => {
  const resultado = new ResultadoPrueba('keyboardNotReachable', 'No se alcanza',
    'Editar', '<div role="button">Editar</div>', 'Anterior', 'Siguiente');
  assert.equal(resultado.tipoPrueba, obtenerTipoPrueba('keyboardNotReachable'));
  assert.equal(resultado.codigoPrueba, 'keyboardNotReachable');
  assert.deepEqual(Object.keys(resultado.toJSON()), camposResultado);
  assert.deepEqual(JSON.parse(JSON.stringify(resultado)), resultado.toJSON());
  assert.deepEqual(crearResumenLimpio({ datos: {}, errores: [resultado] }).errores,
    [resultado.toJSON()]);
});

test('el informe resuelve por código los IDs históricos y conserva el TipoPrueba', () => {
  const informe = crearInformeLote({ motor: 'teclado', resultados: [{
    urlOriginal: 'https://example.test/', urlFinal: 'https://example.test/', statusHttp: 200,
    validacion: { correcta: true, incidencias: [] },
    resultado: { datos: {}, errores: [{ idTipoPrueba: 1006,
      codigoPrueba: 'keyboardPositiveTabindex', contenido: 'tabindex="2"', html: '<button tabindex="2">Acción</button>' }] }
  }] });
  const grupo = informe.rutas[0].errores[0];
  assert.deepEqual(grupo.tipoPrueba, obtenerTipoPrueba('keyboardPositiveTabindex'));
  assert.equal(grupo.criterio, 'CADUA BUENA_PRACTICA');
  assert.equal(grupo.casos[0].resultadoPrueba.idTipoPrueba, 122);
  assert.deepEqual(Object.keys(grupo.casos[0].resultadoPrueba), camposResultado);
});

test('el core nuevo emite las sustituciones y mantiene contadores multimedia', async () => {
  const server = createServer((req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end('<!doctype html><html lang="not_a_language"><title>Prueba</title><body>'
      + '<svg role="img" width="40" height="40"><rect width="40" height="40"/></svg>'
      + '<div role="dialog">Contenido</div><audio controls src="data:audio/wav;base64,UklGRg=="></audio>'
      + '<input autocomplete="token-invalido" aria-label="Dato"></body></html>');
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try {
    const lote = await ejecutarLoteCadua([`http://127.0.0.1:${server.address().port}/`],
      { engine: 'cadua', settleDelayMs: 0 });
    assert.deepEqual(lote.urlsInvalidas, []);
    assert.equal(lote.rutas[0].datos.totalMultimedia, 1);
    assert.equal(lote.rutas[0].datos.erroresMultimedia, 1);
    const grupos = lote.rutas[0].errores;
    for (const codigo of ['imgGraphicWithoutName', 'structureControlWithoutName',
      'structureInvalidLang', 'formAutocompleteInvalid', 'mediaAudioWithoutTranscript']) {
      const grupo = grupos.find(g => g.codigo === codigo);
      assert.ok(grupo, codigo);
      assert.deepEqual(grupo.tipoPrueba, obtenerTipoPrueba(codigo));
      assert.equal(grupo.casos[0].resultadoPrueba.idTipoPrueba, obtenerTipoPrueba(codigo).idTipoPrueba);
    }
  } finally {
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
  }
});
