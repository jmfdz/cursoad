# Futuro de la skill

Ideas pendientes y decisiones ya tomadas, para no volver a discutirlas desde cero.
Este fichero no forma parte de las instrucciones de la skill: es la lista de trabajo.

## Siguiente paso

**Probar los motores avanzados en una aplicación .NET+Vue real.** `--teclado`,
`--teclado --componentes` y `--evidencias` solo se han validado contra páginas de
prueba y contra `www.ua.es`. Falta una aplicación con Bootstrap, menú lateral, tabla
con acciones por fila y sesión CAS, que es donde aparecerán los falsos positivos que
ua.es no ha destapado. El candidato más probable a dar ruido es
`keyboardNotReachable` con menús cerrados y componentes que se montan al vuelo.

De esa prueba debería salir la decisión sobre lo demás: si el motor aguanta, se
amplía; si genera ruido, primero se acota el selector de candidatos.

## Pendiente

### Contraste del indicador de foco sobre fondos no planos

Implementado el calculo determinista con `colorContrastUI`. Queda fuera lo que no se
deduce de los estilos: fondos con imagen o degradado y anillos que caen sobre dos
fondos distintos. Para eso haria falta la captura del elemento enfocado y sin
enfocar, que hoy no se hace.

### Extender el motor de evidencias

`linkManual` y `headingManual` son los otros dos códigos que el catálogo reserva para
revisión manual. La estructura ya está montada: solo cambia qué se recoge. Para
enlaces, el texto visible, el nombre accesible y el destino; para encabezados, el
esquema completo de la página.

También cabría aquí el contraste de texto sobre fotografía, que CADUA no puede
calcular y que se resuelve mirando una captura.

### Foco y regiones vivas tras operaciones CRUD

Es lo más valioso para las aplicaciones Vue de la UA y lo más caro: hay que guionizar
acciones por ruta. El manifiesto ya tiene reservado el hueco de las acciones previas,
documentado en el README de la herramienta como no implementado. Sería el punto de
entrada natural.

Exige resolver antes la cuestión de seguridad: activar controles que modifican datos
no puede ser el efecto secundario de pedir una revisión.

### Tope de disparadores en `--componentes`

Una tabla con cincuenta filas y un modal por fila provoca cincuenta ciclos de abrir y
cerrar, y los cincuenta son el mismo componente. Falta deduplicar por destino o poner
un tope. No se ha hecho porque todavía no se ha visto el caso en una aplicación real.

### Licencia del script CADUA

`vendor/cadua.core.global.js` no lleva cabecera de licencia ni versión, y no consta
en qué condiciones puede redistribuirse. Está anotado en `vendor/README.md`. Hay que
aclararlo con la Universidad de Alicante antes de publicar la skill fuera de este
repositorio.

### Documentos PDF, DOCX y PPTX

El catálogo oficial incluye pruebas para estos formatos que la skill no documenta.
Ahora mismo están declarados fuera de alcance en `SKILL.md`. Si alguna vez entran,
harían falta una referencia propia y un modo de trabajo distinto.

La generación y la comprobación de documentos se han llevado a la skill independiente
`ua-documentos-accesibles`, que ya genera y comprueba PDF, DOCX y PPTX con las reglas
CADUA.

## Descartado, y por qué

### Validador estático propio

Un script que recorriera los ficheros aplicando las reglas de las referencias. Se
descartó por dos motivos: duplicaría cada regla en el Markdown y en el código, que
acabarían desincronizándose; y su parte objetiva ya la comprueba mejor CADUA sobre el
HTML renderizado, mientras que lo que queda fuera depende del contexto y exige
criterio. La revisión de código la hace un agente leyendo, con el procedimiento y la
declaración de cobertura que describe `SKILL.md`.

### Orden de lectura comparando DOM, orden visual y árbol de accesibilidad

Es la comprobación que más falsos positivos produce y la menos accionable: señala una
discrepancia sin poder decir si molesta a alguien. Se retomaría solo si aparece un
caso concreto que la justifique.

### Flujos completos por teclado

Tareas del tipo "abre el buscador, busca becas, filtra y abre el primer resultado".
Exige guionizar cada aplicación y se rompe en cada cambio de interfaz. El coste de
mantenimiento no compensa frente a lo que ya cubren los motores actuales.

### Un agente generalista como núcleo

La propuesta original planteaba montar un agente con herramientas propias. Se
descartó a favor de extender la herramienta que ya existía, que aporta contexto de
navegador, login CAS, manifiesto de rutas y formato de informe. La IA se queda fuera
del código: la herramienta recoge evidencia determinista y quien interpreta es el
agente.
