# Colores

Aplica estas reglas al crear o revisar color, contraste, estados visuales y mensajes que usan color para transmitir información.

Pruebas CADUA de esta familia: `colorContrastAA`, `colorContrastLinks`, `colorContrastAALarge`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Contraste

- Texto corriente: contraste mínimo de 4.5:1 respecto al fondo.
- Texto grande: contraste mínimo de 3:1 respecto al fondo.
- Texto grande significa 18 puntos o más en peso normal, o 14 puntos o más en negrita.
- Texto normal significa cualquier texto por debajo de 18 puntos en peso normal y cualquier texto por debajo de 14 puntos en negrita.
- En CSS, usa como referencia 18 pt = 24 px y 14 pt = 18.5 px aproximadamente. Si hay duda por la fuente, el peso o el renderizado, trata el texto como normal.
- Enlaces y botones: contraste mínimo de 3:1, independientemente del tamaño del texto. Comprueba el texto, el borde, el relleno, el icono, el foco y los estados interactivos contra los colores adyacentes que correspondan.
- Imágenes de texto: aplican las mismas reglas que el texto corriente o grande: 4.5:1 si la imagen contiene texto normal y 3:1 si contiene texto grande. Evita usar imágenes de texto salvo logotipos, presentaciones esenciales o contenido personalizable.
- Iconos, gráficos y partes no textuales necesarias para entender el contenido o identificar un control: contraste mínimo de 3:1 contra los colores adyacentes.
- Comprueba el contraste en el estado real: normal, hover, focus, activo, deshabilitado si comunica información, y sobre fondos, imágenes o transparencias.
- No coloques texto sobre imágenes, degradados o fondos variables si no puedes garantizar contraste suficiente.
- Si usas opacidad o colores `rgba`, calcula el contraste con el color resultante sobre el fondo real.
- Para interfaces críticas o lectura prolongada, considera contraste superior, por ejemplo 7:1.

## No transmitir solo por color

- No uses el color como única forma de transmitir significado, estado, error, seleccion o prioridad.
- Evita instrucciones como "los campos en rojo son obligatorios" o "pulsa el botón verde"; acompaña el color con texto, icono, patron, posición o forma.
- En errores de formulario, combina color con mensaje textual, `aria-invalid`, resumen de errores o icono con texto.
- En gráficas y leyendas, combina color con etiquetas, patrones, formas o valores visibles.
- En enlaces dentro de texto, no dependas solo del color; usa subrayado u otro indicador visual persistente.
- En estados de componentes, acompaña colores de éxito, aviso o error con texto visible o nombre accesible.

## Revisión manual

- Comprueba que la información sigue entendiendose en escala de grises o sin distinguir colores.
- Comprueba contraste con herramientas sobre los colores finales renderizados, no solo sobre variables de diseño.
- Comprueba estados interactivos: foco visible, hover, seleccionado, deshabilitado y error.
- Comprueba que textos pequeños, iconos informativos y badges mantienen contraste suficiente.

## Ejemplos

```html
<!-- Evitar: significado solo por color -->
<p>Las solicitudes en rojo estan pendientes de revisar.</p>

<!-- Mejor: texto, no solo color -->
<p><strong>Pendientes de revisar:</strong> solicitudes marcadas con estado pendiente.</p>

<!-- Enlace distinguible sin depender solo del color -->
<a class="enlace-subrayado" href="/ayuda">Consultar ayuda</a>

<!-- Estado con texto, no solo color -->
<p class="estado-error">
  <span aria-hidden="true">!</span>
  No se ha podido guardar el formulario.
</p>
```
