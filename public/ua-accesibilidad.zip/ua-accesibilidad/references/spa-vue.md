# SPA con Vue: estructura, rutas y foco

Aplica esta referencia al revisar o construir la arquitectura de una aplicación Vue
de una sola página: `App.vue`, el router, la estructura de cada vista y la gestión
del foco. Para reglas de plantilla comprobables fichero a fichero, usa
`references/plantillas-vue.md`. Para componentes de Bootstrap dentro de Vue, usa
`references/bootstrap-vue.md`.

## Qué cambia en una SPA

En una web tradicional, al seguir un enlace el navegador carga un documento nuevo,
cambia el título y establece un contexto de navegación nuevo. Quien usa un lector de
pantalla percibe con facilidad que está en otra página.

Con Vue Router cambia el contenido de `<RouterView>`, pero el documento no se
recarga. Visualmente puede cambiar toda la pantalla; para las tecnologías de apoyo
sigue siendo el mismo documento y el foco sigue donde estaba.

Por eso una SPA tiene que resolver de forma explícita lo que en una navegación
tradicional daba el navegador: el título de cada vista, la posición del foco al
cambiar de ruta y el anuncio de los cambios de contenido.

El reparto de responsabilidades es este: HTML aporta la semántica, Bootstrap la
presentación y el comportamiento de sus componentes, Vue el estado y la
reactividad, y ARIA solo lo que HTML no cubre.

## Estructura de `App.vue`

`App.vue` contiene la estructura común que envuelve al contenido cambiante. La base
recomendable es:

```vue
<template>
  <nav aria-label="Enlaces para saltar">
    <a href="#contenido-principal" class="visually-hidden-focusable">
      Saltar al contenido principal
    </a>
  </nav>

  <header>
    <AppHeader />
    <MenuNavegacion />
  </header>

  <main id="contenido-principal" tabindex="-1" class="container py-4">
    <RouterView />
  </main>

  <footer class="container py-4">
    Universidad de Alicante - 2026
  </footer>

  <Notificaciones />
</template>
```

Puntos que hay que comprobar aquí:

- El enlace de salto es el primer elemento enfocable. Bootstrap ya aporta
  `visually-hidden-focusable`, así que no hacen falta estilos propios.
- El `<main>` es único, vive en `App.vue` y no se repite dentro de cada vista.
- El `<main>` lleva `id` y `tabindex="-1"`. El `tabindex="-1"` no lo mete en el
  recorrido normal del tabulador, pero permite llevarle el foco por código. Es el
  destino de seguridad cuando una vista no tiene `h1`.
- El componente de notificaciones vive aquí, fuera de `<RouterView>`, para que
  sobreviva a los cambios de ruta.

## Encabezados de cada vista

Cada vista debe tener un `h1` que identifique su contenido, y ese `h1` lleva
`tabindex="-1"` para poder recibir el foco al navegar:

```vue
<template>
  <div>
    <h1 tabindex="-1">Usuarios</h1>
    ...
  </div>
</template>
```

El nivel se escoge por estructura, nunca por tamaño. Si hace falta que un `h3` se
vea más pequeño, se usa una clase de Bootstrap: `<h3 class="h5">Filtros
avanzados</h3>` sigue siendo un `h3`.

## Título del documento

WCAG 2.4.2 exige que cada página tenga un título que describa su tema o propósito.
En una SPA el navegador no genera un `<title>` nuevo al cambiar de `RouterView`, así
que lo actualiza el router.

La convención del proyecto es declarar el título en `meta.TITULO` de cada ruta y
recurrir a `name` si no existe. Al revisar un router, comprueba que todas las rutas
navegables declaran `meta.TITULO`.

## Foco al cambiar de ruta

Sin gestión de foco, quien activa un enlace del menú se queda con el foco en la
navegación aunque la pantalla haya cambiado por completo.

El destino preferente es el `h1` de la vista nueva, porque la identifica. El
`<main>` queda como destino de seguridad.

```ts
import { nextTick } from 'vue'

let esCargaInicial = true

router.afterEach(async (to) => {
  document.title = `${to.meta.TITULO ?? String(to.name ?? 'Página')} | Accesibilidad`

  if (esCargaInicial) {
    esCargaInicial = false
    return
  }

  await nextTick()

  const target =
    document.querySelector<HTMLElement>('main h1, [role="main"] h1') ??
    document.querySelector<HTMLElement>('main, [role="main"]')

  if (target) {
    if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1')
    target.focus()
  }
})
```

Detalles que hay que verificar:

- `esCargaInicial` evita mover el foco en la primera carga, para que la aplicación
  empiece de forma normal por el principio de la página.
- `await nextTick()` espera a que la vista nueva esté en el DOM; sin él se busca un
  `h1` que todavía no existe.
- El `tabindex` que se añade sobre la marcha es solo una red de seguridad: tanto el
  `h1` de la vista como el `<main>` deben declararlo ya en su `template`.

## Foco cuando el contenido desaparece

`v-if` destruye el nodo. Si el foco estaba dentro, deja de existir y salta al
`<body>`, con lo que se pierde el punto de la interacción.

```ts
editando.value = false

await nextTick()

botonEditar.value?.focus()
```

Hay que plantearse dónde continúa la interacción siempre que se destruyan
formularios, paneles, filas, editores o controles dinámicos.

Caso típico de una tabla con acciones por fila: el foco está en el botón de la fila,
se abre el modal de edición, se guarda y la tabla se vuelve a renderizar. El botón
que tenía el foco puede haber sido destruido y creado de nuevo, así que hay que
esperar al renderizado y devolver el foco a ese botón si sigue existiendo. En una
eliminación el botón desaparece con la fila: entonces el destino tiene que ser algo
que siga existiendo, normalmente el `h1` de la vista.

## Ruta activa en el menú

La clase `active` de Bootstrap es presentación y no debe ser el único mecanismo que
comunica en qué sección se está. El enlace de la ruta actual expone además
`aria-current="page"`:

```vue
<RouterLink
  :to="opcion.ruta"
  class="nav-link"
  :class="{ active: esPaginaActual(opcion.ruta) }"
  :aria-current="esPaginaActual(opcion.ruta) ? 'page' : undefined"
>
  {{ opcion.texto }}
</RouterLink>
```

`undefined` omite el atributo en las rutas que no son actuales. También es válido
`aria-current="false"`: expresa que el enlace no es el actual y no es un error.
Consulta los distintos tipos de atributos en `references/plantillas-vue.md` y la
[definición de `aria-current`](https://www.w3.org/TR/wai-aria-1.2/#aria-current).

El `<nav>` que lo contiene necesita nombre accesible (`aria-label="Navegación
principal"`) y el menú se marca como lista real.

## Mensajes de estado

WCAG 4.1.3 exige que los mensajes de estado puedan determinarse por programa sin que
el foco se mueva. En una SPA esto afecta a guardados, recuentos, resultados de
búsqueda, estados de carga y paginación.

La distinción entre los dos roles no la decide el aspecto visual, sino la urgencia:

- `role="status"` para lo cotidiano: "Usuario guardado correctamente", "Mostrando
  del 1 al 10 de 50 resultados", "Cargando usuarios…".
- `role="alert"` para lo que exige atención inmediata: error grave, pérdida de
  conexión, sesión a punto de expirar, operación crítica fallida.

Una clase visual de alerta y `role="alert"` son cosas distintas. Un `alert-danger`
puede ser perfectamente un `role="status"`.

Los dos se escriben de forma diferente, y es la confusión más frecuente:

```vue
<!-- status: el contenedor permanece en el DOM y el contenido entra dentro -->
<div role="status">
  <p v-if="mensaje" class="alert alert-success">{{ mensaje }}</p>
</div>

<!-- alert: puede crearse entero con v-if -->
<p v-if="errorUrgente" class="alert alert-danger" role="alert">
  {{ errorUrgente }}
</p>
```

Un `role="status"` que se crea a la vez que su contenido no se anuncia en muchos
lectores. Un `role="alert"` sí, porque se anuncia al insertarse.

`role="status"` ya trae sus propiedades de región viva, así que normalmente no hace
falta repetir `aria-live`, `aria-atomic` ni `aria-relevant`.

En un estado de carga, el spinner es decorativo (`aria-hidden="true"`) y el texto
lleva la información real.

## Notificaciones

Un patrón que funciona bien es separar la presentación visual del anuncio:

- Los toasts visibles viven en un contenedor con `role="region"` y
  `aria-label="Notificaciones"`, y cada botón de cierre incluye el título en su
  nombre accesible: `:aria-label="`Cerrar: ${item.título}`"`.
- El anuncio se hace desde dos contenedores permanentes y ocultos con
  `visually-hidden`, uno con `role="status"` y otro con `role="alert"`, a los que
  el composable envía el texto según la urgencia.

Así la clase visual `toast` no decide cómo se anuncia el mensaje.

## Revisión

Al revisar una SPA, comprueba en este orden:

1. `App.vue`: enlace de salto, `<main id tabindex="-1">` único, notificaciones fuera
   de `<RouterView>`.
2. Router: todas las rutas con `meta.TITULO`, `afterEach` que actualiza el título y
   mueve el foco, guarda de carga inicial.
3. Cada vista: un `h1` con `tabindex="-1"`, jerarquía de encabezados correcta.
4. Menú: lista real, `aria-label` en el `nav`, `aria-current="page"`.
5. Acciones que destruyen nodos: hay destino de foco previsto.
6. Regiones vivas: contenedor de `role="status"` permanente, `role="alert"`
   reservado a lo urgente.
