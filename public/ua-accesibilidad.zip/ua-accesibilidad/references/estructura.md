# Estructura

Aplica estas reglas al crear o revisar documentos HTML, páginas completas, plantillas base, layouts y contenido renderizado en una aplicación web.

Pruebas CADUA de esta familia: `structureWithoutHeadings`, `structureManyBr`, `structureDivTextLong`, `structurePWithBrs`, `structureNoLang`, `structureEmptyLang`, `structureNoTitle`, `structureEmptyTitle`, `structureNoMainTag`, `structureNoSemanticTags`, `structureIframeWithoutTitle`, `structureUserEventIncorrect`, `structureTextJustify`, `structureFontSizeAbsolute`, `structureRepeatedID`, `structurePropertiesImportant`, `structureViewportAvailable`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Documento HTML

- Crea HTML5 válido y semántico: `<!doctype html>`, `<html>`, `<head>` y `<body>` bien formados.
- La etiqueta `<html>` debe tener `lang` con el idioma real de la página, por ejemplo `<html lang="es">`.
- La página debe tener un `<title>` no vacío, especifico y coherente con el contenido principal.
- Usa `<meta name="viewport" content="width=device-width, initial-scale=1">` o equivalente.
- No bloquees el zoom ni la escala del usuario: evita `user-scalable=no`, `maximum-scale=1` o configuraciones similares.
- Mantén `id` únicos en toda la página.

## Regiones y semántica

- La página debe tener un único contenido principal identificable con `<main>`; usa `role="main"` solo si no puedes usar `<main>`.
- En aplicaciones con layout, coloca `<main>` en el layout que envuelve la vista (`App.vue`, plantilla base, layout Razor, etc.), no repetido dentro de cada vista.
- Si no puedes confirmar donde vive el layout principal, pregunta antes de añadir `<main>` a todas las vistas.
- Usa secciones semánticas cuando aporten estructura real: `header`, `footer`, `nav`, `section`, `article`, `aside`.
- No sustituyas semántica por `div` y clases cuando exista un elemento HTML adecuado.
- Usa `nav` para bloques de navegación importantes; si el menú es una lista de enlaces, combina `nav` con `ul`/`ol` y `li`.
- Da nombre accesible a varios `nav` si aparecen en la misma página, por ejemplo `aria-label="Navegacion principal"`.
- No uses tablas para maquetar; reserva `table` para datos tabulares.

## Contenido

- Organiza textos largos con encabezados, párrafos, listas y secciones; no dejes grandes bloques de texto sin estructura.
- Usa la etiqueta que corresponda al contenido: `p`, `li`, `td`, `th`, `blockquote`, `dd`, etc.; no uses `div` como contenedor de texto largo cuando exista una etiqueta semántica adecuada.
- En filas de resultados, tarjetas o listados con títulos, URLs o descripciones largas, evita que el texto quede directamente dentro de un `div` genérico; usa una lista real (`ul`/`ol` + `li`), un `article`, un `p` o elementos de texto como `span`, `strong` y `small` cuando estén dentro de un enlace o botón.
- Si un contenedor acumula muchos elementos de resultado, enlaces, pestañas o filas, no lo dejes como `div` con texto agregado: conviertelo en `ul`/`ol` con `li`, o en una sección semántica adecuada.
- No simules párrafos con `br`, `div` o espacios.
- Evita múltiples `<br>` para separar contenido. Usa párrafos, listas, márgenes CSS o componentes semánticos.
- No uses texto justificado; alinea el texto de forma que mantenga lectura clara y espaciado regular.
- Define tamaños de texto con unidades relativas como `rem`, `em` o `%`; evita `px` y `pt` en contenido editable o escalable.
- No bloquees ajustes de lectura con `!important` en propiedades como `line-height`, `letter-spacing` o `word-spacing`.

## Contenido embebido e interacción

- Todo `iframe` o `frame` debe tener `title` descriptivo del contenido incrustado.
- Usa elementos interactivos nativos: `<a href>` para navegar y `<button>` para acciones.
- No simules botones o enlaces con `div`, `span` u otros elementos con `onclick`; si no hay alternativa, deben tener rol, nombre accesible y soporte completo de teclado.
- Asegura que cualquier funcionalidad disponible con raton también funciona con teclado.

## Revisión manual

- Comprueba que el idioma, el título, el viewport y el contenido principal existen en la página final, no solo en el componente aislado.
- Revisa el esquema de regiones y encabezados para confirmar que permite entender la página sin ver el diseño.
- Comprueba que el contenido copiado de editores externos no arrastra estilos fijos, saltos de línea artificiales o texto largo dentro de `div` sin semántica.
- Comprueba que la estructura semántica coincide con la función real de cada bloque.

## Ejemplos

```html
<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biblioteca universitaria</title>
  </head>
  <body>
    <header>
      <nav aria-label="Navegacion principal">
        <ul>
          <li><a href="/servicios">Servicios</a></li>
          <li><a href="/horarios">Horarios</a></li>
        </ul>
      </nav>
    </header>
    <main>
      <h1>Biblioteca universitaria</h1>
      <p>Consulta los servicios, horarios y recursos disponibles.</p>
    </main>
    <footer>...</footer>
  </body>
</html>

<!-- Evitar: bloquea el zoom -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<!-- Evitar: parrafos simulados con saltos -->
<p>Primer bloque<br><br>Segundo bloque</p>

<!-- Mejor -->
<p>Primer bloque</p>
<p>Segundo bloque</p>

<!-- Iframe con nombre accesible -->
<iframe src="/video" title="Video de presentacion de la biblioteca"></iframe>
```
