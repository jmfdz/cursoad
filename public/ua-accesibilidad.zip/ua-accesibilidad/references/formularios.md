# Formularios

Aplica estas reglas al crear o revisar formularios, campos de entrada, grupos de opciones, controles de seleccion y botones.

Pruebas CADUA de esta familia: `formElementWithoutLabel`, `formElementWithEmptyLabel`, `formLabelNotHidden`, `formFieldsObligatoryOptional`, `formLabelledByNotHidden`, `formTooManyRadio`, `formTooManyCheck`, `formFieldsetNeeded`, `formHeaders`, `formFieldsetNoLegend`, `formGroupHasNoAria`, `formSelectTooManyOpt`, `formSelectConsecutiveChar`, `formOptHasNoLabel`, `formBtnHasNoText`, `formLabelDifferentFromContent`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Campos y etiquetas

- En formularios reales, incluye los campos dentro de un `<form>` y proporciona un botón de envío nativo.
- Usa `<button type="submit">` para enviar el formulario; permite enviar con Enter y mantiene el comportamiento nativo.
- Prefiere colocar el botón de envío dentro del `<form>`; si debe estar fuera por maquetación, asócialo con `form="idFormulario"`.
- Reserva controles fuera de `<form>` para casos justificados, como filtros reactivos o ajustes que no se envian.
- Todo campo visible debe tener una etiqueta descriptiva asociada.
- Prefiere `<label for="id">` asociado a un `id` único del campo.
- La etiqueta no debe estar vacía ni oculta con `display:none`, `visibility:hidden` o mecanismos equivalentes.
- El `placeholder` no sustituye a la etiqueta.
- Usa `aria-label` o `aria-labelledby` solo cuando no puedas usar una etiqueta visible; si hay texto visible, el nombre accesible debe conservarlo.
- Mantén un orden lógico de lectura y tabulacion; no uses `tabindex` positivo para forzarlo.
- No elimines el indicador visible de foco (`outline`) sin proporcionar un foco alternativo claro.

## Grupos

- Agrupa campos relacionados con `<fieldset>` y un `<legend>` como primer hijo con texto descriptivo.
- Como recomendacion de creación, agrupa siempre radios y checkboxes relacionados con `<fieldset>` y `<legend>`, aunque el grupo sea pequeño.
- Los radios de una misma pregunta deben compartir `name`; usa `fieldset` o, si no es posible, `role="radiogroup"`.
- Los checkboxes relacionados deben estar en `fieldset` o, si no es posible, `role="group"`.
- Si usas `role="group"` o `role="radiogroup"`, proporciona nombre con `aria-label` o `aria-labelledby` que apunte a texto existente.
- No uses encabezados dentro de formularios para simular apartados; usa `fieldset`/`legend` o grupos con nombre accesible.
- Si necesitas separar visualmente una sección semántica dentro del formulario, usa el elemento semántico que corresponda y aplica una clase de encabezado como `h2`, `h3`, `h4` o similar para conservar la jerarquía visual sin cambiar el significado HTML.
- Cuando un `fieldset` actúe como encabezado de una sección, el `legend` puede llevar una clase de encabezado como `h2`, `h3`, `h4` o similar para que se vea con el tamaño adecuado según la jerarquía de la página, manteniendo el `legend` como primer hijo del `fieldset`.

## Obligatoriedad, ayuda y errores

- Indica claramente si los campos son obligatorios u opcionales, especialmente en formularios extensos.
- Al crear un formulario con mayoría de campos obligatorios, prefiere indicar
  «Todos los campos son obligatorios salvo los marcados como (opcional)» al inicio,
  dentro del `<form>`, y añadir `(opcional)` a las etiquetas correspondientes.
  Si todos son obligatorios u opcionales, dilo expresamente. No es necesario
  añadir un asterisco a cada campo obligatorio ni sustituir un patrón existente
  con asteriscos que ya esté bien explicado.
- Conserva `required` en los controles nativos obligatorios compatibles; en un
  control personalizado, comunica el estado con `aria-required` cuando su rol lo
  admita y mantén la validación. Estos atributos no sustituyen la indicación
  visible del criterio de obligatoriedad.
- No dependas solo de color, asteriscos sin explicar o posición visual para indicar obligatoriedad.
- Si un asterisco visible es la marca que explica la obligatoriedad, no lo ocultes con `aria-hidden="true"`; debe estar disponible para tecnologías de apoyo o debe existir un texto equivalente asociado al campo.
- Puedes ocultar un asterisco con `aria-hidden="true"` solo si es decorativo y la obligatoriedad ya está comunicada de otra forma accesible, por ejemplo con `required`, texto visible como "obligatorio" o ayuda asociada con `aria-describedby`.
- Relaciona textos de ayuda o error con el campo mediante `aria-describedby`.
- Marca campos invalidos con `aria-invalid="true"` cuando haya error.
- Los mensajes de error deben explicar cómo corregir el dato.
- En formularios renderizados por servidor tras recargar la página, el resumen de errores puede ir antes del formulario.
- En formularios AJAX, coloca el resumen de errores después del botón de envío para que aparezca en el flujo tras la acción.
- En validación AJAX, usa `role="alert"` en el resumen de errores para que se anuncie al actualizarse.
- Si es viable, mueve el foco al resumen de errores tras validar para que la persona pueda revisarlo y saltar a los campos afectados.

La prueba [`formFieldsObligatoryOptional`](https://web.ua.es/es/accesibilidad/cadua/formularios.html#formFieldsObligatoryOptional)
busca indicaciones de obligatoriedad u opcionalidad en formularios de más de cinco
campos; no exige asteriscos. La copia del motor incluida también reconoce
`required` al inspeccionar el HTML descendiente del formulario. La búsqueda es de
subcadena sobre ese HTML y distingue mayúsculas: «Obligatorio» al principio de una
frase no cuenta si la forma en minúscula no aparece en ningún otro sitio. Esto no
comprueba por sí solo que la instrucción sea visible ni que cada campo esté bien
marcado.
En revisión de código, comprueba la instrucción general y las etiquetas antes de
afirmar que faltan marcas: `(opcional)` con la instrucción anterior es un patrón
válido. Se conservan el código y la clasificación CADUA de la prueba.

## Selects y opciones

- Si un `<select>` tiene muchas opciones, agrupa opciones relacionadas con `<optgroup>`.
- Todo `<optgroup>` debe tener `label` no vacío.
- No simules grupos dentro de `<option>` con separadores como `---`, `___`, `***` o `...`.
- En listas largas de números consecutivos puede no hacer falta `optgroup`; en listas largas heterogéneas, si.

## Botones

- Todo botón debe tener texto o nombre accesible que describa la acción.
- En `<button>`, prefiere texto visible; si es solo icono, usa `aria-label` en el botón y marca el icono decorativo.
- En `input type="button"` o `input type="submit"`, usa `value` descriptivo o un nombre accesible equivalente.
- Si usas `aria-label` o `aria-labelledby` en un botón con texto visible, el nombre accesible debe conservar ese texto visible.

## Envío con JavaScript

- En Vue, usa `@submit.prevent="enviar"` en el `<form>` cuando el envío se gestione con JavaScript, para conservar la semántica sin recargar la página.
- Mantén el botón como `type="submit"` para que Enter active el envío del formulario.

## Revisión manual

- Comprueba que cada campo se entiende sin depender del contexto visual.
- Comprueba que los grupos tienen una pregunta o título que se anuncia antes de sus opciones.
- Comprueba que el recorrido con teclado sigue el orden visual y que el foco se ve.
- Comprueba que los errores se anuncian y quedan asociados al campo correspondiente.
- Comprueba que los selects largos no obligan a recorrer opciones sin agrupación.

## Ejemplos

```html
<!-- Formulario con envio nativo y etiqueta visible -->
<form action="/solicitudes" method="post">
  <label for="consulta">Consulta</label>
  <textarea id="consulta" name="consulta"></textarea>
  <button type="submit">Enviar consulta</button>
</form>

<!-- Radios o checkboxes relacionados: fieldset y legend -->
<fieldset>
  <legend class="h3">Tipo de usuario</legend>
  <label><input type="radio" name="tipo" value="estudiante"> Estudiante</label>
  <label><input type="radio" name="tipo" value="pdi"> PDI</label>
</fieldset>

<!-- Seccion semantica con jerarquia visual -->
<section>
  <h2 class="h4">Datos del sitio</h2>
  <p>Contenido de la seccion...</p>
</section>

<!-- Boton submit fuera del formulario -->
<form id="form-busqueda" action="/buscar" method="get">
  <label for="q">Buscar</label>
  <input id="q" name="q" type="search">
</form>
<button type="submit" form="form-busqueda">Buscar</button>

<!-- AJAX: resumen de errores despues del boton -->
<form @submit.prevent="enviar">
  <label for="correo">Correo electronico</label>
  <input id="correo" name="correo" type="email" aria-describedby="correo-error" aria-invalid="true">
  <button type="submit">Enviar</button>
  <section role="alert" tabindex="-1">
    <p>Revisa los errores del formulario.</p>
    <ul>
      <li><a href="#correo">Introduce un correo electronico valido.</a></li>
    </ul>
  </section>
</form>

<!-- Patrón preferente cuando la mayoría de campos son obligatorios -->
<form action="/contacto" method="post">
  <p>Todos los campos son obligatorios salvo los marcados como (opcional).</p>
  <div class="mb-3">
    <label for="contacto-email" class="form-label">Correo electrónico</label>
    <input id="contacto-email" name="email" type="email" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="contacto-telefono" class="form-label">Teléfono (opcional)</label>
    <input id="contacto-telefono" name="telefono" type="tel" class="form-control">
  </div>
  <button type="submit" class="btn btn-primary">Enviar consulta</button>
</form>

<!-- Alternativa válida: el asterisco visible no se oculta si es parte de la explicación -->
<p>Los campos marcados con * son obligatorios.</p>
<label for="email">Correo electronico *</label>
<input id="email" name="email" type="email" required>

<!-- Alternativa: asterisco decorativo y texto accesible asociado -->
<label for="telefono">Telefono <span aria-hidden="true">*</span></label>
<input id="telefono" name="telefono" type="tel" required aria-describedby="telefono-ayuda">
<p id="telefono-ayuda">Campo obligatorio.</p>

<!-- Select con grupos reales -->
<label for="estudios">Estudios</label>
<select id="estudios" name="estudios">
  <optgroup label="Grados">
    <option>Ingenieria Informatica</option>
  </optgroup>
  <optgroup label="Masteres">
    <option>Desarrollo de Software</option>
  </optgroup>
</select>

<!-- Boton solo con icono -->
<button type="button" aria-label="Buscar">
  <span class="icon-search" aria-hidden="true"></span>
</button>
```
