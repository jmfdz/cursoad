# CADUA y AXE

## Motores

- CADUA es el motor por defecto. Usa `vendor/cadua.core.global.js` y enriquece cada
  error con `lib/catalogo-de-pruebas.json` (`codigoPrueba` y `catalogoPrueba`, con
  id, código, familia, nombre, descripción, referencia, criterio y nivel).
- AXE es opcional y solo debe ejecutarse si el usuario lo pide expresamente
  ("con AXE", "axe-core", `--engine axe`, `--axe`). Usa `lib/axe.es.min.js`,
  axe-core con el idioma español ya configurado dentro del propio fichero. Sus resultados se normalizan al mismo
  lote JSON, pero sus criterios proceden de axe-core, no del catálogo CADUA.
- No sustituyas CADUA por AXE sin esa indicación explícita.

### Motor de teclado (modo avanzado)

`--engine teclado` o `--teclado` recorre cada ruta pulsando el tabulador y comprueba
lo que ningún motor del catálogo alcanza: controles a los que no se llega, trampas
de teclado, elementos no visibles que reciben el foco, ausencia de indicador de foco
y `tabindex` positivos.

El recorrido se limita a Tab. En radios nativos basta con alcanzar una opción del
mismo grupo; las demás se operan con flechas. Las pestañas Bootstrap inactivas con
`tabindex="-1"` quedan fuera del recorrido. No fuerces todas las opciones a
`tabindex="0"`: conserva el patrón del componente. El funcionamiento con flechas
y la activación siguen como comprobación manual pendiente, incluso si no hay
errores automáticos. Véase la
[guía de teclado W3C](https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/).

Ejecútalo **solo si el usuario lo pide expresamente**, igual que AXE. No lo añadas
por tu cuenta a una revisión normal.

Es de solo lectura: pulsa únicamente el tabulador, nunca Intro ni Espacio, así que
no activa botones ni envía formularios. Mantenlo así; en estas aplicaciones una
pulsación de más se ejecuta sobre datos reales con una sesión real.

Comprueba además el contraste del indicador de foco, `colorContrastUI` (WCAG 1.4.11,
3:1). El cálculo es determinista: lee el color del contorno, la sombra, el borde o el
fondo que cambia al recibir el foco, compone su transparencia sobre el color real de
detrás y mide la relación de contraste.

El cálculo conserva los distintos indicadores y descarta colores transparentes.
Para sombras admite anillos concéntricos opacos sin desenfoque: analiza todas las
capas, excluye las tapadas y compara sus adyacencias. Cuando la geometría o el
fondo no se puede resolver, registra una comprobación pendiente.

`--teclado --forced-colors` ejecuta un recorrido separado con colores forzados.
La CLI guarda su informe en la subcarpeta `forced-colors` de la salida, sin
sustituir el informe normal. El modo figura en `rutas[].teclado.modo`; la emulación
no sustituye la comprobación manual en el sistema del usuario.

Sus códigos viven en `lib/catalogo-de-pruebas-avanzadas.json`, separado del catálogo
oficial, y siguen su misma nomenclatura por si algún día se incorporan a CADUA.

Como cada ejecución usa un solo motor, el informe de teclado contiene solo estos
códigos y no se mezcla con el del catálogo oficial. No los combines a mano en un
mismo listado: preséntalos como un informe aparte que complementa al de CADUA.
Si ejecutas varios motores, usa una carpeta `--out` distinta para cada uno y evita
que sus informes se sobrescriban.

Qué no cubre: no comprueba el comportamiento del foco tras operaciones CRUD ni las
regiones vivas, que siguen siendo comprobación manual.

#### Componentes: `--componentes`

Añadido a `--teclado`, abre además los componentes declarados con `data-bs-toggle`
(`modal`, `dropdown`, `collapse`) y comprueba que el foco entra en el diálogo, que
no se escapa al contenido de detrás, que Escape lo cierra, que el foco vuelve al
control que lo abrió y que `aria-expanded` cambia al abrir.

El motor espera `shown.bs.modal` y `hidden.bs.modal` del destino concreto,
registrando los escuchadores antes de activarlo y con un plazo de 2,5 segundos.
Guarda los estados y tiempos en `rutas[].teclado.componentes`; las aperturas no
confirmadas quedan pendientes. Prueba Tab y Mayús+Tab, y recarga la ruta entre
los disparadores para no arrastrar estados. No activa pestañas.

Cinco códigos más: `keyboardDialogFocusNotMoved`, `keyboardDialogNotTrapped`,
`keyboardDialogNoEscape`, `keyboardFocusNotRestored` y `keyboardExpandedNotUpdated`.
El de Escape está declarado como buena práctica de CADUA, no como criterio WCAG,
porque WCAG no exige esa tecla en concreto.

Esta opción sí activa controles, aunque solo los que llevan `data-bs-toggle`, que
por definición abren o cierran interfaz. Nunca pulsa un control del interior del
componente, así que no guarda, no envía ni elimina nada. Aun así, no la actives por
tu cuenta sobre un entorno con datos que importen sin decírselo antes al usuario.

### Motor de evidencias (modo avanzado)

`--engine evidencias` o `--evidencias` no comprueba nada por su cuenta: recoge el
material que hace falta para resolver las pruebas que el catálogo marca como
`REVISION_MANUAL`. De momento, imágenes.

Por cada imagen **con texto alternativo no vacío** guarda un recorte en
`results-accesibilidad/evidencias/` y una ficha en `evidencias/imagenes.json` con el
`alt`, su longitud, `src`, dimensiones, si está dentro de un enlace o botón, el
destino del enlace y el texto visible de alrededor.

Cada ruta tiene una carpeta `evidencias/ruta-NNNN/`; el índice `imagenes.json` se
escribe una vez al finalizar el lote y cada ficha lleva la URL de origen.
Se inicia la carga de las imágenes diferidas antes de clasificarlas. Al capturar,
se desplazan al viewport, se espera la decodificación con plazo máximo y se vuelven
a medir. Una carga o captura fallida deja `captura: null` y el motivo en la ficha.

Qué deja fuera a propósito:

- Las que no tienen `alt`: eso ya es `imgWithoutAlt`, determinista.
- La longitud del `alt` no se juzga aquí; el límite de 150 caracteres ya es
  `imgLong`.
- Casi todas las imágenes con `alt=""`, que son decorativas por decisión de quien
  las puso. Revisarlas llenaría el informe de iconos y separadores.

La excepción son las **decorativas grandes**: una imagen suelta, visible, de al menos
150×150 px y marcada con `alt=""` es sospechosa de ser informativa mal marcada, y ese
fallo no lo detecta ninguna herramienta porque el HTML es válido. Se recogen en una
lista aparte, `decorativasGrandes`. No entran las que están dentro de un enlace o
botón: ahí el `alt` vacío es lo correcto si el control tiene texto, y si no lo tiene
ya es `imgBadLink`.

Esa lista se revisa con otra pregunta: no si el texto alternativo describe la imagen,
sino si esa imagen aporta información y no debería ser decorativa. Si en una web real
sale ruido, se sube el umbral de tamaño.

#### Cómo revisar la evidencia

Abre los recortes de la carpeta y compáralos con su ficha. Por cada imagen, un
veredicto de tres:

- **Concuerda**: no se informa nada.
- **Dudoso**: queda como `imgManual` pendiente. Muestra el recorte, el `alt` actual
  y un alternativo recomendado, y que decida la persona. Sin veredicto.
- **No concuerda**: el texto no tiene nada que ver con la imagen. Solo esto es
  hallazgo.

El listón es deliberadamente bajo: **no persigas el texto alternativo perfecto**. Un
alternativo mejorable no es un error; como mucho se sugiere una redacción al lado de
la actual. Un juicio quisquilloso convierte el informe en ruido.

`imgManual` sigue siendo `REVISION_MANUAL` en el catálogo y así debe aparecer en el
informe. Lo que aporta el agente es evidencia y una recomendación, no el cierre de
la prueba.

## Comandos

Ejecuta siempre desde la raíz del proyecto que se está revisando, no desde el
directorio de la skill. Las rutas relativas se resuelven contra ese directorio.

| Situación | Comando |
| --- | --- |
| Una o varias URLs | `run-cadua.mjs <url> [<url>...]` |
| Lista de URLs en fichero | `run-cadua.mjs --file urls.txt` |
| Proyecto completo | `run-cadua-auto.mjs` |
| Crear o revisar el manifiesto sin navegador | `generate-cadua-routes.mjs` |
| Recoger evidencia de imágenes | `run-cadua.mjs <url> --evidencias` |

`run-cadua-auto.mjs` es el camino normal para una aplicación: recorre manifiesto o
router, genera las URLs y ejecuta el motor. `run-cadua.mjs` es el atajo para URLs
sueltas, aunque también acepte `--router` y `--routes`.

## Manifiesto de pruebas

- Para un proyecto completo, reutiliza `results-accesibilidad/rutas.json` si ya
  existe; no vuelvas a inspeccionar el router.
- Crea el manifiesto desde el router solo la primera vez. Regenéralo únicamente
  con `--regenerate-routes`, y solo si el usuario lo pide o si el manifiesto ya no
  representa la aplicación. La regeneración reemplaza las rutas de todas las
  pruebas y conserva sus credenciales.
- Cada propiedad principal del manifiesto es una prueba con `usuario`,
  `contrasena` y `rutas`. Cada ruta es un objeto con una propiedad `url`. Con
  usuario y contraseña vacíos, la prueba se ejecuta sin autenticación. Usa varias
  pruebas para recorrer las rutas con distintas identidades.
- Se pueden añadir rutas manuales directamente al manifiesto; una ejecución normal
  no las sobrescribe.
- `tools/cadua-playwright/rutas.example.json` es el ejemplo y usa valores ficticios.

## Resultados

- Los resultados pertenecen al proyecto revisado, no a la skill. Sin `--stdout` ni
  `--out`, las herramientas escriben en `./results-accesibilidad/` relativo al
  directorio de trabajo.
- No guardes resultados, capturas, manifiestos, listas de URLs ni estados de sesión
  dentro de `skills/ua-accesibilidad/`. La herramienta lo rechaza por defecto;
  `--allow-skill-output` existe solo para pruebas internas de la propia skill.
- Con varias pruebas, cada una escribe en su subcarpeta.
- No versiones los resultados locales. Si el proyecto no ignora
  `results-accesibilidad/`, recomienda añadirlo a su `.gitignore`.
- Si solo necesitas los resultados para extraer el informe, usa una ruta ignorada o
  limpia los artefactos al terminar.

## Credenciales

`results-accesibilidad/rutas.json` es local y puede contener credenciales de prueba.
Comprueba que la carpeta está ignorada por Git y no muestres ni copies esas
credenciales en informes, mensajes ni commits.

Las expresiones `${...}` del router no generan URLs: el generador informa cuántas
expresiones no pudo resolver para completar `rutas.json` manualmente. No se puede
inferir de ese contador cuántas rutas produce cada bucle.
