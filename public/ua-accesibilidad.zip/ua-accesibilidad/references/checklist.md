# Lista de comprobación

Lista compacta para barrer una revisión de código o para repasar antes de dar por
terminado un componente. Una línea por comprobación. Carga la referencia completa
del elemento solo cuando necesites explicar el problema, decidir un caso dudoso o
redactar la corrección.

La columna `Código` es el código de la prueba equivalente en el catálogo CADUA.
Úsalo en el informe para que la revisión de código y la validación automática
hablen el mismo idioma. `Criterio` es la referencia y el nivel que declara el catálogo.

Respeta esa clasificación tal cual. Una prueba marcada como `CADUA` u `OAW` no
procede directamente de WCAG, pero el OAW la marca como incumplimiento y en el
informe se trata igual que las demás. No la degrades a `Aviso` ni la presentes como
recomendación: el informe debe poder cruzarse con el del validador oficial.

Las comprobaciones sin código no las detecta CADUA: dependen de lectura del código
o de prueba manual.

## Imágenes — `imagenes.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| Todo `<img>` tiene `alt` | `imgWithoutAlt` | WCAG 1.1.1 A |
| La imagen dentro de un enlace tiene `alt` | `imgBadLink` | WCAG 1.1.1 A |
| El `alt` no es genérico ni un nombre de fichero | `imgBadWords` | WCAG 1.1.1 A |
| La imagen decorativa con `role` usa `presentation` | `imgNoAltNoRolePresentation` | WCAG 1.1.1 A |
| La imagen sin `alt` no se queda sin texto que la describa | `imgNoAriaLabel` | WCAG 1.1.1 A |
| `alt=""` no convive con `title`, `aria-label` o `aria-labelledby` con contenido | `imgEmptyAlt` | CADUA |
| `longdesc`, si existe, apunta a una URL válida | `imgWrongLongdesc` | WCAG 1.1.1 A |
| El `alt` no supera 150 caracteres | `imgLong` | OAW |
| El `alt` describe de verdad la imagen en su contexto | `imgManual` | Revisión manual |
| Los iconos junto a texto visible llevan `aria-hidden="true"` | — | WCAG 1.1.1 A |
| Los SVG informativos tienen `role="img"` y `<title>` | — | WCAG 1.1.1 A |

Para resolver `imgManual` con evidencia, `--engine evidencias` recoge los recortes y
las fichas de las imágenes con texto alternativo. Ver `references/cadua.md`.

## Enlaces — `enlaces.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| Ningún enlace está vacío o solo con elementos decorativos | `linkEmpty` | WCAG 2.4.4 A |
| El texto no es genérico ("aquí", "más información", "pulsa aquí") | `linkBadWords` | WCAG 2.4.4 A |
| Un enlace solo con icono tiene `aria-label` | `linkWithIconWithoutAriaLabel` | WCAG 2.4.4 A |
| Los cambios de idioma en enlaces se marcan con `lang` | `linkBadLang` | WCAG 3.1.2 AA |
| Un elemento con `role="link"` o `role="button"` tiene contenido textual | `listRoleWithoutText` | WCAG 4.1.2 A |
| El `alt` de la imagen no repite el texto visible del enlace | `linkSameAltAndContent` | CADUA |
| Dos enlaces adyacentes al mismo destino se combinan en uno | `linkAdjacent` | CADUA |
| El texto del enlace no supera 250 caracteres | `linkLong` | OAW |
| El texto se entiende fuera de su frase y sin contexto visual | `linkManual` | Revisión manual |
| Se avisa si abre pestaña, descarga o cambia de contexto | — | WCAG 3.2.5 AAA |

## Encabezados — `encabezados.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| La página tiene un `h1` y es el primer encabezado | `headingNoH1` | WCAG 1.3.1 A |
| No hay encabezados vacíos | `headingEmpty` | WCAG 2.4.6 AA |
| No se saltan niveles de encabezado | `headingBad` | WCAG 1.3.1 A |
| No hay encabezados consecutivos sin contenido entre ellos | `headingsConsecutive` | CADUA |
| No se repite el mismo texto en varios encabezados | `headingRepeat`, `headingSameName` | CADUA |
| Cada encabezado introduce contenido propio y no es solo estilo | `headingManual` | Revisión manual |
| No se simulan encabezados con `div`, `span`, `p` o negrita | — | WCAG 1.3.1 A |

## Estructura — `estructura.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| `<html>` tiene `lang` con el idioma real | `structureNoLang`, `structureEmptyLang` | WCAG 3.1.1 A |
| La página tiene `<title>` y no está vacío | `structureNoTitle`, `structureEmptyTitle` | WCAG 2.4.2 A |
| Existe un `<main>` que identifica el contenido principal | `structureNoMainTag` | WCAG 2.4.1 A |
| Se usan etiquetas semánticas en vez de `div` genéricos | `structureNoSemanticTags` | WCAG 1.3.1 A |
| Los textos largos no cuelgan de un `div` sin semántica | `structureDivTextLong` | WCAG 1.3.1 A |
| Todo `iframe` tiene `title` descriptivo | `structureIframeWithoutTitle` | WCAG 4.1.2 A |
| No hay controles simulados sin acceso por teclado | `structureUserEventIncorrect` | WCAG 2.1.1 A |
| Los `id` no se repiten en la página | `structureRepeatedID` | WCAG 4.1.2 A |
| No se bloquea el zoom en el `viewport` | `structureViewportAvailable` | WCAG 1.4.4 AA |
| Los tamaños de texto no son absolutos (`px`, `pt`) | `structureFontSizeAbsolute` | WCAG 1.4.4 |
| No se usa `!important` en propiedades de espaciado de texto | `structurePropertiesImportant` | WCAG 1.4.12 AA |
| El texto no está justificado | `structureTextJustify` | CADUA |
| No se estructura el contenido con saltos de línea | `structureManyBr`, `structurePWithBrs` | CADUA |
| Un bloque largo de texto no se queda sin encabezados | `structureWithoutHeadings` | CADUA |

## Listas — `listas.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| No hay listas vacías | `listEmpty` | WCAG 1.3.1 A |
| No hay `<li>` vacíos expuestos | `listElementEmpty` | WCAG 1.3.1 A |
| Todo `<li>` cuelga de un `<ul>` u `<ol>` | `listBadParent`, `listWrong` | WCAG 1.3.1 A |
| No se simulan listas con párrafos o marcadores manuales | `listSimulated`, `list3LevelsSimulated` | WCAG 1.3.1 A |
| No se usa una tabla de una columna como lista | `listSimulatedByTable` | WCAG 1.3.1 A |
| La elección entre `ul` y `ol` refleja si el orden importa | — | Revisión manual |

## Tablas — `tablas.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| La tabla tiene título con `<caption>` | `tableWithoutHead` | WCAG 1.3.1 A |
| La tabla tiene fila o columna de encabezados con `<th>` | `tableNoHeadCell` | WCAG 1.3.1 A |
| Las tablas complejas asocian celdas con `id` y `headers` | `tableComplexNoAttrs` | WCAG 1.3.1 A |
| El título no se simula con una primera fila combinada | `tableSimulatedTitleByCells` | WCAG 1.3.1 A |
| El título no se simula con un encabezado justo antes | `tableSimulatedTitleByHeading` | WCAG 1.3.1 A |
| `aria-describedby` apunta a un `id` existente | `noIdForAriaDescribed` | WCAG 4.1.2 A |
| El título no se repite en `summary` o en la descripción | `sameCaptionAndSummary`, `sameCaptionAndDescribedBy` | CADUA |
| La tabla no se usa para maquetar | — | WCAG 1.3.1 A |
| El contenedor con desplazamiento es alcanzable y tiene nombre | — | WCAG 2.1.1 A |

## Formularios — `formularios.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| Todo campo tiene etiqueta asociada | `formElementWithoutLabel` | WCAG 3.3.2 A |
| La etiqueta no está vacía | `formElementWithEmptyLabel` | WCAG 3.3.2 A |
| La etiqueta no está oculta con `display:none` o equivalente | `formLabelNotHidden` | WCAG 3.3.2 A |
| El texto referenciado por `aria-labelledby` no está oculto | `formLabelledByNotHidden` | WCAG 2.5.3 A |
| El nombre accesible conserva el texto visible del control | `formLabelDifferentFromContent` | WCAG 2.5.3 A |
| Todo botón tiene texto o nombre accesible | `formBtnHasNoText` | WCAG 4.1.2 A |
| Los radios relacionados están agrupados | `formTooManyRadio` | WCAG 1.3.1 A |
| Los checkboxes relacionados están agrupados | `formTooManyCheck` | WCAG 1.3.1 A |
| Un formulario extenso agrupa sus campos | `formFieldsetNeeded` | WCAG 1.3.1 A |
| Todo `fieldset` tiene `legend` con texto | `formFieldsetNoLegend` | WCAG 1.3.1 A |
| Los grupos con `role="group"` o `radiogroup` tienen nombre accesible | `formGroupHasNoAria` | WCAG 1.3.1 A |
| Los apartados no se simulan con encabezados dentro del formulario | `formHeaders` | WCAG 1.3.1 A |
| Todo `optgroup` tiene `label` no vacío | `formOptHasNoLabel` | WCAG 1.3.1 A |
| Un formulario extenso indica qué campos son obligatorios u opcionales; no exige asteriscos | `formFieldsObligatoryOptional` | WCAG 3.3.2 A |
| Los selects largos agrupan sus opciones | `formSelectTooManyOpt` | CADUA |
| No se simulan grupos con separadores dentro de `<option>` | `formSelectConsecutiveChar` | CADUA |
| Los errores se asocian al campo y explican cómo corregirlo | — | WCAG 3.3.1 A / 3.3.3 AA |
| El foco es visible y el orden de tabulación es lógico | — | WCAG 2.4.7 AA / 2.4.3 A |

## Color — `colores.md`

| Comprobación | Código | Criterio |
| --- | --- | --- |
| Texto normal con contraste mínimo 4.5:1 | `colorContrastAA` | WCAG 1.4.3 AA |
| Texto grande con contraste mínimo 3:1 | `colorContrastAALarge` | WCAG 1.4.3 AA |
| Enlaces con contraste suficiente frente al texto y al fondo | `colorContrastLinks` | WCAG 1.4.3 AA |
| Iconos y partes no textuales necesarias con contraste 3:1 | — | WCAG 1.4.11 AA |
| El color no es el único portador de significado | — | WCAG 1.3.3 A / 1.4.1 A |
| El contraste se mantiene en hover, foco, activo y error | — | Revisión manual |

## Teclado — motor avanzado

Siete pruebas con código propio, en `lib/catalogo-de-pruebas-avanzadas.json`, que
solo se ejecutan si el usuario pide expresamente `--engine teclado`. No están en el
catálogo oficial y su informe va aparte del de CADUA. El recorrido se limita a Tab:
las opciones internas que se operan con flechas quedan como comprobación manual.

| Comprobación | Código | Criterio |
| --- | --- | --- |
| Todo control del recorrido de Tab se alcanza | `keyboardNotReachable` | WCAG 2.1.1 A |
| El foco no queda retenido en un elemento | `keyboardTrap` | WCAG 2.1.2 A |
| La primera tabulación lleva a un control | `keyboardFocusLost` | WCAG 2.4.3 A |
| Ningún elemento oculto recibe el foco | `keyboardHiddenFocusable` | WCAG 2.4.3 A |
| El elemento enfocado cambia de aspecto | `keyboardFocusNotVisible` | WCAG 2.4.7 AA |
| No hay `tabindex` con valor positivo | `keyboardPositiveTabindex` | WCAG 2.4.3 A |
| El indicador de foco contrasta al menos 3:1 | `colorContrastUI` | WCAG 1.4.11 AA |

Con `--componentes` se abren además los componentes declarados con `data-bs-toggle`:

| Comprobación | Código | Criterio |
| --- | --- | --- |
| El foco entra en el diálogo al abrirlo | `keyboardDialogFocusNotMoved` | WCAG 2.4.3 A |
| El foco no se escapa del diálogo abierto | `keyboardDialogNotTrapped` | WCAG 2.4.3 A |
| Escape cierra el diálogo | `keyboardDialogNoEscape` | CADUA |
| El foco vuelve al control que abrió el componente | `keyboardFocusNotRestored` | WCAG 2.4.3 A |
| `aria-expanded` cambia al abrir | `keyboardExpandedNotUpdated` | WCAG 4.1.2 A |

## Componentes — `componentes.md`

Estas comprobaciones requieren lectura de código y pruebas de interacción. Algunas
tienen cobertura parcial en los códigos avanzados de teclado indicados arriba:
foco del diálogo, retorno del foco y cambio de `aria-expanded`. No equivalen a
comprobar el componente entero. El foco tras operaciones CRUD y las regiones vivas
siguen fuera del motor, también con `--componentes`.

| Comprobación | Criterio |
| --- | --- |
| El componente se puede usar entero con teclado | WCAG 2.1.1 A |
| El foco entra en el diálogo, no se escapa y vuelve al cerrarlo | WCAG 2.1.2 A / 2.4.3 A |
| El componente tiene nombre accesible | WCAG 4.1.2 A |
| El estado (`aria-expanded`, `aria-selected`, `aria-current`) refleja lo visible | WCAG 4.1.2 A |
| Los cambios de contenido relevantes se anuncian | WCAG 4.1.3 AA |
| Al navegar en una SPA, el foco y el título se actualizan | WCAG 2.4.2 A / 2.4.3 A |
| Existe un enlace de salto al contenido principal | WCAG 2.4.1 A |

## SPA y plantillas Vue — `spa-vue.md`, `plantillas-vue.md`

CADUA valida el HTML renderizado y no ve la plantilla, así que estas comprobaciones
no tienen código propio. Varias, sin embargo, provocan un error del catálogo en
tiempo de ejecución: se indica cuál.

| Comprobación | Provoca | Criterio |
| --- | --- | --- |
| El `<main>` es único, vive en el layout y tiene `id` y `tabindex="-1"` | `structureNoMainTag` | WCAG 2.4.1 A |
| Existe enlace de salto al contenido principal | — | WCAG 2.4.1 A |
| Cada vista de ruta tiene un `h1` con `tabindex="-1"` | `headingNoH1` | WCAG 1.3.1 A |
| Todas las rutas declaran `meta.TITULO` y el router actualiza el `<title>` | `structureNoTitle` | WCAG 2.4.2 A |
| El router mueve el foco tras cambiar de ruta, salvo en la carga inicial | — | WCAG 2.4.3 A |
| Hay destino de foco previsto al destruir un nodo con `v-if` | — | WCAG 2.4.3 A |
| El enlace de la ruta actual usa `aria-current="page"` | — | WCAG 4.1.2 A |
| Los atributos ARIA usan valores válidos para su tipo; `false` expresa un estado y `undefined` elimina el atributo | — | WCAG 4.1.2 A |
| El contenedor de `role="status"` permanece en el DOM | — | WCAG 4.1.3 AA |
| `role="alert"` se reserva a lo urgente, no a lo que se ve rojo | — | WCAG 4.1.3 AA |
| El contenedor de lista no se pinta cuando el array está vacío | `listEmpty` | WCAG 1.3.1 A |
| `v-if` y `v-for` no comparten elemento | — | Buena práctica |
| Los eventos van sobre controles interactivos, no sobre `div` o `span` | `structureUserEventIncorrect` | WCAG 2.1.1 A |
| Navegar usa `RouterLink`, no un botón con `router.push` | — | WCAG 4.1.2 A |
| `v-model` no sustituye a `label for` / `id` | `formElementWithoutLabel` | WCAG 3.3.2 A |

## Fuera del validador

`tipografia.md`, `usabilidad.md` y `diseno-estilos.md` no tienen equivalencia en el
catálogo y no los comprueba ningún motor. Sus pautas son recomendaciones: preséntalas
como `Aviso`, nunca como `Error`, y no las mezcles con las reglas de este checklist.

Esto no afecta a las pruebas del catálogo marcadas como `CADUA` u `OAW`, que sí son
incumplimientos.
