# Revisión de código

La haces tú leyendo ficheros: HTML, Vue, Razor, PHP, Markdown renderizado,
componentes, layouts, formularios y estilos relacionados. Sin navegador y sin
herramientas de la skill.

Sigue este recorrido:

1. **Inventaria y cuenta.** Enumera los ficheros candidatos con `find` o `grep` y
   apunta cuántos hay. Ese número es el denominador de la cobertura que declararás
   en el informe.
2. **Delimita.** Si son demasiados para revisarlos todos, elige un subconjunto con
   un criterio explicable: layouts y vistas antes que componentes hoja, lo que toca
   la tarea en curso, lo que más se reutiliza. Anota el criterio; no muestrees en
   silencio.
3. **Clasifica cada fichero** antes de juzgarlo: página completa, layout o
   componente parcial. Muchas reglas solo se pueden exigir a la página final.
4. **Recorre el checklist** fichero a fichero. En proyectos Vue,
   `references/plantillas-vue.md` separa lo que se puede afirmar leyendo la
   plantilla de lo que hay que confirmar en el componente padre o en el router.
   Si hay componentes Bootstrap, carga `references/bootstrap-vue.md` y comprueba
   la versión y el plugin utilizado antes de proponer cambios de ARIA o teclado.
5. **Confirma lo dudoso** en el padre, en el layout o en el router. Lo que no puedas
   confirmar leyendo es `Comprobación manual pendiente`, nunca `Error`.
6. **Declara la cobertura** en el informe: ficheros existentes, revisados, criterio
   de selección y qué queda pendiente de validar en navegador.

Para cada hallazgo:

- Localízalo con ruta y línea siempre que sea posible.
- Clasifícalo como `Error`, `Aviso` o `Comprobación manual pendiente`.
- Usa `Error` solo para un incumplimiento de accesibilidad, un componente que no
  funciona o un problema objetivo que impida completar la tarea. Las pautas de
  usabilidad y diseño son recomendaciones o `Aviso`.
- Explica por qué es un problema, qué criterio afecta y cómo se corrige, con
  `HTML incorrecto` y `HTML corregido`.
- Cita el código CADUA equivalente cuando exista, según `references/checklist.md`,
  para que este informe se pueda cruzar con el de la validación automática.

Cierra proponiendo la validación con CADUA para lo que no se puede resolver leyendo:
contraste real, comportamiento en ejecución y estructura de la página renderizada.
