# Proyectos .NET de la UA

Aplica estas reglas al revisar en local una aplicación .NET de la UA con cliente Vue.

## Localizar el proyecto

- Identifica el proyecto web, no el de test: suele ser el `.csproj` con
  `Sdk="Microsoft.NET.Sdk.Web"` y una carpeta `ClientApp`. Ignora `*.Test`,
  `*.Tests` o similares salvo petición explícita.
- Revisa primero el esqueleto general: `Views/**/*.cshtml`, sobre todo
  `Views/Home/Index.cshtml`, `_ViewStart.cshtml` y los layouts si existen.
  La aplicación Vue vive en `ClientApp`.
- Para cambios de interfaz, revisa `ClientApp/src/views/**/*.vue`,
  `ClientApp/src/components/**/*.vue` y, cuando afecten al comportamiento
  accesible, `ClientApp/src/composables/**/*.ts`.

## Levantar la aplicación

- Comprueba primero si el puerto `44306` está abierto y escuchando. Si lo está,
  asume que la aplicación ya está desplegada y puede llamarse directamente.
- Si no lo está, levántala con `dotnet run` desde el directorio del proyecto web.
  Al terminar la validación, cierra solo el proceso que hayas arrancado tú.
- Las URLs locales suelen seguir el patrón `https://localhost:44306/{aplicacion}`,
  por ejemplo `https://localhost:44306/accesibilidad`.

## Descubrimiento de URL y rutas

1. Lee `Properties/launchSettings.json`. Prioriza un perfil con
   `commandName: "Project"` y entorno `Development`; suele contener
   `applicationUrl` con `https://localhost:44306;http://localhost:5156`. Si solo
   está `iisSettings.iisExpress.sslPort`, usa `https://localhost:{sslPort}`.
2. Lee `appsettings.json` y `appsettings.development.json`. Busca
   `App:ServerCoreApp`, `App:DirApp` y `Vite:Base`. En esta plantilla
   `App:DirApp` suele ser el path base real de ASP.NET (`UsePathBase`) y
   `Vite:Base` suele coincidir en desarrollo.
3. Si `App:ServerCoreApp` existe, úsalo como origen preferente. Si no existe, usa
   el primer origen HTTPS de `applicationUrl`.
4. Para el path base, prioriza `App:DirApp`; si no existe, usa `Vite:Base`; si
   tampoco existe, infiérelo desde `launchUrl` o desde la ruta de
   `applicationUrl` solo como último recurso.
5. Normaliza el path base con una sola barra inicial y sin barra final:
   `/accesibilidad`, no `/accesibilidad/`.
6. Busca el router en `ClientApp/src/router.ts`; si no está ahí, busca
   `router.ts` dentro de `ClientApp`.
7. Extrae las rutas del array de rutas de Vue. Es habitual que usen una constante
   como `APP_DIR` o `VITE_APP_DIR`, por ejemplo `path: APP_DIR + "/firma"`.
8. Si las rutas extraídas ya incluyen el path base (`/accesibilidad/firma`), no
   vuelvas a anteponerlo. Evita URLs duplicadas como
   `/accesibilidad/accesibilidad/firma`.
9. Si las rutas son relativas al path base (`/firma`, `/contenidoaccesible/Ocr`),
   antepón el path base una sola vez.
10. Ignora rutas comodín o técnicas como `/:catchAll(.*)*` salvo que se revise
    específicamente la página 404.
11. Incluye rutas especiales como `/index.html`, `Logout` o errores de
    autenticación solo cuando aporten valor a la revisión.

Regla práctica de composición:

- Origen: `App:ServerCoreApp` o `https://localhost:44306`.
- Path base: `App:DirApp` o `Vite:Base`.
- Ruta Vue: valor de `path` en `router.ts`.
- URL final: concatena origen y ruta normalizada. Si la ruta Vue ya empieza por el
  path base, úsala tal cual; si no, concatena `pathBase + rutaVue`.

## Autenticación CAS

- Si la aplicación redirige a autenticación, ten en cuenta que las aplicaciones de
  la UA suelen usar el dominio `preproddesa` y CAS.
- La URL de login CAS esperada es `https://casdesa.cpd.ua.es/cas/login`.
- En la primera ejecución puede hacer falta iniciar sesión con usuario y
  contraseña; después la sesión suele mantenerse para ejecuciones posteriores del
  navegador o contexto usado.

Campos habituales del formulario CAS de desarrollo:

- Usuario: `input#username[name="username"]`, etiqueta "Correo electrónico de la UA".
- Contraseña: `input#password[name="password"]`, etiqueta "Contraseña".
- Envío: `button[name="submit"][type="submit"]`, texto "Entrar".
- El formulario puede incluir campos ocultos como `execution`, `_eventId` y
  `geolocation`; no los inventes ni los fijes a mano si el navegador ya los recibe
  de la página.
- Puede aparecer acceso con certificado digital mediante `a#accesoX509`; no usarlo
  salvo petición explícita.

## Credenciales

- Si automatizas el login con `results-accesibilidad/rutas.json`, confirma que la
  carpeta está ignorada por Git.
- No muestres ni copies usuarios, contraseñas, tokens ni cookies en informes,
  mensajes ni commits.
