# Componentes

Aplica estas reglas a componentes interactivos: modales, pestañas, desplegables,
acordeones, paneles, combobox, tablas interactivas, avisos y navegación de
aplicación.

La interacción completa requiere revisión de código y prueba con teclado. El motor
avanzado de teclado cubre parte del foco y, con `--componentes`, algunos estados y
diálogos Bootstrap; consulta los códigos en `references/checklist.md`. No pertenece
al catálogo oficial CADUA. Los fallos de uso confirmados van como `Error` y lo no
verificado como `Comprobación manual pendiente`.

Si el proyecto usa Bootstrap con Vue, aplica además `references/bootstrap-vue.md`:
el plugin ya resuelve buena parte de lo que sigue y el error habitual es
reconstruirlo por encima.

## Los cinco requisitos

Todo componente interactivo debe cumplir estos cinco puntos. Compruébalos uno a
uno; no basta con mirar si el componente se abre.

1. **Teclado**: se puede usar entero sin ratón, con las teclas que el patrón
   espera.
2. **Foco**: es visible en todo momento y está en un lugar lógico, también después
   de abrir, cerrar o completar una interacción.
3. **Nombre**: el componente y cada uno de sus controles tienen nombre accesible.
4. **Estado**: abierto o cerrado, seleccionado, activo o con error se refleja en el
   marcado, no solo en el aspecto.
5. **Cambios**: cuando el contenido se actualiza sin recargar, el cambio se anuncia
   o resulta perceptible sin ver la pantalla.

## Reglas generales

- Prefiere controles HTML nativos. Un `<button>` recibe foco, se activa con Intro y
  Espacio, responde al toque en pantalla táctil y anuncia su rol sin escribir nada.
  Si simulas el control con un `div` o un `span`, tienes que añadir `tabindex="0"`,
  el rol, el manejo de teclado y comprobar el toque, y es fácil dejarte una vía.
- Usa ARIA solo cuando el elemento nativo no cubra el patrón, y mantén sus estados
  sincronizados con el comportamiento visible. ARIA que miente es peor que ausente.
- No añadas ARIA redundante o contradictoria sobre elementos nativos.
- Si una librería ya gestiona el estado y lo comunica con los atributos correctos,
  déjala hacerlo. Duplicar ese estado en el framework crea dos fuentes de verdad
  que acaban desincronizándose.
- No apliques roles por su apariencia. `role="tablist"` describe un componente que
  cambia paneles de contenido, no cualquier cosa que parezca una pestaña; el patrón
  `menu`/`menuitem` describe un menú de aplicación, no un desplegable de acciones
  corriente.
- Si un panel, tarjeta o bloque introduce una sección real, usa un encabezado que
  encaje en la jerarquía de la página. No uses un encabezado solo para obtener un
  tamaño de letra.

## Modales y diálogos

- Todo modal debe tener nombre accesible: vincula el contenedor con su título
  visible mediante `aria-labelledby`, o usa `aria-label` si no hay título visible.
- El título visible debe existir en el DOM y no estar oculto.
- Mientras está abierto, el foco debe quedar retenido dentro del diálogo. Es el
  requisito que más se incumple al construir un modal a mano: de nada sirve que el
  diálogo se vea encima si el teclado sigue recorriendo la página de detrás.
- Al abrirlo, el foco entra en el diálogo. Al cerrarlo, vuelve al control que lo
  abrió.
- Se debe poder cerrar con Escape.
- El botón de cierre sin texto visible necesita nombre accesible, normalmente
  `aria-label="Cerrar"`.

## Pestañas

- Úsalas solo cuando el componente cambie paneles de contenido dentro de la misma
  vista. Una navegación que solo tenga aspecto de pestañas no debe llevar
  `role="tablist"`, `role="tab"` ni `role="tabpanel"`: son enlaces.
- El contenedor usa `role="tablist"`; cada pestaña, `role="tab"` con nombre
  accesible, `aria-controls` apuntando a su panel y `aria-selected` para el estado;
  cada panel, `role="tabpanel"` con `aria-labelledby` hacia su pestaña.
- Las pestañas se implementan con botones, no con enlaces de navegación.
- El recorrido correcto no es con tabulador: el tabulador entra en el grupo de
  pestañas y sale de él, y el cambio entre pestañas se hace con las flechas.
- Da `tabindex="0"` al panel para que el siguiente tabulador lleve a su contenido.

## Desplegables y menús de acciones

- El desencadenante debe ser un `<button>` con `aria-expanded`, que cambia de
  `false` a `true` al abrir.
- Se debe poder cerrar con Escape, y el foco vuelve al botón que lo abrió.
- Las opciones se recorren con las flechas dentro del menú abierto.
- Un desplegable de acciones puede contener enlaces, botones o formularios: mantén
  el HTML estándar y no le impongas `role="menu"` y `role="menuitem"`, que
  implican un modelo de interacción distinto.
- Cuando varias acciones comparten contexto, da nombre al grupo con texto visible
  o con aria sobre un contenedor semántico.
- Si una acción elimina o modifica un elemento concreto, su nombre accesible debe
  incluir ese contexto: `Eliminar solicitud de junio`, no solo `Eliminar`.
- No dependas solo del icono para identificar una acción repetida. Si la acción
  solo tiene icono, `aria-label` es el nombre imprescindible y `title` es ayuda
  opcional para quien usa ratón.

## Acordeones y paneles plegables

- El control es un `<button>` con `aria-expanded`, que comunica el estado, y
  `aria-controls`, que apunta al `id` del bloque que abre. Son dos cosas distintas:
  uno es el estado, el otro la relación.
- El texto del botón debe tener sentido en los dos estados. `Mostrar filtros`
  funciona porque describe la acción; un botón que solo diga `Filtros` deja sin
  saber si va a abrirlos o cerrarlos.
- No hace falta añadir `role="status"` al contenido expandido: el estado ya lo
  comunica el botón.

## Combobox y campos con sugerencias

- Prefiere un `<select>` o un `<input list>` antes que construir un combobox.
- Si lo construyes, el campo necesita `role="combobox"`, `aria-expanded`,
  `aria-controls` hacia la lista y `aria-activedescendant` para la opción resaltada.
- Las sugerencias se recorren con las flechas, se eligen con Intro y se descartan
  con Escape, sin perder lo escrito.
- El número de resultados debe anunciarse en una región viva.

## Tablas interactivas

- La ordenación se marca con `aria-sort` en el `<th>` correspondiente, y el control
  que ordena debe ser un botón dentro del encabezado.
- Los controles de paginación necesitan nombre accesible propio: `Página 3`, no
  solo `3`.
- Al cambiar de página o reordenar, anuncia el resultado en una región viva; el
  foco no debe saltar al principio de la página sin avisar.
- Los filtros que actualizan la tabla al vuelo deben comunicar cuántos resultados
  quedan.

## Mensajes, estados y regiones vivas

- Un mensaje que aparece como resultado de una acción debe anunciarse: usa
  `role="alert"` para errores y avisos importantes, o `role="status"` /
  `aria-live="polite"` para confirmaciones y recuentos.
- El contenedor de la región viva debe existir en el DOM antes de recibir el texto;
  si se crea y se rellena a la vez, muchos lectores no lo anuncian. La excepción es
  `role="alert"`, que sí se anuncia al insertarse.
- No abuses de `aria-live="assertive"`: interrumpe.
- Los estados de carga perceptibles deben comunicarse, no solo mostrar un icono
  girando.
- Los estados de éxito, aviso o error no pueden distinguirse solo por color.

## Navegación en aplicaciones de una sola página

Al cambiar de vista sin recargar el documento hay que actualizar el `<title>`, mover
el foco a la vista nueva y marcar la ruta activa con `aria-current="page"`. Mantén
también un enlace de salto al contenido principal como primer elemento enfocable.

Si la aplicación usa Vue, el detalle está en `references/spa-vue.md`.

## Errores frecuentes

- Iconos sin nombre accesible.
- Controles simulados que no reciben foco o no funcionan con teclado.
- Paneles y diálogos que se abren sin gestionar el foco.
- Estados de carga, éxito o error que solo se perciben visualmente.
- Componentes que cambian el contenido sin dejar claro qué ha ocurrido.
- Estado duplicado entre la librería y el framework, que se desincroniza.

Todos tienen algo en común: se detectan en cuanto se aparta el ratón.

## Revisión

Recorre el componente dos veces: una con ratón y otra solo con teclado.

- Tabulador: ¿llegas a los controles y a la entrada de cada grupo, en orden lógico,
  con foco visible? Las opciones internas de radios y pestañas pueden usar flechas;
  no añadas `tabindex="0"` a todas ellas.
- Intro y Espacio: ¿activan lo que parece que van a activar?
- Flechas: ¿recorren pestañas, opciones de menú y sugerencias?
- Escape: ¿cierra lo que está abierto y devuelve el foco?
- Inspecciona el DOM al interactuar: ¿cambia `aria-expanded`, `aria-selected`,
  `aria-current`, `aria-invalid`?
- Sin mirar la pantalla: ¿sabrías qué ha pasado tras pulsar?
