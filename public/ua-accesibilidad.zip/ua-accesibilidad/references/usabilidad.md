# Usabilidad, microcopy y accesibilidad cognitiva

Aplica estas recomendaciones al crear o revisar textos de interfaz, acciones,
mensajes, estados y recorridos de navegación. Su objetivo es que la interfaz resulte
predecible y fácil de entender.

**Nada de lo que hay aquí es criterio WCAG ni prueba del catálogo.** En un informe va
como `Aviso` o como recomendación, nunca como `Error`. Cuando una de estas
recomendaciones tenga además una regla exigible detrás, esa regla vive en su familia y
no se repite aquí: el marcado de errores y ayudas en `references/formularios.md`, el
anuncio de los cambios de contenido en `references/componentes.md`, y los nombres
accesibles de enlaces y botones en `references/enlaces.md` y `references/formularios.md`.

## Estados de una interfaz

Diseña de forma explícita al menos cinco estados en cada componente que cargue datos:
**inicial** (esperando una acción), **cargando**, **vacío**, **éxito** y **error**.

Sin ellos aparecen mensajes ambiguos: una zona vacía puede significar que todavía no
se ha buscado, que la petición está en curso, que no hay resultados o que algo ha
fallado. El estado y su mensaje tienen que resolver esa ambigüedad.

## Feedback inmediato

Cuando alguien pulsa un botón, envía un formulario o cambia un filtro, la interfaz
debe reaccionar en el momento: deshabilitar el botón y mostrar que se procesa, o
actualizar la zona afectada. Si una acción tarda, dilo; si termina bien o mal, también.

El feedback tiene que llegar por una vía perceptible. Un aviso visual de dos segundos
no sirve a quien no está mirando esa parte de la pantalla o usa un lector de pantalla:
la acción se completa y aun así la persona se queda sin confirmación. Cuando el mensaje
aparece sin recargar la página y sin mover el foco, hay que anunciarlo por programa
El cómo hacerlo está en `references/componentes.md`.

## Acciones y botones

- Etiqueta la acción y su objeto: `Enviar solicitud`, `Guardar cambios`,
  `Descargar informe`, `Eliminar documento`.
- Evita `Aceptar`, `Continuar` o `Enviar` cuando exista una alternativa breve y más
  concreta. `Continuar` puede valer en un proceso por pasos, cuando avanzar es
  realmente la acción esperada.
- Mantén el mismo texto para la misma acción en toda la aplicación.
- Distingue con claridad la acción principal, las secundarias y las destructivas. No
  las presentes como si tuvieran la misma prioridad.
- Nombra las destructivas de forma explícita, por ejemplo `Eliminar solicitud`.
- Evita que el nombre visible y el nombre accesible comuniquen acciones distintas.

### Acciones repetidas en listas y CRUD

En un listado, la misma acción se repite en cada fila. Si el texto es siempre el mismo
genérico, quien recorre la lista de controles con un lector de pantalla escucha
`Editar`, `Editar`, `Editar`, sin saber a qué fila corresponde cada uno.

El botón debe incluir el elemento al que afecta: `Editar Aula 12` mejor que `Editar`,
`Crear convocatoria` mejor que `Crear`. Cuando el diseño no admite un texto tan largo
en cada fila, la forma más simple de dar ese contexto sin tocar el aspecto visual es un
`aria-label` en el propio control:

```html
<button type="button" aria-label="Editar Aula 12">Editar</button>
```

## Mensajes

- Los de éxito confirman la acción y, si procede, orientan sobre el paso siguiente:
  `Los cambios se han guardado` es más claro que `Operación correcta`.
- Los de error explican qué ha ocurrido, dónde está el problema y cómo corregirlo.
- Los estados vacíos explican que no hay contenido y ofrecen una acción útil:
  `Todavía no tienes solicitudes creadas` mejor que una pantalla en blanco.
- Informa de los estados de carga cuando la espera se note, y di qué se está haciendo.
- No dependas solo del color, de un icono o de la posición para comunicar un estado.

El texto debe encajar con el momento: `Guardar cambios` anticipa la acción,
`Cambios guardados` confirma el resultado, y `No se ha podido guardar la solicitud.
Revisa los campos marcados.` explica el error y orienta la recuperación.

### Errores de formulario

Redáctalos como instrucciones accionables, no como descripciones del fallo:

- `Introduce el nombre`, mejor que `El campo nombre no puede estar vacío`.
- `Introduce un correo electrónico válido`, mejor que `Formato de email incorrecto`.
- `Introduce la fecha de nacimiento en formato DD/MM/AAAA`, mejor que
  `Entrada no válida`, que obliga a averiguar qué parte falla.

Si el formato esperado ya está en la ayuda del campo, no repitas el mismo ejemplo en
el error. El mensaje junto al campo y el del resumen de errores deben coincidir
exactamente. El marcado de todo esto está en `references/formularios.md`.

## Formularios y ayuda

- Usa etiquetas e instrucciones breves que expliquen qué dato se necesita. Coloca las
  indicaciones generales antes del formulario o del grupo al que afectan.
- Explica el formato esperado con ejemplos cuando pueda haber dudas, sin usar el
  `placeholder` como única instrucción.
- Mantén una indicación coherente de obligatoriedad u opcionalidad antes de
  empezar a rellenar; para el patrón con `(opcional)` y las marcas accesibles,
  sigue `references/formularios.md`.
- Si un botón está deshabilitado y el motivo no es evidente, explica qué falta.
- Conserva los datos introducidos cuando se produzca un error, siempre que se pueda.

## Prevención y recuperación de errores

- **Validación temprana no invasiva**: avisa en cuanto el error se pueda detectar con
  seguridad, pero sin interrumpir mientras la persona escribe. Valida el correo al
  perder el foco, no letra a letra.
- **Sugerencias de corrección**: si el sistema puede deducir qué se quiso decir o qué
  formato se esperaba, ofrécelo en el propio mensaje.
- **Revisión antes de un envío irreversible**: en trámites largos o con consecuencias
  legales o económicas, muestra un resumen final editable antes de confirmar.

### Acciones reversibles y destructivas

Ante una operación que elimina o modifica datos de forma permanente hay tres salidas:
que sea reversible, que los datos puedan revisarse antes de confirmar, o que exista una
confirmación previa. Las tres persiguen lo mismo, que una equivocación no produzca una
pérdida irreversible, y la elección depende de la acción.

- Para una acción **reversible**, suele ser mejor ofrecer un "deshacer" justo después
  que interrumpir con una confirmación previa: molesta menos y da el mismo margen.
- Para una acción **irreversible**, pide confirmación explícita.

En un diálogo de confirmación:

- Sé específico en el título: `¿Eliminar Aula 12?` se entiende de un vistazo;
  `¿Eliminar?` obliga a leer también el cuerpo.
- Resalta en el cuerpo lo irreversible: "Esta acción no se puede deshacer", "Se
  perderán las reservas asociadas".
- El botón principal dice el verbo y el elemento (`Crear convocatoria`,
  `Guardar cambios`), salvo cuando el título ya identifica el elemento: si el diálogo
  dice `¿Eliminar Aula 12?`, basta con `Eliminar`, destacado como destructivo.
- El botón de cancelar se queda en `Cancelar`, sin avisos añadidos: si se cancela no
  ha pasado nada, y avisar de algo que no ha ocurrido solo añade ruido.
- No abuses de la confirmación. Pedirla en cualquier clic entrena a pulsar `Aceptar`
  sin leer.

## Carga cognitiva

La carga aumenta con el exceso de opciones, el lenguaje técnico, los pasos ocultos,
los errores poco claros y los diseños incoherentes. Para reducirla:

- Divide los procesos largos en pasos y muestra el progreso, para que nadie tenga que
  deducir cuántos faltan.
- Agrupa la información relacionada y usa valores por defecto razonables.
- No pidas datos que ya conoces.
- Mantén la consistencia visual y terminológica, para no obligar a aprender dos veces
  la misma acción.

La accesibilidad cognitiva facilita comprender, aprender, recordar, orientarse y
decidir. Beneficia a personas con discapacidad intelectual, trastornos de atención,
dislexia, daño cerebral, bajo dominio del idioma, estrés o poca experiencia digital.
Medidas concretas: lenguaje claro, estructura visual simple, instrucciones antes del
formulario, ejemplos, prevención de errores, tiempo suficiente, ayuda contextual y
evitar animaciones y distracciones innecesarias.

De todas ellas, dar tiempo suficiente es la que con más frecuencia se olvida: si hay un
límite de tiempo, debe poder ampliarse o desactivarse.

## Navegación y orientación

En cualquier pantalla deberían poder responderse cuatro preguntas: **dónde estoy**,
**qué puedo hacer aquí**, **cómo vuelvo atrás o cambio de sección** y **qué paso sigue**
si estoy dentro de un proceso. Si alguna no se responde, revisa títulos, acciones,
navegación y la relación con el paso anterior y el siguiente.

Cada patrón responde a una relación distinta y usarlo fuera de su propósito añade
complejidad: navegación principal para secciones globales, navegación local para los
apartados de una sección, migas de pan para la posición jerárquica, pestañas para
varias vistas del mismo contexto y pasos para una secuencia.

La arquitectura de información agrupa lo relacionado, separa lo secundario y da más
peso visual a lo importante. No es estética: cuando todas las opciones pesan igual, la
persona tiene que reconstruir mentalmente una organización que la interfaz no le da.

## Consistencia

La navegación repetida debe mantener el mismo orden relativo entre páginas, y los
componentes con la misma función deben identificarse siempre igual.

En la práctica: si el menú está arriba en unas secciones y en un lateral en otras, hay
que localizarlo de nuevo cada vez; y si una misma acción se llama `Guardar` en una
pantalla y `Confirmar` en otra, no se puede anticipar si hacen lo mismo.

## Claridad

- Usa frases directas, vocabulario conocido y voz activa.
- Evita tecnicismos internos, códigos de error sin explicación y textos genéricos como
  `Haz clic aquí`.
- Mantén nombres, fechas, unidades y formatos consistentes en toda la interfaz.
- Presenta primero la información necesaria para decidir y deja los detalles como apoyo.
- Evita confirmaciones, avisos o interrupciones que no prevengan un error real.

## Revisión

- Comprueba que cada acción se entiende fuera de su contexto visual inmediato.
- Revisa los estados normal, carga, vacío, error, éxito y sin permisos.
- Comprueba que los mensajes no culpan a la persona y ofrecen un siguiente paso útil.
- Recorre una pantalla cualquiera y responde las cuatro preguntas de orientación.
- Compara la misma acción en dos pantallas distintas: debe llamarse igual.
