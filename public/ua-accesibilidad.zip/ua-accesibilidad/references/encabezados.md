# Encabezados

Aplica estas reglas al crear o revisar encabezados HTML (`h1` a `h6`) en páginas, componentes, plantillas o contenido renderizado desde Markdown.

Pruebas CADUA de esta familia: `headingEmpty`, `headingBad`, `headingsConsecutive`, `headingRepeat`, `headingManual`, `headingNoH1`, `headingSameName`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Reglas

- Organiza el contenido de las pantallas con encabezados claros; una interfaz sin encabezados suele ser más difícil de explorar y entender.
- Usa encabezados para estructurar secciones, no para dar estilo visual a texto normal.
- Toda página debe tener obligatoriamente un encabezado principal `h1` que describa claramente su propósito. No se admite sustituirlo por otro nivel de encabezado, texto con apariencia de título, `role="heading"` ni ningún otro elemento equivalente.
- El primer encabezado visible de la página debe ser el `h1`. Si se revisa un componente o una vista parcial, el `h1` puede estar fuera de ese archivo, pero debe existir en la página final renderizada.
- No uses encabezados vacíos ni encabezados que solo contengan espacios, iconos decorativos o elementos sin nombre accesible.
- El texto de cada encabezado debe ser descriptivo y conciso.
- No saltes niveles: después de `h2` no debe aparecer directamente `h4`; usa `h3` si es un subapartado.
- Puedes volver a un nivel superior cuando cierras una sección, por ejemplo `h2`, `h3`, `h2`, pero no coloques un encabezado del mismo nivel o superior justo después de otro sin contenido real entre ambos.
- Evita repetir exactamente el mismo texto en varios encabezados de la misma página; si hay repetición necesaria, añade contexto.
- No elijas el nivel por el tamaño visual. Ajusta el estilo con CSS y conserva la jerarquía semántica.
- No simules encabezados con `div`, `span`, `p`, clases CSS o texto en negrita si el contenido introduce una sección.
- Si necesitas un encabezado visualmente oculto para dar estructura, usa una clase de ocultación accesible, no `display:none` ni `aria-hidden="true"`.
- Si usas `role="heading"`, añade `aria-level`, pero prefiere `h1`-`h6` nativos siempre que sea posible.
- No uses encabezados dentro de formularios; organiza los grupos de campos con elementos propios de formulario, como `fieldset` y `legend`, cuando corresponda. Es la prueba `formHeaders`, incumplimiento de WCAG 1.3.1.

## Componentes y vistas parciales

- Revisa la jerarquía dentro del contexto donde se renderiza el componente, no solo dentro del archivo aislado.
- Un componente reutilizable no debe imponer `h1` salvo que represente la página completa, pero al revisar su contexto debe comprobarse que la página final contiene obligatoriamente un `h1`.
- Para tarjetas, paneles o bloques repetidos, suele ser mejor recibir el nivel de encabezado como parámetro o usar el nivel que encaje con la página contenedora.
- Si una vista parcial empieza en `h3`, debe existir un `h2` padre real en la página final.

## Recomendaciones al crear

- Es recomendable que el `h1` coincida con el `<title>` de la página o sea muy parecido, para que el título del navegador y el encabezado principal transmitan el mismo propósito.
- Si el `<title>` incluye nombre del sitio, sección o marca, el `h1` puede quedarse solo con el título especifico de la página.

## Revisión manual

- Considera un `Error` que la página final no tenga un `h1`.
- Genera o inspecciona el esquema de encabezados y comprueba que permite entender la página sin ver el diseño.
- Comprueba que cada encabezado introduce contenido propio.
- Comprueba que no hay encabezados consecutivos de nivel igual o superior sin contenido intermedio.
- Comprueba que los niveles reflejan relaciones padre-hijo, no preferencias visuales.
- Comprueba que el `h1` coincide con el tema principal de la página y no con navegación, logotipo o bloques auxiliares.
- Comprueba que no hay encabezados ocultos, generados por componentes o dentro de formularios que rompan la jerarquía final.

## Ejemplos

```html
<!-- Correcto -->
<h1>Biblioteca universitaria</h1>
<h2>Servicios</h2>
<p>...</p>
<h3>Prestamo de libros</h3>
<p>...</p>
<h2>Horarios</h2>
<p>...</p>

<!-- Evitar: salto de nivel -->
<h1>Biblioteca universitaria</h1>
<h3>Servicios</h3>

<!-- Evitar: encabezados sin contenido entre secciones -->
<h2>Servicios</h2>
<h2>Horarios</h2>

<!-- Evitar: seccion hija sin contenido antes de volver al nivel superior -->
<h2>Servicios</h2>
<h3>Prestamo de libros</h3>
<h2>Horarios</h2>

<!-- Evitar: encabezado usado solo para estilo -->
<h2 class="destacado">Plazo abierto hasta el viernes</h2>

<!-- Mejor: texto destacado sin cambiar la estructura -->
<p class="destacado">Plazo abierto hasta el viernes</p>

<!-- Evitar en formularios: usa fieldset/legend si agrupa campos -->
<form>
  <h2>Datos personales</h2>
</form>
```
