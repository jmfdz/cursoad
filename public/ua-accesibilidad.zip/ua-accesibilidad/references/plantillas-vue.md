# Plantillas Vue: reglas comprobables

Reglas que se comprueban leyendo el `<template>` de un `.vue`, sin ejecutar la
aplicación. Para la arquitectura de la aplicación y el router, usa
`references/spa-vue.md`. Para componentes de Bootstrap, `references/bootstrap-vue.md`.

Ninguna de estas reglas tiene código CADUA: el validador trabaja sobre el HTML ya
renderizado y no ve la plantilla. Aun así, varias de ellas provocan directamente un
error CADUA en tiempo de ejecución; cuando sea así, cita el código en el informe
(`listEmpty` para una lista que puede quedar vacía, `formElementWithoutLabel` para
un campo sin etiqueta, `structureUserEventIncorrect` para un control simulado).

**Las reglas de este fichero se dividen en dos grupos por una razón práctica.** Las
del primer grupo se pueden afirmar leyendo el fragmento. Las del segundo dependen de
lo que haya alrededor: en un fichero suelto producen falsos positivos, así que hay
que confirmarlas antes de darlas por error. No mezcles los dos grupos en el informe.

## Grupo 1: reglas de alta confianza

Se pueden afirmar viendo el fragmento. Cada señal está escrita para que no dependa
del componente padre ni del plugin Bootstrap: si el patrón aparece entero, es un
problema.

| Regla | Señal en el código | Efecto |
| --- | --- | --- |
| `v-if` y `v-for` nunca en el mismo elemento | ambas directivas en la misma etiqueta | en Vue 3 el `v-if` se evalúa primero y no ve la variable del `v-for`; si la condición la usa, el componente falla |
| Un `role="status"` no puede llevar `v-if` en su propio nodo | `<div role="status" v-if="...">` | el contenedor nace con el texto dentro y muchos lectores no lo anuncian |
| Un contenedor de lista no se pinta vacío | `<ul>` con `v-for` en el `<li>` y sin `v-if` que proteja el contenedor | cuando el array queda vacío genera `<ul></ul>`, error CADUA `listEmpty` |
| Los eventos van sobre controles interactivos | `@click` en `div`, `span`, `li`, `td`, `i` sin `role`, sin `tabindex` y sin manejador de teclado | control no accesible por teclado, `structureUserEventIncorrect` |
| Un atributo ARIA de relación no recibe booleanos | `:aria-describedby="hayError && 'emailError'"` | cuando la condición es falsa escribe `aria-describedby="false"`, una referencia a un id que no existe; para omitir la relación, `undefined` |
| Navegar es un enlace, no un botón | `@click="router.push(...)"` en un `<button>` | pierde menú contextual, abrir en pestaña nueva y semántica de enlace |
| Un botón solo con icono necesita nombre | `<button>` cuyo contenido es solo `<i>`, `<span class="bi-…">` o `<svg>`, sin `aria-label`, sin `aria-labelledby` y sin `v-bind` que pueda aportarlos | botón sin nombre accesible, `formBtnHasNoText` |
| Un icono junto a texto es decorativo | `<i class="bi-…">` o `<svg>` sin `aria-hidden="true"` junto a texto visible | el lector anuncia ruido o el nombre del icono; si el icono dice algo que el texto no dice, la alternativa va en texto, no en el icono |
| Dentro de un `<form>`, todo `<button>` declara su `type` | `<button>` sin `type` dentro de un `form` | sin `type` el botón envía: correcto solo si es el de envío, error en los secundarios, que llevan `type="button"` |
| `v-model` no da nombre accesible | `<input v-model>` sin `id` apuntado por un `<label for>` y sin `<label>` que lo envuelva | `formElementWithoutLabel` |

La precedencia de `v-if` sobre `v-for` es la de
[Vue 3](https://vuejs.org/guide/essentials/list.html#v-for-with-v-if); en Vue 2 era
al revés, así que comprueba la versión antes de citar el efecto. Cuando una regla
tenga código CADUA equivalente, cítalo; cuando sea solo una recomendación de estilo
de Vue, no la presentes como error CADUA.

### Las tres que más se confunden

`role="status"` frente a `role="alert"`. El contenedor de `status` permanece en el
DOM y el contenido entra dentro; el de `alert` puede crearse entero:

```vue
<!-- Correcto -->
<div role="status">
  <p v-if="mensaje" class="alert alert-success">{{ mensaje }}</p>
</div>

<!-- Incorrecto: nace con el contenido dentro -->
<div v-if="mensaje" role="status" class="alert alert-success">{{ mensaje }}</div>

<!-- Correcto: alert sí puede crearse con v-if -->
<p v-if="errorUrgente" role="alert" class="alert alert-danger">{{ errorUrgente }}</p>
```

Listas condicionadas. El `v-if` va en el contenedor, el `v-for` en el `<li>`:

```vue
<ul v-if="usuarios.length">
  <li v-for="usuario in usuarios" :key="usuario.id">{{ usuario.nombre }}</li>
</ul>
<p v-else>No hay usuarios.</p>
```

Con carga asíncrona, los tres estados se distinguen con `v-if` / `v-else-if` /
`v-else`: cargando, lista con elementos y estado vacío.

Atributos ARIA condicionales. `undefined` quita el atributo; `false` se escribe
como texto. La elección depende del atributo:

```vue
:aria-current="esActual ? 'page' : undefined"
:aria-invalid="hayError ? 'true' : 'false'"
:aria-describedby="hayError ? 'emailError' : undefined"
```

`aria-current="false"` y `aria-invalid="false"` son estados válidos. En controles
que admiten `aria-expanded` o `aria-selected`, conserva `false` para comunicar
cerrado o no seleccionado; quitar el atributo no siempre equivale a ese estado.
`aria-describedby` y `aria-labelledby` contienen referencias a IDs, no booleanos:
omite la relación cuando no exista. Véanse los
[tipos de valores WAI-ARIA](https://www.w3.org/TR/wai-aria-1.2/#propcharacteristic_value).

Con Bootstrap, conserva el estado inicial declarativo y deja que el plugin
actualice `aria-expanded` y `aria-selected`. No añadas un enlace reactivo Vue si
Bootstrap ya es responsable del atributo; aplica `references/bootstrap-vue.md`.

## Grupo 2: reglas que dependen del contexto

Aquí es donde salen los falsos positivos. El patrón es sospechoso, pero puede ser
correcto. **Confirma antes de informar**, y si no puedes confirmarlo, clasifícalo
como `Comprobación manual pendiente`, no como `Error`.

| Regla | Por qué puede ser un falso positivo |
| --- | --- |
| Cada vista tiene un `h1` con `tabindex="-1"` | el fichero puede ser un componente parcial, no una vista de ruta. Comprueba si está referenciado en el router antes de exigirle `h1` |
| No hay `<main>` dentro de una vista | una vista puede ser el layout de la aplicación. Comprueba dónde vive el `<main>` real antes de pedir que se quite |
| Los radios o checkboxes relacionados van en `fieldset` con `legend` | el `fieldset` puede estar en el componente padre que envuelve al que estás leyendo |
| El texto de ayuda se asocia con `aria-describedby` | la ayuda puede estar asociada desde un componente de campo reutilizable |
| Un `<form>` en el que no se ve ningún `type="submit"` | el botón de envío puede estar fuera y asociado con `form="id"`, o el envío puede resolverlo el componente padre. Un `<button>` sin `type` también envía |
| Un `@click` en un elemento no interactivo | puede llevar ya `role`, `tabindex="0"` y `@keydown`; entonces es aceptable aunque no sea lo preferible |
| Un encabezado que salta de nivel | el nivel de partida depende de dónde se monte el componente. Revisa la vista que lo usa |
| Un `<img>` sin `alt` | puede recibirlo por `v-bind` o desde un componente de imagen propio |
| Texto de enlace genérico | puede completarse con un `<span class="visually-hidden">` que esté en otra línea |
| `:key` en un `v-for` | usar el índice no es un error de accesibilidad por sí mismo, pero al reordenar reutiliza nodos y puede mover el foco. Coméntalo como aviso, no como error |

## Cómo evitar falsos positivos

- Un `.vue` no es una página. Antes de exigir `h1`, `main`, `title` o jerarquía
  completa, averigua si el fichero es una vista de ruta, un layout o un componente
  reutilizable.
- Mira el componente padre antes de afirmar que falta un envoltorio (`fieldset`,
  `nav`, `ul`, `main`).
- Los atributos pueden llegar por `v-bind`, por props o desde un componente
  intermedio. La ausencia literal de `alt` o de `aria-label` en la etiqueta no
  siempre significa que falten en el HTML final.
- Los componentes de terceros o propios pueden renderizar el elemento accesible por
  dentro. Si no puedes leer su implementación, es comprobación manual.
- Cuando la duda solo se resuelve viendo el HTML renderizado, dilo y propone la
  validación con CADUA en lugar de afirmar el error.

## Formularios en Vue

Para formularios de envío, aplica estas pautas. Los filtros reactivos y ajustes
que no se envían conservan las excepciones de `references/formularios.md`:

1. Los eventos de interacción van solo sobre controles interactivos; para una acción,
   un `<button>`.
2. Los campos de una misma operación se agrupan en un `<form>`, también en una SPA.
3. Prefiere `<label for>` apuntando al `id` del campo. Un `label` envolvente también
   asocia la etiqueta; respeta las alternativas justificadas de `formularios.md`.
   `v-model` no sustituye esa asociación.
4. El formulario tiene acción predeterminada: `@submit.prevent="accion"` en el
   `<form>` y un botón `type="submit"`.

```vue
<form @submit.prevent="crearUsuario">
  <label for="nombreUsuario">Nombre del usuario</label>
  <input id="nombreUsuario" v-model="nombreUsuario" type="text">
  <button type="submit">Crear usuario</button>
</form>
```

Para la agrupación con `fieldset` y `legend`, la indicación de campos obligatorios,
la ayuda con `aria-describedby` y los mensajes de error, aplica
`references/formularios.md`. Lo específico de Vue es que `v-model` no aporta
semántica: ni nombre accesible, ni agrupación, ni relación con la ayuda.

En el resumen de errores, el contenedor con `role="alert"` va después del botón de
envío y permanece en el DOM; la lista se genera solo cuando hay errores, para no
dejar un `<ul>` vacío. Cada error enlaza al `id` de su campo.

## Revisión

Al revisar un `.vue`, recorre en este orden:

1. ¿Qué es este fichero: vista de ruta, layout o componente?
2. Grupo 1 completo, que se puede afirmar sin salir del fichero.
3. Grupo 2, confirmando cada caso en el padre o en el router.
4. Reglas generales de imágenes, enlaces, tablas y formularios según
   `references/checklist.md`.
