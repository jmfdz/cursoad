# Informes

Genera informes breves, claros y en español. Sirven tanto para la revisión de
código como para CADUA, AXE, teclado y recogida de evidencias.

Di siempre con qué método se ha obtenido cada cosa. Un informe de revisión de código
no puede presentarse como si lo hubiera producido un validador, y tampoco al revés.

## Ficheros

Para cada prueba automatizada, guarda únicamente:

- `informe-accesibilidad.json`: datos estructurados, sin duplicar el resultado
  interno del motor.
- `informe-accesibilidad.md`: informe legible para revisión humana.

No generes un JSON adicional por cada URL.
Si se pide el informe en PDF, genéralo desde el Markdown con la skill
`ua-documentos-accesibles` si está disponible; no maquetes el PDF por otra vía.
El motor de evidencias conserva además sus recortes y `evidencias/imagenes.json`,
según `references/cadua.md`. Usa carpetas distintas al ejecutar varios motores.

## JSON

Usa campos públicos en español y no expongas la estructura interna del motor.
Organízalo así: identificación de la prueba, método, fecha, alcance, resumen, rutas
o ficheros, URLs inválidas y comprobaciones manuales pendientes. Dentro de cada ruta, agrupa los errores por
criterio y reúne sus casos.

## Markdown

Abre siempre con el título exacto `# Resultados de la comprobación de accesibilidad`
y muestra, en este orden:

1. Prueba, método y fecha. El método es revisión de código, CADUA, AXE, teclado o
   recogida de evidencias; distingue esta última de la posterior revisión asistida.
2. Alcance. En una validación automática, las rutas analizadas. En una revisión de
   código, la cobertura: cuántos ficheros candidatos hay, cuántos se han revisado,
   con qué criterio se han elegido y cuáles quedan sin revisar. Nunca dejes que se
   entienda que se ha revisado todo el proyecto si solo se ha leído una parte.
3. Resumen con rutas o ficheros correctos, con incidencias y número de errores.
4. Una sección breve por ruta o fichero, con su número de errores.
5. Detalle agrupado por criterio, solo cuando haya errores.
6. URLs inválidas o desviadas.
7. Comprobaciones manuales pendientes y, en una revisión de código, lo que queda
   pendiente de validar en navegador: contraste real, comportamiento en ejecución y
   estructura de la página renderizada.

Agrupa y resume siempre por tipo de prueba o criterio, nunca por familias de errores.
En evidencias, sustituye el resultado «correcto» por «pendiente de revisión» y
resume el material recogido: cero errores no implica que las imágenes se hayan
comprobado. En teclado, declara el recorrido de Tab y si se usó `--componentes`;
no presentes el resultado como una prueba completa de interacción.

## Contenido de cada criterio

Incluye nombre, descripción, referencia, solución y número de casos. Para cada error
o caso representativo, muestra el `HTML incorrecto` o código actual detectado y el
`HTML corregido` o propuesta, y explica brevemente el motivo del cambio.

Según el origen del hallazgo:

- CADUA: usa `catalogoPrueba` como fuente preferente para id, código, nombre,
  descripción, criterio WCAG/OAW/CADUA y nivel de auditoría.
- AXE: usa el id de regla, la ayuda, el impacto, las etiquetas WCAG si existen y
  `helpUrl` como referencia.
- Teclado: usa `lib/catalogo-de-pruebas-avanzadas.json`, conserva sus códigos y
  clasificación, y presenta el informe separado del catálogo oficial CADUA.
- Evidencias: identifica la imagen, su recorte y el texto alternativo; conserva
  `imgManual` como revisión manual pendiente según `references/cadua.md`.
- Revisión de código: cita la referencia interna aplicada y la ubicación del
  fichero, con ruta y línea siempre que sea posible. Si la regla tiene código CADUA
  equivalente, indícalo para poder cruzar los dos informes.

## Reglas de cierre

- No incluyas usuarios, contraseñas, cookies ni datos de autenticación.
- Distingue siempre errores del motor, avisos y comprobaciones manuales pendientes.
  La ausencia de errores detectables no equivale a conformidad completa.
- Si el usuario ha pedido corregir, aplica los cambios y resume lo corregido.
- Si no lo ha pedido y el proyecto es local y modificable, termina literalmente con:
  `Si quieres, puedo solucionar los problemas con la skill.`
