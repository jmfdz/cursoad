# Enlaces

Aplica estas reglas al crear o revisar enlaces (`<a>`, `router-link`, enlaces generados por componentes, o elementos con rol de enlace).

Pruebas CADUA de esta familia: `linkEmpty`, `linkLong`, `linkBadWords`, `linkManual`, `linkAdjacent`, `linkWithIconWithoutAriaLabel`, `linkSameAltAndContent`, `linkBadLang`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Reglas

- Todo enlace debe tener nombre accesible.
- El texto del enlace debe describir destino o acción sin depender del contexto visual.
- No uses como texto único expresiones genéricas como `aqui`, `este`, `enlace`, `pulsa aqui`, `pulse aqui`, `haz click`, `haz click aqui`, `click aqui`, `aci`, `enllac`, `prem aci`, `fes click` o `click aci`.
- `Mas informacion` o `leer mas` no son descriptivos por si solos: haz visible el destino o completa el nombre accesible.
- Evita usar la URL completa como texto visible del enlace, salvo que la URL sea el dato que se quiere comunicar.
- El texto del enlace debe ser breve; no debe superar 250 caracteres.
- Los textos legales pueden superar ese límite cuando empiezan por términos como `ley`, `orden`, `decreto`, `r.d.` o `real decreto`.
- Dos enlaces adyacentes con el mismo destino deben combinarse en un solo enlace.
- No crees enlaces vacíos ni enlaces que solo contengan espacios, saltos de línea o elementos decorativos.
- Si el enlace abre una nueva pestaña, descarga un archivo o cambia de contexto de forma relevante, indícalo en el texto visible o en el nombre accesible.
- Si el enlace es un cambio de idioma o está en otro idioma, marca el cambio con `lang` en el enlace o en su primer elemento interno.
- Usa `<a href="...">` para navegar. Usa `<button>` para ejecutar acciones que no navegan.
- Si creas un elemento con `role="link"` o `role="button"`, debe tener contenido textual, `aria-label` o `aria-labelledby`.
- Si creas un enlace con `role="link"`, debe ser accesible por teclado; prefiere `<a href>` siempre que sea posible.

## Enlaces con imágenes

- Si el único contenido del enlace es una imagen, el `alt` de la imagen debe describir el destino o acción del enlace.
- Si el enlace tiene texto visible suficiente, la imagen interna debe ser decorativa: `alt=""`.
- No repitas en el `alt` el mismo texto visible del enlace si la imagen no aporta información adicional.
- Si la imagen aporta información adicional al texto del enlace, el `alt` puede completar esa información sin duplicarla.

## Enlaces con iconos

- Si el enlace solo contiene un icono, usa `aria-label` en el enlace.
- En enlaces solo con icono, prefiere `aria-label` antes que texto oculto visualmente.
- Si por compatibilidad o convención se usa `title`, debe coincidir con `aria-label`; no dependas solo de `title`.
- `title` es opcional y aconsejable como ayuda para raton en enlaces solo con icono, pero el nombre accesible imprescindible sigue siendo `aria-label`.
- Si el enlace tiene texto visible y el icono es decorativo, marca el icono con `aria-hidden="true"`.
- Los iconos decorativos renderizados con `i`, `span`, SVG u otro elemento junto a texto visible deben llevar `aria-hidden="true"`.
- Si el icono está renderizado con `<i>`, `<span>` u otro elemento sin texto, el nombre accesible debe estar en el enlace.
- Nombra el enlace, no el icono interno.

## Enlaces genéricos con contexto

- Preferencia: escribe un texto visible descriptivo, por ejemplo `Mas informacion sobre admision`.
- Si el diseño obliga a mostrar solo `Mas informacion`, completa el nombre accesible.
- En enlaces de texto, suele ser preferible añadir un sufijo oculto visualmente antes que sustituir todo el nombre con `aria-label`.
- Si usas `aria-label` en un enlace con texto visible, debe conservar ese texto visible al principio: `aria-label="Mas informacion sobre admision"`.
- En botones o enlaces solo con icono, prefiere `aria-label` antes que texto oculto visualmente.

## Revisión manual

- Comprueba que varios enlaces con el mismo texto no llevan a destinos distintos sin contexto suficiente.
- Comprueba que el texto del enlace sigue teniendo sentido leido fuera de la frase.
- Comprueba que enlaces de idioma como `English`, `Welcome`, `Espanol`, `Francais`, `Valencia`, `Benvingut` o equivalentes usan el `lang` correcto.
- Comprueba que los enlaces con imagen o icono tienen un nombre accesible equivalente al destino o acción real.

## Ejemplos

```html
<!-- Correcto: texto descriptivo -->
<a href="/admision">Consultar informacion de admision</a>

<!-- Evitar: texto generico -->
<a href="/admision">Mas informacion</a>

<!-- Correcto si debe verse corto -->
<a href="/admision">
  Mas informacion<span class="visually-hidden"> sobre admision</span>
</a>

<!-- Alternativa aceptable con aria-label -->
<a href="/admision" aria-label="Mas informacion sobre admision">Mas informacion</a>

<!-- Enlace solo con imagen -->
<a href="/admision">
  <img src="/banner-admision.png" alt="Consultar informacion de admision">
</a>

<!-- Enlace con texto e imagen decorativa -->
<a href="/admision">
  <img src="/flecha.svg" alt="">
  Consultar informacion de admision
</a>

<!-- Enlace solo con icono -->
<a href="/eliminar" aria-label="Eliminar elemento">
  <span class="icon-trash" aria-hidden="true"></span>
</a>

<!-- Enlace en otro idioma -->
<a href="/en/" lang="en">English</a>

<!-- Elemento con rol de enlace -->
<span role="link" tabindex="0" aria-label="Abrir ayuda"></span>
```
