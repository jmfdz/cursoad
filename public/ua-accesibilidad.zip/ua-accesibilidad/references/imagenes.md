# Imágenes

Aplica estas reglas al crear o revisar imágenes, iconos, SVG y botones gráficos. Para enlaces con imágenes o iconos, aplica `references/enlaces.md`, que define el nombre accesible final del enlace.

Pruebas CADUA de esta familia: `imgWithoutAlt`, `imgLong`, `imgBadWords`, `imgBadLink`, `imgManual`, `imgNoAltNoRolePresentation`, `imgNoAriaLabel`, `imgEmptyAlt`, `imgWrongLongdesc`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Reglas

- Toda etiqueta `<img>` debe tener atributo `alt`.
- Si la imagen informa o aporta contenido, `alt` debe describir su contenido o propósito.
- Si la imagen es decorativa, usa `alt=""`.
- No uses una imagen decorativa como único contenido de un botón. Para enlaces, revisa la regla equivalente en `references/enlaces.md`.
- El `alt` debe ser breve; no debe superar 150 caracteres.
- No uses textos genéricos como `imagen`, `foto`, `grafico`, `icono`, `logo` o equivalentes si no describen el propósito.
- No uses nombres de fichero, extensiones ni textos solo numéricos como texto alternativo: `cabecera.jpg`, `logo.png`, `IMG_0012`, `12345`.
- No empieces con "imagen de" o "foto de" salvo que sea necesario para entender el contenido.
- Si una imagen contiene texto relevante, ese texto debe estar en el `alt` o en texto visible cercano.
- Si la imagen necesita una descripción larga, pon la explicación como texto visible cercano; no la metas entera en `alt`.
- Si una imagen tiene `alt=""`, no debe tener `title`, `aria-label` ni `aria-labelledby` con contenido.
- Si una imagen no tiene texto alternativo porque es decorativa y se usa `role`, el rol debe ser `presentation`.
- No uses `role="img"` en una imagen sin nombre accesible.
- Evita `aria-label` en `<img>` como sustituto de `alt`; usa `alt` por defecto.
- Evita `title` como sustituto de `alt`.
- Evita `longdesc`; si existe, debe apuntar a una URL `https` valida y mantenida.
- Si una imagen está dentro de un botón, decide su `alt` según el nombre accesible final del botón.
- Si una imagen está dentro de un enlace, aplica `references/enlaces.md`.

## Iconos

- Si el icono acompaña a texto visible, marca el icono como decorativo.
- Los iconos decorativos renderizados con `i`, `span`, SVG u otro elemento junto a texto visible deben llevar `aria-hidden="true"`.
- Si el icono es el único contenido de un botón, el botón debe tener nombre accesible.
- En botones solo con icono, prefiere `aria-label` antes que texto oculto visualmente para lectores de pantalla.
- Nombra el botón, no el icono interno.

## SVG

- Si el SVG es decorativo, usa `aria-hidden="true"` y evita que reciba foco.
- Si el SVG funciona como imagen informativa autónoma, usa `role="img"` e incluye un `<title>` descriptivo dentro del SVG.
- Si el SVG transmite información y no hay texto cercano, dale nombre accesible; preferiblemente con `role="img"` y `<title>`.
- Si el SVG está dentro de un botón o enlace, normalmente el nombre accesible debe estar en el botón o enlace.

## Revisión manual

- Comprueba que el `alt` encaja con el contexto real, no solo que exista.
- Pregunta qué perdería una persona si no pudiera ver la imagen.
- Decide si la imagen informa, decora o ejecuta una acción.
- En gráficos, capturas, esquemas o banners, verifica que la información esencial también existe como texto.

## Ejemplos

```html
<!-- Imagen informativa -->
<img src="/campus.jpg" alt="Vista del campus universitario">

<!-- Imagen decorativa -->
<img src="/separador.svg" alt="">

<!-- Boton solo con icono -->
<button type="button" aria-label="Guardar cambios">
  <svg aria-hidden="true" focusable="false">...</svg>
</button>

<!-- Icono no SVG decorativo junto a texto -->
<button type="button">
  <span class="icon-save" aria-hidden="true"></span>
  Guardar
</button>

<!-- Icono Font Awesome decorativo junto a texto -->
<button type="button">
  <i class="fa fa-save" aria-hidden="true"></i>
  Guardar cambios
</button>

<!-- SVG informativo autonomo -->
<svg role="img" focusable="false">
  <title>Estado completado</title>
  ...
</svg>
```
