# Tipografía y presentación del texto

Recomendaciones sobre cómo se presenta el texto: qué familia, de qué tamaño y cómo se
reparte en la página.

**Nada de lo que hay aquí es criterio WCAG ni prueba del catálogo.** En un informe va
como `Aviso` o como recomendación, nunca como `Error`. Las reglas exigibles que tocan
el texto viven en sus familias y no se repiten aquí:

- Unidades relativas, texto justificado, `!important` sobre el espaciado, párrafos
  simulados con `<br>` e idioma de la página: `references/estructura.md`.
- Umbral de texto grande a efectos de contraste: `references/colores.md`.
- Cambio de idioma en enlaces: `references/enlaces.md`.

## Elección de la familia

- Usa familias sin remates (*sans serif*): se distinguen mejor en pantalla y a tamaños
  pequeños.
- Declara siempre una lista con alternativas y termina en `sans-serif`, que es la red
  de seguridad para que el sistema no acabe eligiendo una fuente con remates.
- Comprueba tres cosas al elegirla: que no confunda caracteres parecidos (`I`, `l`,
  `1`; `O`, `0`), que no sea demasiado estrecha ni demasiado ligera, y que tenga pesos
  suficientes para marcar jerarquía sin recursos raros.

En la UA la familia de partida es **Arial**. La web institucional usa además **Atkinson
Hyperlegible Next**, del Braille Institute, y su uso va a extenderse.

Esa familia ataca justamente el primer punto: dibuja de forma deliberadamente distinta
los caracteres que suelen confundirse. La `I` mayúscula lleva remates que la separan de
la `l` y del `1`; el `0` se distingue de la `O`; la `b`, la `d`, la `p` y la `q` no son
la misma forma girada. En un texto corrido apenas se nota; marca la diferencia en un
DNI, una matrícula o una contraseña.

No está instalada en los sistemas operativos, así que hay que servirla. Es preferible
alojarla en el propio sitio antes que cargarla de un proveedor externo: no dependes de
un tercero, no envías datos de navegación de tus usuarios a otro servidor y sigue
funcionando en una intranet sin salida a internet.

```css
@font-face {
  font-family: 'Atkinson Hyperlegible Next';
  src: url('/fonts/atkinson-hyperlegible-next.woff2') format('woff2');
  font-weight: 100 900;   /* Fuente variable: todos los pesos en un fichero */
  font-display: swap;     /* Muestra el texto ya con la alternativa */
}
```

`font-display: swap` no es opcional en la práctica: sin él, la mayoría de navegadores
dejan el texto invisible mientras se descarga la fuente, así que una descarga lenta o
fallida deja el contenido ilegible.

## Dónde se declara

- La familia y el tamaño base van en `body`, y de ahí se heredan.
- En `html` no se fija tamaño: déjalo en `font-size: 100%`. Tanto un valor en píxeles
  como el truco de `62.5%` anulan el tamaño de letra que la persona haya configurado en
  su navegador.
- No uses el selector universal `*` para la tipografía: rompe la herencia y aplasta
  elementos que normalmente queremos distintos, como `pre`, `code` o `kbd`.
- Los controles de formulario **no heredan** la tipografía: `input`, `select`,
  `textarea` y `button` usan la fuente del sistema y a menor tamaño. Es justo donde más
  falta hace leer bien, y se corrige con una regla.

```css
html { font-size: 100%; }

body {
  font-family: 'Atkinson Hyperlegible Next', Arial, Verdana, sans-serif;
  font-size: 1.14rem;
  line-height: 1.5;
}

input, select, textarea, button { font: inherit; }
```

Con Bootstrap 5 esto ya viene resuelto: en lugar de escribir las reglas a mano,
redefine `--bs-body-font-family` y `--bs-body-font-size` para que todos sus componentes
queden coherentes.

## Tamaño base

Equivalencias, partiendo de una raíz de 16 px:

| Puntos | Píxeles | rem |
| --- | --- | --- |
| 12 pt | 16 px | 1rem |
| 14 pt | 18,67 px | 1.1667rem |

Doce puntos es el suelo por debajo del cual el texto de cuerpo se lee mal, y se aplica
a todo el texto: pies de tabla, etiquetas de campo, mensajes de error, migas de pan y
pie de página son donde más se cuela un tamaño pequeño.

Conviene partir por encima de ese suelo, porque el mínimo no deja margen: en cuanto
aparece un texto secundario o la letra pequeña de un formulario, esos elementos caen por
debajo.

Hay dos valores en circulación y conviene conocer los dos:

- **`1.1667rem`** es el tamaño **recomendado** con carácter general. Equivale a los 14
  puntos de la tabla, 18,67 px con la raíz por defecto.
- **`1.14rem`** es el que se ha puesto en la **nueva web de la UA** y en la **nueva
  plantilla de UACloud**. Son 18,24 px con la raíz por defecto.

La diferencia entre ambos es de menos de medio píxel, así que los dos cumplen de sobra
el mínimo y dejan margen para el texto secundario. Al trabajar sobre un proyecto, sigue
el que ya use: en la web institucional y en las aplicaciones basadas en la plantilla
nueva de UACloud, `1.14rem`. Lo que no conviene es mezclar los dos en el mismo sitio.

Define el resto de la escala también en `rem`, para que todo crezca a la vez si la
persona cambia el tamaño de su navegador y la jerarquía se mantenga:

```css
body { font-size: 1.14rem; } /* Plantilla nueva de la UA; 1.1667rem si se sigue la recomendación general */

h1 { font-size: 2.5rem; }
h2 { font-size: 2rem; }
h3 { font-size: 1.5rem; }
```

## Párrafo y espaciado

- Interlineado de 1.5 en el cuerpo y algo menor en los titulares, donde las líneas son
  cortas.
- Centra solo textos cortos, de un par de líneas como mucho.
- Longitud de línea entre 45 y 80 caracteres. La unidad `ch` va bien porque equivale
  aproximadamente a la anchura de un carácter: `max-width: 70ch`. No se echa de menos
  hasta que se ve el mismo texto a pantalla completa en un monitor ancho.
- Evita las alturas fijas: si el contenedor tiene `height` en píxeles y el texto crece
  al ampliarlo, se corta o se solapa. Usa `min-height`.

```css
/* Evitar: al ampliar el texto, el contenido se corta */
.tarjeta { height: 180px; overflow: hidden; }

/* Correcto: la altura es un mínimo, no un límite */
.tarjeta { min-height: 180px; }
```

## Mayúsculas y énfasis

- Evita el texto en mayúsculas: todas las letras ocupan la misma caja y la palabra
  pierde el perfil que usamos para reconocerla de un vistazo. En líneas braille su
  lectura es además menos cómoda.
- Si el diseño las exige, aplícalas con `text-transform`, no las escribas en el HTML:
  el lector de pantalla lee el texto del código y puede deletrear la palabra como si
  fuera una sigla.
- `<strong>` y `<em>` aportan significado; `<b>` e `<i>` son visuales. Si solo buscas
  negrita o cursiva por diseño, aplícalo desde CSS.

```html
<!-- Evitar: puede deletrearse M-A-T-R-Í-C-U-L-A -->
<button type="button">MATRÍCULA</button>

<!-- Correcto: el texto real es "Matrícula" -->
<button type="button" class="text-uppercase">Matrícula</button>
```

## El texto debe estar en el HTML

No uses la propiedad `content` de `::before` y `::after` para transmitir información.
Los lectores de pantalla la anuncian de forma inconsistente, no se puede seleccionar ni
copiar, no la encuentra el buscador del navegador ni los indexadores, los traductores
automáticos la ignoran y desaparece si alguien aplica su propia hoja de estilos, algo
habitual en configuraciones de alto contraste.

```css
/* Evitar: el texto solo existe en la hoja de estilos */
.aviso::before { content: "Importante: "; }
```

```html
<!-- Correcto: el texto vive donde se puede leer y traducir -->
<p class="aviso"><strong>Importante:</strong> el plazo termina el 30 de junio.</p>
```

Sí es legítimo para elementos decorativos, como el icono de una fuente iconográfica,
siempre que no aporten información que no esté ya en el texto.

Regla práctica: si al desactivar la hoja de estilos se pierde información, ese texto
estaba en el sitio equivocado.

## Revisión

1. Amplía al 400 % con Ctrl++. Delata anchuras y alturas fijas.
2. Cambia el tamaño de letra por defecto del navegador de 16 a 20 px. Todo el texto
   debe crecer; lo que no se mueva está en píxeles fijos o hay un `font-size` absoluto
   en `html`.
3. Inspecciona el texto más pequeño de la página. Ninguno debe bajar de 12 puntos.
4. Desactiva la hoja de estilos. Delata el texto generado con `content`.
5. Comprueba que los campos de formulario tienen la misma fuente y tamaño que el texto
   que los rodea.
