# Bootstrap con Vue

Aplica esta referencia cuando el proyecto use componentes de Bootstrap dentro de
Vue. Los criterios de fondo están en `references/componentes.md`; aquí está lo que
cambia al combinar ambas librerías.

Bootstrap aporta componentes con una buena base de accesibilidad, pero hay que
mantener su estructura y comprobar su uso en cada caso.

## Principio

Si el plugin JavaScript de Bootstrap ya gestiona el estado y lo comunica con los
atributos ARIA correctos, la tarea de Vue es dejarle hacerlo, no reconstruirlo por
su cuenta. Duplicar ese estado en un `ref` propio crea dos fuentes de verdad que
acaban desincronizándose.

De ahí salen los errores más frecuentes en estos proyectos:

- Ligar `:aria-expanded` a un `ref` propio en vez de dejar que Bootstrap actualice
  el atributo.
- Controlar la pestaña activa desde Vue cuando ya se usa `data-bs-toggle="tab"`.
- Añadir o quitar la clase `.show` a mano en lugar de usar el plugin.
- Escribir un mecanismo propio de apertura y cierre para un modal.

En todos los ejemplos que siguen, el `aria-expanded="false"` o el
`aria-selected="false"` del marcado indican **solo el estado inicial**. Bootstrap
los actualiza al interactuar; se puede comprobar abriendo el componente con las
herramientas de desarrollo delante.

Conserva esos valores `false`: son estados válidos, no atributos que haya que
eliminar con `undefined`. Antes de exigir manejadores propios, comprueba la versión
instalada y que su plugin esté cargado e inicializado. Las clases CSS por sí solas
no implementan teclado ni sincronizan ARIA. La navegación con flechas documentada
para [pestañas de Bootstrap 5.3](https://getbootstrap.com/docs/5.3/components/navs-tabs/#accessibility)
debe verificarse en la versión que use el proyecto.

## Desplegable

```html
<div class="dropdown">
  <button
    class="btn btn-secondary dropdown-toggle"
    type="button"
    data-bs-toggle="dropdown"
    aria-expanded="false"
  >
    Acciones
  </button>

  <ul class="dropdown-menu">
    <li>
      <button class="dropdown-item" type="button" @click="editar">Editar</button>
    </li>
    <li>
      <button class="dropdown-item" type="button" @click="eliminar">Eliminar</button>
    </li>
  </ul>
</div>
```

Comportamiento esperado: se llega al botón con tabulador y se abre con Intro o
Espacio; dentro se recorren las opciones con las flechas; Escape cierra y devuelve
el foco al botón. Bootstrap cambia `aria-expanded` de `false` a `true` al abrir.

- No repliques `aria-expanded` con un `ref` propio.
- No añadas `role="menu"` ni `role="menuitem"`. Un desplegable puede contener
  enlaces, botones o formularios, y esos roles implican un modelo de interacción
  específico. Reserva el patrón de menú para un widget que realmente lo sea.
- El desencadenante es un `<button>` nativo, no un `div` con un manejador de clic:
  así ya responde a ratón, toque y teclado sin programarlo aparte.

## Collapse y acordeón

```html
<button
  class="btn btn-secondary"
  type="button"
  data-bs-toggle="collapse"
  data-bs-target="#filtros"
  aria-expanded="false"
  aria-controls="filtros"
>
  Mostrar filtros
</button>

<div id="filtros" class="collapse">
  <div class="card card-body">
    <p class="mb-0">Opciones disponibles para filtrar los resultados.</p>
  </div>
</div>
```

Dos atributos hacen el trabajo y conviene no confundirlos: `aria-expanded` va en el
botón y dice si el contenido está abierto; `aria-controls` también va en el botón y
apunta al `id` del bloque que abre. Uno comunica el estado, el otro la relación.

El acordeón es varios Collapse coordinados y se apoya en el mismo plugin.

- No hace falta `role="status"` en el contenido expandido.
- Sí es responsabilidad nuestra que el texto del botón tenga sentido en los dos
  estados: `Mostrar filtros` describe la acción; `Filtros` a secas no.

## Pestañas

```html
<ul id="usuarioTabs" class="nav nav-tabs" role="tablist">
  <li class="nav-item" role="presentation">
    <button
      id="datos-tab"
      class="nav-link active"
      type="button"
      role="tab"
      data-bs-toggle="tab"
      data-bs-target="#datos-panel"
      aria-controls="datos-panel"
      aria-selected="true"
    >
      Datos
    </button>
  </li>
  <li class="nav-item" role="presentation">
    <button
      id="permisos-tab"
      class="nav-link"
      type="button"
      role="tab"
      data-bs-toggle="tab"
      data-bs-target="#permisos-panel"
      aria-controls="permisos-panel"
      aria-selected="false"
    >
      Permisos
    </button>
  </li>
</ul>

<div id="usuarioTabsContenido" class="tab-content">
  <div
    id="datos-panel"
    class="tab-pane fade show active"
    role="tabpanel"
    aria-labelledby="datos-tab"
    tabindex="0"
  >
    <p>Datos generales del usuario.</p>
  </div>
  <div
    id="permisos-panel"
    class="tab-pane fade"
    role="tabpanel"
    aria-labelledby="permisos-tab"
    tabindex="0"
  >
    <p>Permisos asignados al usuario.</p>
  </div>
</div>
```

Al probarlo con teclado se ve lo que distingue al componente: las pestañas no se
recorren con tabulador. El tabulador entra en el grupo y sale de él, y el cambio
entre pestañas se hace con las flechas. Bootstrap lo implementa por nosotros.

El `tabindex="0"` de los paneles no es decorativo: permite que el panel reciba el
foco, de modo que tras elegir pestaña el siguiente tabulador lleva a su contenido.

Bootstrap actualiza clases, `aria-selected` y orden de foco al cambiar de pestaña:
no vuelvas a controlar el estado activo desde Vue si ya usas `data-bs-toggle="tab"`.

Usa estos roles solo si el componente cambia paneles de contenido. Una navegación
con aspecto de pestañas no debe llevarlos.

## Modal

```html
<button
  type="button"
  class="btn btn-danger"
  data-bs-toggle="modal"
  data-bs-target="#modalEliminar"
>
  Eliminar usuario
</button>

<div
  id="modalEliminar"
  class="modal fade"
  tabindex="-1"
  aria-labelledby="modalEliminarTitulo"
  aria-hidden="true"
>
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h2 id="modalEliminarTitulo" class="modal-title fs-5">Eliminar usuario</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <p>¿Seguro que desea eliminar este usuario?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-danger" @click="eliminar">Eliminar</button>
      </div>
    </div>
  </div>
</div>
```

Al tabular con el modal abierto, el foco da vueltas dentro del diálogo y no sale al
resto de la página: es la retención del foco, el requisito que más se incumple al
construir un modal a mano. Bootstrap también devuelve el foco al botón de origen al
cerrar, que es la otra mitad del problema.

- `aria-labelledby` conecta el diálogo con su título, para que el lector anuncie de
  qué diálogo se trata.
- `class="btn-close"` no lleva texto visible, así que necesita `aria-label="Cerrar"`.
- `data-bs-dismiss="modal"` indica al plugin que cierre; se usa tanto en el botón
  gráfico de cierre como en `Cancelar`, que ya toma su nombre del texto visible.
- No añadas la clase `.show` a mano ni construyas tu propio mecanismo de apertura.

Para abrirlo desde código Vue, usa la API del plugin:

```js
import { Modal } from 'bootstrap'

const elemento = document.getElementById('modalEliminar')

if (elemento) {
  const modal = Modal.getOrCreateInstance(elemento)
  modal.show()
}
```

Así se conserva todo el comportamiento del componente.

## Revisión

Prueba cada componente con ratón y repite el recorrido solo con teclado: es ahí
donde se aprecia lo que el plugin está haciendo, y donde se ve si Vue lo ha roto.
Con las herramientas de desarrollo abiertas, comprueba que `aria-expanded` y
`aria-selected` cambian solos al interactuar. Si no cambian, o cambian dos veces,
hay estado duplicado.
