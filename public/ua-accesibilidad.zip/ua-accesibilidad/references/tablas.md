# Tablas

Aplica estas reglas al crear o revisar tablas HTML. Usa tablas solo para datos tabulares, no para maquetación, listas o alineación visual.

Pruebas CADUA de esta familia: `tableWithoutHead`, `sameCaptionAndSummary`, `sameCaptionAndDescribedBy`, `noIdForAriaDescribed`, `tableSimulatedTitleByCells`, `tableSimulatedTitleByHeading`, `tableNoHeadCell`, `tableComplexNoAttrs`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Reglas

- Usa `<table>` solo cuando haya relación real entre filas y columnas.
- No uses tablas para maquetar, colocar columnas visuales o simular listas.
- Las tablas deben ser lo más simples posible; si se vuelven complejas, divide la información en varias tablas.
- Toda tabla de datos debe tener un título o descripción que explique su propósito.
- Prefiere `<caption>` para el título breve de la tabla.
- Si la tabla necesita una descripción larga, usa texto visible cercano o `aria-describedby` apuntando a un `id` existente.
- No dupliques el mismo texto en `<caption>`, `summary` o `aria-describedby`; el título y la descripción deben aportar información distinta.
- Evita el atributo `summary` en HTML moderno; si existe por compatibilidad, no debe repetir el `caption`.
- No simules el título de la tabla con un encabezado justo antes, ni con una primera fila combinada.
- No combines celdas con `rowspan` o `colspan` salvo que sea imprescindible y la relación quede clara.
- La tabla debe tener al menos una fila o columna de encabezados con `<th>`.
- Usa `scope="col"` o `scope="row"` en encabezados simples para asociarlos con sus celdas.
- En tablas complejas con varios niveles de encabezado, usa `id` en los `<th>` y `headers` en las celdas relacionadas.
- No marques una tabla de datos con `role="presentation"`.
- Si una tabla es puramente decorativa, elimina la tabla si puedes; si no, `role="presentation"` solo es aceptable cuando no contiene datos que deban interpretarse como tabla.

## Tablas con desplazamiento horizontal

Una tabla dentro de un contenedor con desplazamiento, como el `.table-responsive` de
Bootstrap, esconde columnas fuera de la vista. Quien usa ratón las alcanza arrastrando;
quien usa teclado solo puede desplazarlas si el contenedor **puede recibir el foco**,
porque las flechas actúan sobre el elemento enfocado.

- El contenedor de desplazamiento debe ser alcanzable con el tabulador.
- Al serlo, se convierte en una parada de foco, así que necesita nombre accesible y un
  rol que la justifique: `role="region"` con `aria-label`, o `aria-labelledby`
  apuntando al `caption`. Sin nombre, el lector de pantalla anuncia una parada vacía.
- El nombre del contenedor y el `caption` de la tabla deben decir lo mismo, sin
  repetirse palabra por palabra si aportan matices distintos.

```html
<div class="table-responsive" tabindex="0" role="region" aria-label="Horarios por curso">
  <table>
    <caption>Horarios por curso</caption>
    ...
  </table>
</div>
```

El `tabindex` debe ser `0`, no `-1`. Con `-1` el elemento solo se puede enfocar por
código: queda fuera del recorrido del tabulador y la tabla deja de poder desplazarse
con el teclado. Los navegadores actuales ya hacen enfocables los contenedores con
desplazamiento por su cuenta, así que `-1` no añade nada, quita.

## Revisión manual

- Comprueba que al leer una celda se puede saber a que encabezados pertenece.
- Comprueba que el `caption` identifica la tabla sin repetir un encabezado de página cercano.
- Comprueba que `aria-describedby` apunta a un elemento existente y con texto útil.
- Comprueba que las celdas combinadas no rompen la comprensión con lector de pantalla.
- Comprueba si una tabla de una columna o con elementos cortos debería ser una lista.
- Si la tabla está en un contenedor con desplazamiento, comprueba con el tabulador que
  se puede llegar a él y desplazar la tabla con las flechas.

## Ejemplos

```html
<!-- Correcto: tabla simple con caption y encabezados -->
<table>
  <caption>Prestamos por tipo de usuario</caption>
  <thead>
    <tr>
      <th scope="col">Tipo de usuario</th>
      <th scope="col">Duracion</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Estudiantes</th>
      <td>14 dias</td>
    </tr>
    <tr>
      <th scope="row">Profesorado</th>
      <td>30 dias</td>
    </tr>
  </tbody>
</table>

<!-- Correcto: descripcion larga referenciada -->
<p id="desc-prestamos">La tabla compara la duracion maxima de prestamos por colectivo.</p>
<table aria-describedby="desc-prestamos">
  <caption>Duracion de prestamos</caption>
  ...
</table>

<!-- Evitar: titulo simulado con celda combinada -->
<table>
  <tr><th colspan="2">Prestamos por tipo de usuario</th></tr>
  <tr><th>Tipo</th><th>Duracion</th></tr>
</table>

<!-- Evitar: tabla usada como lista -->
<table>
  <tr><td>Prestamo de libros</td></tr>
  <tr><td>Salas de estudio</td></tr>
  <tr><td>Formacion de usuarios</td></tr>
</table>
```
