# Diseño y estilos

Aplica estas recomendaciones al crear o revisar la presentacion de una interfaz. Respeta primero el sistema visual y los componentes que ya use el proyecto.

## Clases y estilos

- Evita por norma general los estilos en línea mediante `style=""`. Prefiere clases reutilizables para mantener el código coherente y fácil de modificar.
- Si el proyecto ya usa Bootstrap y una utilidad expresa bien el ajuste, suele ser preferible usar clases como `mt-*`, `mb-*`, `p-*`, `gap-*`, `d-flex` o `visually-hidden` antes que crear CSS equivalente.
- Crea una clase propia cuando represente una regla recurrente del componente, una decisión del sistema visual o un comportamiento que no se exprese con claridad mediante utilidades existentes.
- Evita acumular demasiadas utilidades si una clase con un nombre comprensible mejora la lectura y reutilización del componente.
- No introduzcas Bootstrap en un proyecto que no lo usa solo para obtener unas pocas utilidades.
- Mantén el CSS propio en hojas o bloques de estilo del proyecto, no disperso entre atributos HTML.

## Componentes y jerarquía

- Reutiliza los componentes y variantes existentes antes de crear otros visualmente equivalentes.
- En paneles y tarjetas, usa un encabezado real cuando el título introduzca una sección. El nivel debe encajar con la jerarquía de la página.
- No conviertas en encabezado un texto que solo actúa como etiqueta, dato destacado o elemento decorativo.
- Mantén espaciado, alineación, bordes, radios y sombras coherentes entre componentes similares.
- Evita usar tarjetas, paneles o badges cuando una estructura más sencilla comunique mejor el contenido.

## Bootstrap y estados de color

- Si el proyecto usa Bootstrap, aprovecha sus variantes contextuales para botones, alertas, badges y componentes: `primary`, `secondary`, `success`, `danger`, `warning` e `info`.
- Prefiere las clases de componente o combinaciones que resuelvan fondo y texto, como `text-bg-danger` en badges compatibles, antes que fijar colores mediante `style`.
- Elige la variante por su significado, no solo por preferencia estética: `danger` para errores o acciones destructivas, `warning` para avisos y `success` para confirmaciones.
- Acompaña siempre el color con texto, icono con nombre accesible u otra señal. Revisa el contraste real de cada variante y estado.
- No uses una variante contextual para contenido que no tenga ese significado, porque reduce la consistencia del sistema.

## Interacción y accesibilidad

- Todos los componentes interactivos deben funcionar con teclado, mostrar foco visible y exponer correctamente sus relaciones y estados mediante HTML nativo o ARIA cuando corresponda.
- Mantén sincronizados estados como `aria-expanded`, `aria-selected`, `aria-pressed`, `aria-current`, `aria-invalid` y `aria-disabled` con lo que ocurre visualmente.
- Los iconos decorativos deben ocultarse a las tecnologías de apoyo; los iconos informativos o interactivos necesitan una alternativa o nombre accesible.
- Respeta las preferencias de movimiento reducido y evita animaciones que dificulten leer, enfocar o completar una tarea.

## Revisión

- Comprueba la interfaz con distintos tamaños de texto y de ventana sin perder contenido ni funcionalidad.
- Revisa estados normal, hover, foco, activo, deshabilitado, carga, error y éxito.
- Comprueba que las clases elegidas expresan una intención clara y no duplican estilos ya disponibles en el proyecto.
