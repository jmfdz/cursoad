# Listas

Aplica estas reglas al crear o revisar listas de elementos, menús, pasos, requisitos, opciones, indices o cualquier contenido que sea una enumeración.

Pruebas CADUA de esta familia: `listElementEmpty`, `listEmpty`, `listBadParent`, `listWrong`, `list3LevelsSimulated`, `listSimulated`, `listSimulatedByTable`, `listRoleWithoutText`. Consulta `references/checklist.md` para el criterio WCAG, el nivel y la comprobación equivalente de cada código, y cítalos en el informe para que la revisión de código y la validación automática coincidan.

## Reglas

- Usa listas HTML reales: `<ul>` para listas sin orden y `<ol>` para secuencias donde el orden importa.
- Cada elemento de lista debe estar en un `<li>`.
- Todo `<li>` debe tener contenido real, salvo elementos técnicos ocultos de forma intencional y no expuestos a usuarios.
- No dejes listas vacías; elimina la lista o añade elementos.
- No coloques `<li>` fuera de un `<ul>` u `<ol>`.
- No dejes separadores visuales de menús como `<li>` vacíos expuestos.
- Si un separador decorativo está dentro de una lista, oculta el `<li>` contenedor con `aria-hidden="true"`; no basta con ocultar solo el `<hr>` o el icono interior.
- Si el menú no está estructurado como lista, el separador puede ser un `<hr class="dropdown-divider" aria-hidden="true">` fuera de `<li>`.
- No simules listas con párrafos, saltos de línea, guiones, asteriscos, números escritos o letras: usa `ul` u `ol`.
- No repitas marcadores manuales dentro de una lista real, como `-`, `*`, `1.`, `a)` o `I-`, salvo que formen parte del contenido.
- No uses tablas de una columna para representar una lista; usa una lista real.
- Usa tablas solo cuando haya datos tabulares con relación entre filas y columnas.
- En menús de navegación, combina `nav` con `ul`/`ol` y `li` cuando el menú sea una lista de enlaces.
- En listados de resultados, menús laterales, `list-group` o pestañas generadas desde arrays, usa `ul`/`ol` con `li`; evita un `div` contenedor con muchos enlaces o botones si representa una colección.
- Si una lista funciona también como `tablist`, puedes poner `role="tablist"` en el `ul`, envolver cada pestaña en `li role="presentation"` y mantener el enlace o botón interno con `role="tab"`.
- En listas anidadas, la lista hija debe estar dentro del `<li>` padre correspondiente.

## Revisión manual

- Comprueba si varios párrafos consecutivos empiezan con patrones como `1.`, `2.`, `3.`, `a)`, `b)`, `-` o `*`; normalmente deben ser una lista.
- Comprueba si una tabla de una sola columna contiene elementos cortos independientes; normalmente debe ser una lista.
- Comprueba que la elección entre `ul` y `ol` refleja si el orden cambia el significado.
- Comprueba que las listas anidadas se anuncian como parte del elemento padre correcto.

## Vue y renderizado dinámico

- Si una lista se pinta desde un array, no renderices `<ul>` u `<ol>` cuando el array esté vacío: genera `<ul></ul>` y es el error `listEmpty`.
- En Vue, pon `v-if="items.length"` en el contenedor de lista o en un `<template>` envolvente, y deja `v-for` en los `<li>`.
- Evita combinar `v-if` y `v-for` en el mismo elemento.
- Consulta `references/plantillas-vue.md` para el resto de reglas de plantilla y para los tres estados de una lista con carga asíncrona.

## Ejemplos

```html
<!-- Correcto: lista sin orden -->
<ul>
  <li>Prestamo de libros</li>
  <li>Salas de estudio</li>
  <li>Formacion de usuarios</li>
</ul>

<!-- Correcto: pasos ordenados -->
<ol>
  <li>Rellena la solicitud</li>
  <li>Adjunta la documentacion</li>
  <li>Envia el formulario</li>
</ol>

<!-- Evitar: lista simulada con parrafos -->
<p>1. Rellena la solicitud</p>
<p>2. Adjunta la documentacion</p>
<p>3. Envia el formulario</p>

<!-- Evitar: marcadores manuales dentro de una lista real -->
<ul>
  <li>- Prestamo de libros</li>
  <li>- Salas de estudio</li>
</ul>

<!-- Correcto: lista anidada -->
<ul>
  <li>
    Servicios
    <ul>
      <li>Prestamo</li>
      <li>Reservas</li>
    </ul>
  </li>
</ul>

<!-- Vue: evita renderizar una lista vacia -->
<ul v-if="servicios.length">
  <li v-for="servicio in servicios" :key="servicio.id">
    {{ servicio.nombre }}
  </li>
</ul>

<!-- Correcto: separador decorativo en menu basado en lista -->
<ul class="dropdown-menu">
  <li><button class="dropdown-item" type="button">Editar</button></li>
  <li class="dropdown-divider" aria-hidden="true"></li>
  <li><button class="dropdown-item" type="button">Eliminar</button></li>
</ul>

<!-- Correcto: lista que tambien funciona como tablist -->
<ul class="list-group" role="tablist">
  <li role="presentation">
    <a href="#panel-1" role="tab" aria-controls="panel-1" aria-selected="true">
      Pagina principal
    </a>
  </li>
  <li role="presentation">
    <a href="#panel-2" role="tab" aria-controls="panel-2" aria-selected="false">
      Contacto
    </a>
  </li>
</ul>

<!-- Evitar: li vacio expuesto -->
<ul class="dropdown-menu">
  <li><button class="dropdown-item" type="button">Editar</button></li>
  <li><hr class="dropdown-divider"></li>
  <li><button class="dropdown-item" type="button">Eliminar</button></li>
</ul>
```
